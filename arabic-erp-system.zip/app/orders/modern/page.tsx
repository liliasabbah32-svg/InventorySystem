import { ModernSalesOrders } from "@/components/orders/modern-sales-orders"

export default function ModernOrdersPage() {
  return <ModernSalesOrders />
}
