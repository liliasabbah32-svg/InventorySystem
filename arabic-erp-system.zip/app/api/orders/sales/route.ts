import { type NextRequest, NextResponse } from "next/server"
import { getSalesOrders, createSalesOrder } from "@/lib/orders"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const filters = {
      search: searchParams.get("search") || undefined,
      status: searchParams.get("status") || undefined,
      salesman: searchParams.get("salesman") || undefined,
      dateFrom: searchParams.get("dateFrom") || undefined,
      dateTo: searchParams.get("dateTo") || undefined,
      customerId: searchParams.get("customerId") ? Number.parseInt(searchParams.get("customerId")!) : undefined,
    }

    const orders = await getSalesOrders(filters)

    return NextResponse.json(orders)
  } catch (error) {
    console.error("Sales orders API error:", error)
    return NextResponse.json({ error: "حدث خطأ في جلب طلبات المبيعات" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    console.log("[v0] POST /api/orders/sales - Starting request processing")

    const requestData = await request.json()
    console.log("[v0] Request data received:", JSON.stringify(requestData, null, 2))

    let orderData, items

    if (requestData.orderData && requestData.items) {
      // New structure: { orderData, items }
      orderData = requestData.orderData
      items = requestData.items
    } else {
      // Legacy structure: direct order data with items array
      const { items: itemsArray, ...orderFields } = requestData
      orderData = orderFields
      items = itemsArray || []
    }

    if (!orderData) {
      console.error("[v0] Validation failed: No order data")
      return NextResponse.json({ error: "بيانات الطلبية مطلوبة" }, { status: 400 })
    }

    if (!orderData.customer_name && !orderData.customer_id) {
      console.error("[v0] Validation failed: No customer")
      return NextResponse.json({ error: "اسم العميل أو رقم العميل مطلوب" }, { status: 400 })
    }

    if (!items || items.length === 0) {
      console.error("[v0] Validation failed: No items")
      return NextResponse.json({ error: "عناصر الطلبية مطلوبة" }, { status: 400 })
    }

    console.log("[v0] Validation passed, creating order...")
    const order = await createSalesOrder(orderData, items)
    console.log("[v0] Order created successfully:", order.id)

    return NextResponse.json(order, { status: 201 })
  } catch (error: any) {
    console.error("[v0] Create sales order API error:", error)
    console.error("[v0] Error stack:", error.stack)

    const errorMessage = error.message || "حدث خطأ في إنشاء طلبية المبيعات"
    return NextResponse.json(
      {
        error: errorMessage,
        details: process.env.NODE_ENV === "development" ? error.stack : undefined,
      },
      { status: 500 },
    )
  }
}
