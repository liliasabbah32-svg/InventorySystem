import { type NextRequest, NextResponse } from "next/server"
import { getExchangeRates, updateExchangeRate } from "@/lib/database"
import { neon } from "@neondatabase/serverless"

const sql = neon(process.env.DATABASE_URL!)

export async function GET() {
  try {
    const result = await getExchangeRates()

    if (!result.success) {
      return NextResponse.json({ error: result.error }, { status: 500 })
    }

    return NextResponse.json({ rates: result.data })
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch exchange rates" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { currency_name, currency_code, currency_symbol, buy_rate, sell_rate, exchange_rate, is_active } = body

    // Validate required fields
    if (!currency_name || !currency_code) {
      return NextResponse.json({ error: "Currency name and code are required" }, { status: 400 })
    }

    const result = await sql`
      INSERT INTO exchange_rates (
        currency_name, 
        currency_code, 
        currency_symbol, 
        buy_rate, 
        sell_rate, 
        exchange_rate, 
        is_active
      ) VALUES (
        ${currency_name}, 
        ${currency_code}, 
        ${currency_symbol || currency_code}, 
        ${buy_rate || 0}, 
        ${sell_rate || 0}, 
        ${exchange_rate || 0}, 
        ${is_active !== false}
      ) RETURNING *
    `

    return NextResponse.json({ rate: result[0] })
  } catch (error) {
    console.error("Error creating exchange rate:", error)
    return NextResponse.json({ error: "Failed to create exchange rate" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    const { id, ...rates } = await request.json()

    const result = await updateExchangeRate(id, rates)

    if (!result.success) {
      return NextResponse.json({ error: result.error }, { status: 500 })
    }

    return NextResponse.json({ rate: result.data[0] })
  } catch (error) {
    return NextResponse.json({ error: "Failed to update exchange rate" }, { status: 500 })
  }
}
