import { type NextRequest, NextResponse } from "next/server"
import { neon } from "@neondatabase/serverless"

const sql = neon(process.env.DATABASE_URL!)

export async function GET() {
  try {
    const suppliers = await sql`
      SELECT *
      FROM suppliers
      ORDER BY created_at DESC
    `

    return NextResponse.json(suppliers)
  } catch (error) {
    console.error("Error fetching suppliers:", error)
    return NextResponse.json({ error: "Failed to fetch suppliers" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()

    console.log("[v0] Received supplier data:", data)

    // Check if supplier code already exists
    if (data.supplier_code) {
      const existingSupplier = await sql`
        SELECT id FROM suppliers WHERE supplier_code = ${data.supplier_code}
      `
      if (existingSupplier.length > 0) {
        return NextResponse.json({ error: "رقم المورد موجود مسبقاً" }, { status: 400 })
      }
    }

    console.log("[v0] About to insert supplier with columns:", {
      supplier_code: data.supplier_code,
      supplier_name: data.supplier_name,
      mobile1: data.mobile1,
      mobile2: data.mobile2,
      whatsapp1: data.whatsapp1,
      whatsapp2: data.whatsapp2,
      city: data.city,
      address: data.address,
      email: data.email,
      status: data.status || "نشط",
      business_nature: data.business_nature,
      salesman: data.salesman,
      movement_notes: data.movement_notes,
      general_notes: data.general_notes,
      classifications: data.classifications,
      account_opening_date: data.account_opening_date || new Date().toISOString().split("T")[0],
      web_username: data.web_username,
      api_number: data.api_number,
    })

    const result = await sql`
      INSERT INTO suppliers (
        supplier_code, supplier_name, mobile1, mobile2, whatsapp1, whatsapp2,
        city, address, email, status, business_nature, salesman,
        movement_notes, general_notes, classifications, account_opening_date,
        web_username, api_number
      ) VALUES (
        ${data.supplier_code}, 
        ${data.supplier_name}, 
        ${data.mobile1}, 
        ${data.mobile2}, 
        ${data.whatsapp1}, 
        ${data.whatsapp2}, 
        ${data.city}, 
        ${data.address},
        ${data.email}, 
        ${data.status || "نشط"}, 
        ${data.business_nature}, 
        ${data.salesman},
        ${data.movement_notes}, 
        ${data.general_notes}, 
        ${data.classifications},
        ${data.account_opening_date || new Date().toISOString().split("T")[0]}, 
        ${data.web_username}, 
        ${data.api_number}
      ) RETURNING *
    `

    console.log("[v0] Supplier created successfully:", result[0])
    return NextResponse.json(result[0], { status: 201 })
  } catch (error) {
    console.error("[v0] Error creating supplier:", error)
    console.error("[v0] Error details:", {
      message: error.message,
      stack: error.stack,
      name: error.name,
    })
    return NextResponse.json({ error: "فشل في إنشاء المورد" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    const data = await request.json()
    const { id, ...updateData } = data

    const result = await sql`
      UPDATE suppliers SET
        supplier_name = ${updateData.supplier_name},
        mobile1 = ${updateData.mobile1},
        mobile2 = ${updateData.mobile2},
        whatsapp1 = ${updateData.whatsapp1},
        whatsapp2 = ${updateData.whatsapp2},
        city = ${updateData.city},
        address = ${updateData.address},
        email = ${updateData.email},
        status = ${updateData.status},
        business_nature = ${updateData.business_nature},
        salesman = ${updateData.salesman},
        movement_notes = ${updateData.movement_notes},
        general_notes = ${updateData.general_notes},
        classifications = ${updateData.classifications},
        web_username = ${updateData.web_username},
        api_number = ${updateData.api_number}
      WHERE id = ${id}
      RETURNING *
    `

    return NextResponse.json(result[0])
  } catch (error) {
    console.error("Error updating supplier:", error)
    return NextResponse.json({ error: "فشل في تحديث المورد" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get("id")

    if (!id) {
      return NextResponse.json({ error: "Supplier ID is required" }, { status: 400 })
    }

    await sql`DELETE FROM suppliers WHERE id = ${id}`

    return NextResponse.json({ message: "Supplier deleted successfully" })
  } catch (error) {
    console.error("Error deleting supplier:", error)
    return NextResponse.json({ error: "Failed to delete supplier" }, { status: 500 })
  }
}
