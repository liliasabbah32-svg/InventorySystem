import { type NextRequest, NextResponse } from "next/server"
import { neon } from "@neondatabase/serverless"

const sql = neon(process.env.DATABASE_URL!)

export async function GET() {
  try {
    // Check if warehouses table exists, if not create it
    await sql`
      CREATE TABLE IF NOT EXISTS warehouses (
        id SERIAL PRIMARY KEY,
        warehouse_code VARCHAR(10) UNIQUE NOT NULL,
        warehouse_name VARCHAR(100) NOT NULL,
        warehouse_name_en VARCHAR(100),
        description TEXT,
        location VARCHAR(200),
        is_active BOOLEAN DEFAULT true,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `

    // Check if table is empty and populate with default warehouses
    const existingWarehouses = await sql`SELECT COUNT(*) as count FROM warehouses`

    if (existingWarehouses[0].count === 0) {
      const defaultWarehouses = [
        { code: "MAIN", name: "المستودع الرئيسي", name_en: "Main Warehouse", location: "المبنى الرئيسي" },
        { code: "SALES", name: "مستودع المبيعات", name_en: "Sales Warehouse", location: "قسم المبيعات" },
        { code: "PROD", name: "مستودع الإنتاج", name_en: "Production Warehouse", location: "قسم الإنتاج" },
        { code: "DMGD", name: "مستودع التالف", name_en: "Damaged Warehouse", location: "منطقة التالف" },
        { code: "RETN", name: "مستودع الإرجاع", name_en: "Return Warehouse", location: "منطقة الإرجاع" },
      ]

      for (const warehouse of defaultWarehouses) {
        await sql`
          INSERT INTO warehouses (warehouse_code, warehouse_name, warehouse_name_en, location, is_active)
          VALUES (${warehouse.code}, ${warehouse.name}, ${warehouse.name_en}, ${warehouse.location}, true)
        `
      }
    }

    const warehouses = await sql`
      SELECT 
        id,
        warehouse_code,
        warehouse_name,
        warehouse_name_en,
        description,
        location,
        is_active,
        created_at,
        updated_at
      FROM warehouses
      WHERE is_active = true
      ORDER BY warehouse_name
    `

    return NextResponse.json(warehouses.map((w) => ({ ...w, name: w.warehouse_name })))
  } catch (error) {
    console.error("Error fetching warehouses:", error)
    return NextResponse.json({ error: "Failed to fetch warehouses" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()

    if (!data.warehouse_name || !data.warehouse_code) {
      return NextResponse.json({ error: "اسم المستودع ورمزه مطلوبان" }, { status: 400 })
    }

    // Check if warehouse code already exists
    const existingWarehouse = await sql`
      SELECT id FROM warehouses WHERE warehouse_code = ${data.warehouse_code}
    `

    if (existingWarehouse.length > 0) {
      return NextResponse.json({ error: "رمز المستودع موجود مسبقاً" }, { status: 400 })
    }

    const result = await sql`
      INSERT INTO warehouses (
        warehouse_code, warehouse_name, warehouse_name_en, description, location, is_active
      ) VALUES (
        ${data.warehouse_code}, 
        ${data.warehouse_name}, 
        ${data.warehouse_name_en || ""}, 
        ${data.description || ""}, 
        ${data.location || ""}, 
        ${data.is_active !== false}
      ) RETURNING *
    `

    return NextResponse.json({ ...result[0], name: result[0].warehouse_name }, { status: 201 })
  } catch (error) {
    console.error("Error creating warehouse:", error)
    return NextResponse.json({ error: "Failed to create warehouse" }, { status: 500 })
  }
}
