import { type NextRequest, NextResponse } from "next/server"
import { advanceOrderToNextStage } from "@/lib/workflow"

export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const orderId = Number.parseInt(params.id)
    const body = await request.json()

    const { orderType, performedByUser, performedByDepartment, notes } = body

    if (!orderType || !performedByUser || !performedByDepartment) {
      return NextResponse.json({ error: "جميع الحقول المطلوبة يجب أن تكون موجودة" }, { status: 400 })
    }

    const updatedStatus = await advanceOrderToNextStage(
      orderId,
      orderType,
      performedByUser,
      performedByDepartment,
      notes,
    )

    return NextResponse.json({
      success: true,
      message: "تم تقديم الطلبية للمرحلة التالية بنجاح",
      data: updatedStatus,
    })
  } catch (error) {
    console.error("Error advancing order:", error)
    return NextResponse.json({ error: "حدث خطأ في تقديم الطلبية" }, { status: 500 })
  }
}
