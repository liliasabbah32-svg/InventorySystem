import { type NextRequest, NextResponse } from "next/server"
import { neon } from "@neondatabase/serverless"

const sql = neon(process.env.DATABASE_URL!)

export async function POST(request: NextRequest, { params }: { params: { orderId: string } }) {
  try {
    const orderId = params.orderId
    const body = await request.json()
    const { orderType, performedByUser, performedByDepartment, notes, newStage } = body

    console.log("[v0] Advancing order:", { orderId, orderType })

    try {
      // جلب معلومات الطلبية
      const orderTable = orderType === "sales" ? "sales_orders" : "purchase_orders"
      const orderInfo = await sql`
        SELECT id, customer_id, order_number
        FROM ${sql(orderTable)}
        WHERE id = ${orderId}
        LIMIT 1
      `

      if (orderInfo.length > 0 && orderInfo[0].customer_id) {
        // تحديد حالة الإشعار بناءً على المرحلة الجديدة
        const notificationStatus = mapStageToNotificationStatus(newStage.stage_name)

        if (notificationStatus) {
          // إرسال الإشعار
          await fetch(`${request.nextUrl.origin}/api/customer-notifications/send`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              customer_id: orderInfo[0].customer_id,
              order_id: orderInfo[0].id,
              status: notificationStatus,
            }),
          })

          console.log("[v0] Notification sent for order:", orderInfo[0].order_number)
        }
      }
    } catch (notificationError) {
      console.error("[v0] Error sending notification:", notificationError)
      // لا نوقف العملية إذا فشل الإشعار
    }

    return NextResponse.json({
      success: true,
      message: "تم تقديم الطلبية بنجاح",
    })
  } catch (error) {
    console.error("[v0] Error advancing order:", error)
    return NextResponse.json({ error: "فشل في تقديم الطلبية" }, { status: 500 })
  }
}

// دالة مساعدة لتحويل اسم المرحلة إلى حالة الإشعار
function mapStageToNotificationStatus(stageName: string): string | null {
  const stageMap: Record<string, string> = {
    "استلام الطلبية": "received",
    "تحضير الطلبية": "preparing",
    "التدقيق والمراجعة": "quality_check",
    "جاهز للشحن": "ready_to_ship",
    "تم الشحن": "shipped",
    "تم التسليم": "delivered",
  }

  return stageMap[stageName] || null
}
