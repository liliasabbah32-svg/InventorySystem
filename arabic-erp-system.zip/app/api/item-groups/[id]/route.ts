import { type NextRequest, NextResponse } from "next/server"
import { neon } from "@neondatabase/serverless"

const sql = neon(process.env.DATABASE_URL!)

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const data = await request.json()
    const { id } = params

    const isActive = data.status === "نشط" || data.status !== "غير نشط"

    const result = await sql`
      UPDATE item_groups SET
        group_name = ${data.group_name},
        description = ${data.description},
        is_active = ${isActive},
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ${id}
      RETURNING *
    `

    const formattedResult = {
      ...result[0],
      status: result[0].is_active ? "نشط" : "غير نشط",
    }

    return NextResponse.json(formattedResult)
  } catch (error) {
    console.error("Error updating item group:", error)
    return NextResponse.json({ error: "Failed to update item group" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { id } = params

    await sql`DELETE FROM item_groups WHERE id = ${id}`

    return NextResponse.json({ message: "Item group deleted successfully" })
  } catch (error) {
    console.error("Error deleting item group:", error)
    return NextResponse.json({ error: "Failed to delete item group" }, { status: 500 })
  }
}
