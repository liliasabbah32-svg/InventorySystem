"use client"

import { Button } from "@/components/ui/button"
import {
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  Plus,
  Save,
  Trash2,
  FileText,
  Download,
  Printer,
} from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { useToast } from "@/hooks/use-toast"

interface UniversalToolbarProps {
  // Navigation props
  currentRecord?: number
  totalRecords?: number
  onFirst?: () => void
  onPrevious?: () => void
  onNext?: () => void
  onLast?: () => void

  // CRUD operations
  onNew?: () => void
  onSave?: () => void
  onDelete?: () => void

  // Report operations
  onReport?: () => void
  onExportExcel?: () => void
  onPrint?: () => void

  // State props
  isLoading?: boolean
  isSaving?: boolean
  canSave?: boolean
  canDelete?: boolean
  isFirstRecord?: boolean
  isLastRecord?: boolean

  // Labels (for Arabic support)
  labels?: {
    new: string
    save: string
    previous: string
    next: string
    first: string
    last: string
    delete: string
    report: string
    exportExcel: string
    print: string
  }
}

const defaultLabels = {
  new: "جديد",
  save: "حفظ",
  previous: "السابق",
  next: "التالي",
  first: "الأول",
  last: "الأخير",
  delete: "حذف",
  report: "استعلام",
  exportExcel: "تصدير إكسل",
  print: "طباعة",
}

export function UniversalToolbar({
  currentRecord = 1,
  totalRecords = 0,
  onFirst,
  onPrevious,
  onNext,
  onLast,
  onNew,
  onSave,
  onDelete,
  onReport,
  onExportExcel,
  onPrint,
  isLoading = false,
  isSaving = false,
  canSave = true,
  canDelete = true,
  isFirstRecord = false,
  isLastRecord = false,
  labels = defaultLabels,
}: UniversalToolbarProps) {
  const hasRecords = totalRecords > 0
  const { toast } = useToast()

  const handleFirst = () => {
    if (!hasRecords) {
      toast({
        title: "لا توجد سجلات",
        description: "لا يوجد سجلات لعرضها. قم بإضافة سجل جديد أولاً.",
        variant: "default",
      })
      return
    }
    onFirst?.()
  }

  const handlePrevious = () => {
    if (!hasRecords) {
      toast({
        title: "لا توجد سجلات",
        description: "لا يوجد سجلات لعرضها. قم بإضافة سجل جديد أولاً.",
        variant: "default",
      })
      return
    }
    onNext?.()
  }

  const handleNext = () => {
    if (!hasRecords) {
      toast({
        title: "لا توجد سجلات",
        description: "لا يوجد سجلات لعرضها. قم بإضافة سجل جديد أولاً.",
        variant: "default",
      })
      return
    }
    onPrevious?.()
  }

  const handleLast = () => {
    if (!hasRecords) {
      toast({
        title: "لا توجد سجلات",
        description: "لا يوجد سجلات لعرضها. قم بإضافة سجل جديد أولاً.",
        variant: "default",
      })
      return
    }
    onLast?.()
  }

  return (
    <div className="flex items-center justify-start gap-2 p-2 bg-background border-b" dir="rtl">
      {/* Actions Section - Now first on the right */}
      <div className="flex items-center gap-1">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" size="sm" disabled={isLoading} className="h-7 text-xs px-2 bg-transparent">
              <FileText className="h-3 w-3 ml-1" />
              {labels.report}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            {onReport && (
              <DropdownMenuItem onClick={onReport} className="text-xs">
                <FileText className="h-3 w-3 ml-2" />
                عرض التقرير
              </DropdownMenuItem>
            )}
            {onExportExcel && (
              <DropdownMenuItem onClick={onExportExcel} className="text-xs">
                <Download className="h-3 w-3 ml-2" />
                {labels.exportExcel}
              </DropdownMenuItem>
            )}
            {onPrint && (
              <DropdownMenuItem onClick={onPrint} className="text-xs">
                <Printer className="h-3 w-3 ml-2" />
                {labels.print}
              </DropdownMenuItem>
            )}
          </DropdownMenuContent>
        </DropdownMenu>

        {onDelete && (
          <Button
            variant="destructive"
            size="sm"
            onClick={onDelete}
            disabled={isLoading || !canDelete || !hasRecords}
            title={!canDelete ? "لا يوجد سجل محدد للحذف" : "حذف السجل الحالي"}
            className="h-7 text-xs px-2"
          >
            <Trash2 className="h-3 w-3 ml-1" />
            {labels.delete}
          </Button>
        )}

        <div className="h-6 w-px bg-border mx-1" />
      </div>

      {/* Record Counter */}
      <div className="text-xs text-muted-foreground">
        {hasRecords ? `${currentRecord + 1} من ${totalRecords}` : "لا توجد سجلات"}
      </div>

      <div className="h-6 w-px bg-border mx-1" />

      {/* Navigation Section - Now last */}
      <div className="flex items-center gap-1">
        {onNew && (
          <Button
            variant="outline"
            size="sm"
            onClick={onNew}
            disabled={isLoading}
            className="h-7 text-xs px-2 bg-transparent"
          >
            <Plus className="h-3 w-3 ml-1" />
            {labels.new}
          </Button>
        )}

        {onSave && (
          <Button
            variant="default"
            size="sm"
            onClick={onSave}
            disabled={isLoading || isSaving || !canSave}
            className="h-7 text-xs px-2"
          >
            <Save className="h-3 w-3 ml-1" />
            {isSaving ? "جاري الحفظ..." : labels.save}
          </Button>
        )}

        <div className="h-6 w-px bg-border mx-1" />

        {onLast && (
          <Button
            variant="outline"
            size="sm"
            onClick={handleLast}
            disabled={isLoading || (hasRecords && isLastRecord)}
            className="h-7 px-2 bg-transparent"
          >
            <ChevronsLeft className="h-3 w-3 ml-1" />
            <span className="text-xs">{labels.last}</span>
          </Button>
        )}

        {onNext && (
          <Button
            variant="outline"
            size="sm"
            onClick={handleNext}
            disabled={isLoading || (hasRecords && isLastRecord)}
            className="h-7 px-2 bg-transparent"
          >
            <ChevronLeft className="h-3 w-3 ml-1" />
            <span className="text-xs">{labels.next}</span>
          </Button>
        )}

        {onPrevious && (
          <Button
            variant="outline"
            size="sm"
            onClick={handlePrevious}
            disabled={isLoading || (hasRecords && isFirstRecord)}
            className="h-7 px-2 bg-transparent"
          >
            <span className="text-xs">{labels.previous}</span>
            <ChevronRight className="h-3 w-3 mr-1" />
          </Button>
        )}

        {onFirst && (
          <Button
            variant="outline"
            size="sm"
            onClick={handleFirst}
            disabled={isLoading || (hasRecords && isFirstRecord)}
            className="h-7 px-2 bg-transparent"
          >
            <span className="text-xs">{labels.first}</span>
            <ChevronsRight className="h-3 w-3 mr-1" />
          </Button>
        )}
      </div>
    </div>
  )
}
