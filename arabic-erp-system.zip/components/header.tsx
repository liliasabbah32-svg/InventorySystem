"use client"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { useAuth } from "@/components/auth/auth-context"
import { Icons } from "@/components/ui/icons"
import { NotificationCenter } from "@/components/notifications/notification-center"

interface HeaderProps {
  onMenuClick: () => void
  activeSection: string
  onProfileClick?: () => void
  onSettingsClick?: () => void
}

export function Header({ onMenuClick, activeSection, onProfileClick, onSettingsClick }: HeaderProps) {
  const { user, logout } = useAuth()

  const sectionTitles: Record<string, string> = {
    dashboard: "لوحة التحكم الرئيسية",
    "order-tracking": "متابعة الطلبيات",
    "theme-customization": "تخصيص المظهر والألوان",
    customers: "إدارة الزبائن",
    suppliers: "إدارة الموردين",
    products: "الأصناف والخدمات",
    "product-groups": "مجموعات الأصناف",
    branches: "الأقسام والفروع",
    definitions: "التعريفات",
    "sales-orders": "طلبيات المبيعات",
    "purchase-orders": "طلبيات المشتريات",
    "exchange-rates": "أسعار الصرف اليومية",
    "order-reports": "تقارير الطلبيات",
    "product-reports": "تقارير الأصناف والخدمات",
    "user-settings": "إعدادات المستخدمين",
    "print-settings": "إعدادات الطباعة",
    "system-settings": "إعدادات النظام",
    "document-settings": "إعدادات السندات",
    permissions: "إدارة المستخدمين والصلاحيات",
    "general-settings": "الإعدادات العامة",
    "api-settings": "إعدادات API والتكامل",
    "pervasive-settings": "إعدادات قاعدة بيانات Pervasive",
  }

  return (
    <header
      className="h-14 md:h-16 border-b border-border bg-card px-3 md:px-6 flex items-center justify-between shadow-sm"
      dir="rtl"
    >
      <div className="flex items-center gap-2 md:gap-4 flex-1 min-w-0">
        <Button variant="ghost" size="icon" onClick={onMenuClick} className="shrink-0">
          <Icons.Menu />
        </Button>
        <h1 className="text-sm md:text-xl font-semibold text-card-foreground truncate">
          {sectionTitles[activeSection] || "نظام إدارة المخزون والطلبيات"}
        </h1>
      </div>

      <div className="flex items-center gap-2 md:gap-4 shrink-0">
        <div className="relative hidden lg:block">
          <Icons.Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
          <Input
            placeholder="البحث..."
            className="w-48 xl:w-64 pr-10 pl-4 bg-muted/50 border-0 focus:bg-background text-right"
          />
        </div>

        <Button variant="ghost" size="icon" className="lg:hidden">
          <Icons.Search className="h-4 w-4 md:h-5 md:w-5" />
        </Button>

        <NotificationCenter userId={user?.id} department={user?.department} className="relative" />

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="flex items-center gap-2 h-auto p-1 md:p-2">
              <div className="w-7 h-7 md:w-8 md:h-8 bg-emerald-600 rounded-full flex items-center justify-center">
                <Icons.User className="h-3 w-3 md:h-4 md:w-4 text-white" />
              </div>
              <div className="text-right hidden md:block">
                <p className="text-sm font-medium">{user?.fullName}</p>
                <p className="text-xs text-muted-foreground">{user?.email}</p>
              </div>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start" className="w-48 md:w-56">
            <DropdownMenuLabel>
              <div className="flex flex-col space-y-1 text-right">
                <p className="text-sm font-medium leading-none">{user?.fullName}</p>
                <p className="text-xs leading-none text-muted-foreground">{user?.role}</p>
                <p className="text-xs leading-none text-muted-foreground">{user?.email}</p>
              </div>
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem className="justify-end cursor-pointer" onClick={() => onProfileClick?.()}>
              <span>الملف الشخصي</span>
              <Icons.UserCircle className="mr-2 h-4 w-4" />
            </DropdownMenuItem>
            <DropdownMenuItem className="justify-end cursor-pointer" onClick={() => onSettingsClick?.()}>
              <span>الإعدادات</span>
              <Icons.Settings className="mr-2 h-4 w-4" />
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={logout} className="text-red-600 focus:text-red-600 justify-end">
              <span>تسجيل الخروج</span>
              <Icons.LogOut className="mr-2 h-4 w-4" />
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  )
}
