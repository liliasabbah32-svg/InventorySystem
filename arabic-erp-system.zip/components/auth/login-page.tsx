"use client"

import type React from "react"
import { PasswordReset } from "./password-reset"
import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Eye, EyeOff, Lock, User, Building2, AlertCircle, LogIn } from "lucide-react"

interface LoginPageProps {
  onLogin: (credentials: { username: string; password: string; rememberMe: boolean }) => void
}

export function LoginPage({ onLogin }: LoginPageProps) {
  const [credentials, setCredentials] = useState({
    username: "",
    password: "",
    rememberMe: false,
  })
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const [showPasswordReset, setShowPasswordReset] = useState(false)

  if (showPasswordReset) {
    return <PasswordReset onBack={() => setShowPasswordReset(false)} />
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setIsLoading(true)

    try {
      await onLogin(credentials)
    } catch (err: any) {
      setError(err.message || "حدث خطأ في تسجيل الدخول")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-blue-50 to-emerald-100 flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-6">
        {/* Company Logo & Title */}
        <div className="text-center space-y-4">
          <div className="mx-auto w-20 h-20 bg-gradient-to-br from-emerald-600 to-blue-600 rounded-2xl flex items-center justify-center shadow-lg">
            <Building2 className="h-10 w-10 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">نظام إدارة المخزون والطلبيات</h1>
            <p className="text-gray-600 text-lg">Inventory & Orders Management System</p>
            <p className="text-gray-500 text-sm mt-1">تسجيل الدخول إلى حسابك</p>
          </div>
        </div>

        {/* Login Form */}
        <Card className="shadow-xl border-0 bg-white/80 backdrop-blur-sm">
          <CardHeader className="space-y-1 pb-6">
            <CardTitle className="text-2xl text-center flex items-center justify-center gap-2">
              <LogIn className="h-6 w-6 text-emerald-600" />
              تسجيل الدخول
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-5">
              {error && (
                <Alert className="border-red-200 bg-red-50">
                  <AlertCircle className="h-4 w-4 text-red-600" />
                  <AlertDescription className="text-red-700 font-medium">{error}</AlertDescription>
                </Alert>
              )}

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-sm">
                <h4 className="font-semibold text-blue-800 mb-2">بيانات تسجيل الدخول:</h4>
                <div className="space-y-1 text-blue-700">
                  <p>
                    <strong>المدير:</strong> zaid.salous | كلمة المرور: password
                  </p>
                  <p>
                    <strong>أو:</strong> admin | كلمة المرور: password
                  </p>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="username" className="text-base font-semibold">
                  اسم المستخدم أو البريد الإلكتروني
                </Label>
                <div className="relative">
                  <User className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                  <Input
                    id="username"
                    type="text"
                    placeholder="أدخل اسم المستخدم أو البريد الإلكتروني"
                    className="pr-12 h-12 text-base border-2 focus:border-emerald-500"
                    value={credentials.username}
                    onChange={(e) => setCredentials({ ...credentials, username: e.target.value })}
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="text-base font-semibold">
                  كلمة المرور
                </Label>
                <div className="relative">
                  <Lock className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="أدخل كلمة المرور"
                    className="pr-12 pl-12 h-12 text-base border-2 focus:border-emerald-500"
                    value={credentials.password}
                    onChange={(e) => setCredentials({ ...credentials, password: e.target.value })}
                    required
                  />
                  <button
                    type="button"
                    className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between pt-2">
                <div className="flex items-center space-x-2 space-x-reverse">
                  <Switch
                    id="rememberMe"
                    checked={credentials.rememberMe}
                    onCheckedChange={(checked) => setCredentials({ ...credentials, rememberMe: checked })}
                  />
                  <Label htmlFor="rememberMe" className="text-sm font-medium">
                    تذكرني
                  </Label>
                </div>
                <Button
                  type="button"
                  variant="link"
                  className="text-sm text-emerald-600 hover:text-emerald-700 p-0 font-medium"
                  onClick={() => setShowPasswordReset(true)}
                >
                  نسيت كلمة المرور؟
                </Button>
              </div>

              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-emerald-600 to-blue-600 hover:from-emerald-700 hover:to-blue-700 h-12 text-base font-semibold shadow-lg hover:shadow-xl transition-all duration-200"
                disabled={isLoading}
              >
                {isLoading ? (
                  <div className="flex items-center gap-2">
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                    جاري تسجيل الدخول...
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <LogIn className="h-4 w-4" />
                    تسجيل الدخول
                  </div>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center text-sm text-gray-500">
          <p>© 2025 نظام إدارة المخزون والطلبيات</p>
          <p className="mt-1">جميع الحقوق محفوظة</p>
        </div>
      </div>
    </div>
  )
}
