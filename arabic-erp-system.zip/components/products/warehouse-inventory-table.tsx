"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Plus, Trash2, Edit, Warehouse, Package } from "lucide-react"

interface WarehouseInventory {
  id?: number
  warehouse_id: number
  warehouse_name: string
  floor: string
  area: string
  shelf: string
  quantity: number
  reserved_quantity: number
  available_quantity: number
  min_stock_level: number
  max_stock_level: number
  status: string
}

interface WarehouseInventoryTableProps {
  productId?: number
  onDataChange?: (data: WarehouseInventory[]) => void
  readOnly?: boolean
}

export function WarehouseInventoryTable({ productId, onDataChange, readOnly = false }: WarehouseInventoryTableProps) {
  const [inventoryData, setInventoryData] = useState<WarehouseInventory[]>([])
  const [warehouses, setWarehouses] = useState<Array<{ id: number; name: string }>>([])
  const [editingIndex, setEditingIndex] = useState<number | null>(null)
  const [loading, setLoading] = useState(false)

  const statuses = ["متوفر", "تحت الحد الأدنى", "نفد المخزون", "محجوز", "تالف"]

  useEffect(() => {
    fetchWarehouses()
    if (productId) {
      fetchProductInventory()
    }
  }, [productId])

  const fetchWarehouses = async () => {
    try {
      const response = await fetch("/api/warehouses")
      if (response.ok) {
        const data = await response.json()
        setWarehouses(data)
      }
    } catch (error) {
      console.error("Error fetching warehouses:", error)
    }
  }

  const fetchProductInventory = async () => {
    if (!productId) return

    try {
      setLoading(true)
      const response = await fetch(`/api/inventory/products/${productId}/warehouses`)
      if (response.ok) {
        const data = await response.json()
        setInventoryData(data)
        onDataChange?.(data)
      }
    } catch (error) {
      console.error("Error fetching product inventory:", error)
    } finally {
      setLoading(false)
    }
  }

  const addNewRow = () => {
    const newRow: WarehouseInventory = {
      warehouse_id: 0,
      warehouse_name: "",
      floor: "",
      area: "",
      shelf: "",
      quantity: 0,
      reserved_quantity: 0,
      available_quantity: 0,
      min_stock_level: 0,
      max_stock_level: 0,
      status: "متوفر",
    }

    const newData = [...inventoryData, newRow]
    setInventoryData(newData)
    setEditingIndex(newData.length - 1)
    onDataChange?.(newData)
  }

  const updateRow = (index: number, field: keyof WarehouseInventory, value: any) => {
    const newData = [...inventoryData]
    newData[index] = { ...newData[index], [field]: value }

    // Auto-calculate available quantity
    if (field === "quantity" || field === "reserved_quantity") {
      newData[index].available_quantity = newData[index].quantity - newData[index].reserved_quantity
    }

    // Update warehouse name when warehouse_id changes
    if (field === "warehouse_id") {
      const warehouse = warehouses.find((w) => w.id === Number.parseInt(value))
      newData[index].warehouse_name = warehouse?.name || ""
    }

    setInventoryData(newData)
    onDataChange?.(newData)
  }

  const deleteRow = (index: number) => {
    const newData = inventoryData.filter((_, i) => i !== index)
    setInventoryData(newData)
    onDataChange?.(newData)
    if (editingIndex === index) {
      setEditingIndex(null)
    }
  }

  const saveRow = async (index: number) => {
    if (!productId) {
      setEditingIndex(null)
      return
    }

    try {
      const rowData = inventoryData[index]
      const response = await fetch("/api/inventory/product-warehouses", {
        method: rowData.id ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...rowData,
          product_id: productId,
        }),
      })

      if (response.ok) {
        const savedData = await response.json()
        const newData = [...inventoryData]
        newData[index] = savedData
        setInventoryData(newData)
        onDataChange?.(newData)
      }
    } catch (error) {
      console.error("Error saving warehouse inventory:", error)
    }

    setEditingIndex(null)
  }

  const getStatusBadge = (status: string, quantity: number, minLevel: number) => {
    if (quantity === 0) {
      return <Badge variant="destructive">نفد المخزون</Badge>
    }
    if (quantity <= minLevel) {
      return <Badge className="bg-orange-100 text-orange-800">تحت الحد الأدنى</Badge>
    }
    return <Badge className="bg-green-100 text-green-800">متوفر</Badge>
  }

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Warehouse className="h-5 w-5" />
            تفاصيل المخزون في المستودعات
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Warehouse className="h-5 w-5" />
            تفاصيل المخزون في المستودعات
          </CardTitle>
          {!readOnly && (
            <Button onClick={addNewRow} size="sm" className="flex items-center gap-2">
              <Plus className="h-4 w-4" />
              إضافة مستودع
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent>
        {inventoryData.length === 0 ? (
          <div className="text-center py-8">
            <Package className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-muted-foreground">لا توجد بيانات مخزون في المستودعات</p>
            {!readOnly && (
              <Button onClick={addNewRow} className="mt-4">
                <Plus className="h-4 w-4 mr-2" />
                إضافة مستودع جديد
              </Button>
            )}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-right">المستودع</TableHead>
                  <TableHead className="text-right">الطابق</TableHead>
                  <TableHead className="text-right">المنطقة</TableHead>
                  <TableHead className="text-right">الرف</TableHead>
                  <TableHead className="text-right">الكمية</TableHead>
                  <TableHead className="text-right">محجوز</TableHead>
                  <TableHead className="text-right">متاح</TableHead>
                  <TableHead className="text-right">حد أدنى</TableHead>
                  <TableHead className="text-right">حد أقصى</TableHead>
                  <TableHead className="text-right">الحالة</TableHead>
                  {!readOnly && <TableHead className="text-right">الإجراءات</TableHead>}
                </TableRow>
              </TableHeader>
              <TableBody>
                {inventoryData.map((row, index) => (
                  <TableRow key={index}>
                    <TableCell>
                      {editingIndex === index ? (
                        <Select
                          value={row.warehouse_id.toString()}
                          onValueChange={(value) => updateRow(index, "warehouse_id", Number.parseInt(value))}
                        >
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="اختر المستودع" />
                          </SelectTrigger>
                          <SelectContent>
                            {warehouses.map((warehouse) => (
                              <SelectItem key={warehouse.id} value={warehouse.id.toString()}>
                                {warehouse.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      ) : (
                        row.warehouse_name
                      )}
                    </TableCell>
                    <TableCell>
                      {editingIndex === index ? (
                        <Input
                          value={row.floor}
                          onChange={(e) => updateRow(index, "floor", e.target.value)}
                          className="w-20"
                        />
                      ) : (
                        row.floor
                      )}
                    </TableCell>
                    <TableCell>
                      {editingIndex === index ? (
                        <Input
                          value={row.area}
                          onChange={(e) => updateRow(index, "area", e.target.value)}
                          className="w-20"
                        />
                      ) : (
                        row.area
                      )}
                    </TableCell>
                    <TableCell>
                      {editingIndex === index ? (
                        <Input
                          value={row.shelf}
                          onChange={(e) => updateRow(index, "shelf", e.target.value)}
                          className="w-20"
                        />
                      ) : (
                        row.shelf
                      )}
                    </TableCell>
                    <TableCell>
                      {editingIndex === index ? (
                        <Input
                          type="number"
                          value={row.quantity}
                          onChange={(e) => updateRow(index, "quantity", Number.parseInt(e.target.value) || 0)}
                          className="w-20"
                        />
                      ) : (
                        row.quantity
                      )}
                    </TableCell>
                    <TableCell>
                      {editingIndex === index ? (
                        <Input
                          type="number"
                          value={row.reserved_quantity}
                          onChange={(e) => updateRow(index, "reserved_quantity", Number.parseInt(e.target.value) || 0)}
                          className="w-20"
                        />
                      ) : (
                        row.reserved_quantity
                      )}
                    </TableCell>
                    <TableCell className="font-medium">{row.available_quantity}</TableCell>
                    <TableCell>
                      {editingIndex === index ? (
                        <Input
                          type="number"
                          value={row.min_stock_level}
                          onChange={(e) => updateRow(index, "min_stock_level", Number.parseInt(e.target.value) || 0)}
                          className="w-20"
                        />
                      ) : (
                        row.min_stock_level
                      )}
                    </TableCell>
                    <TableCell>
                      {editingIndex === index ? (
                        <Input
                          type="number"
                          value={row.max_stock_level}
                          onChange={(e) => updateRow(index, "max_stock_level", Number.parseInt(e.target.value) || 0)}
                          className="w-20"
                        />
                      ) : (
                        row.max_stock_level
                      )}
                    </TableCell>
                    <TableCell>
                      {editingIndex === index ? (
                        <Select value={row.status} onValueChange={(value) => updateRow(index, "status", value)}>
                          <SelectTrigger className="w-32">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {statuses.map((status) => (
                              <SelectItem key={status} value={status}>
                                {status}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      ) : (
                        getStatusBadge(row.status, row.quantity, row.min_stock_level)
                      )}
                    </TableCell>
                    {!readOnly && (
                      <TableCell>
                        <div className="flex gap-2">
                          {editingIndex === index ? (
                            <>
                              <Button
                                size="sm"
                                onClick={() => saveRow(index)}
                                className="bg-green-600 hover:bg-green-700"
                              >
                                حفظ
                              </Button>
                              <Button size="sm" variant="outline" onClick={() => setEditingIndex(null)}>
                                إلغاء
                              </Button>
                            </>
                          ) : (
                            <>
                              <Button size="sm" variant="outline" onClick={() => setEditingIndex(index)}>
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => deleteRow(index)}
                                className="text-red-600 hover:text-red-700"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </>
                          )}
                        </div>
                      </TableCell>
                    )}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
