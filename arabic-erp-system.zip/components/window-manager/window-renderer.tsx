"use client"

import type React from "react"
import { useWindowManager } from "@/contexts/window-manager-context"
import { ModalWindow } from "./modal-window"
import { Dashboard } from "@/components/dashboard"
import { SalesOrders } from "@/components/orders/sales-orders"
import { PurchaseOrders } from "@/components/orders/purchase-orders"
import Products from "@/components/products/products"
import Customers from "@/components/products/customers"
import { OrderReports } from "@/components/reports/order-reports"
import { ProductReports } from "@/components/reports/product-reports"
import DocumentSettings from "@/components/settings/document-settings"
import GeneralSettings from "@/components/settings/general-settings"
import PervasiveSettings from "@/app/settings/pervasive/page"

const componentMap: Record<string, React.ComponentType<any>> = {
  dashboard: Dashboard,
  "sales-orders": SalesOrders,
  "purchase-orders": PurchaseOrders,
  products: Products,
  customers: Customers,
  "order-reports": OrderReports,
  "product-reports": ProductReports,
  "document-settings": DocumentSettings,
  "general-settings": GeneralSettings,
  "pervasive-settings": PervasiveSettings,
}

export function WindowRenderer() {
  const { windows } = useWindowManager()

  console.log("[v0] WindowRenderer rendering:", { windowCount: windows.length })

  return (
    <>
      {windows.map((window) => {
        const Component = componentMap[window.component]

        if (!Component) {
          console.warn("[v0] Component not found for:", window.component)
          return null
        }

        if (window.type === "modal") {
          return (
            <ModalWindow key={window.id} window={window}>
              <Component {...(window.data || {})} />
            </ModalWindow>
          )
        }

        return null // Tab windows are rendered in the main content area
      })}
    </>
  )
}
