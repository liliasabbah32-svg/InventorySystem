import { WhatsAppDashboard } from "@/components/whatsapp/whatsapp-dashboard"

export default function WhatsAppPage() {
  return <WhatsAppDashboard />
}
