import { MessagesDashboard } from "@/components/messaging/messages-dashboard"

export default function MessagesDashboardPage() {
  return <MessagesDashboard />
}
