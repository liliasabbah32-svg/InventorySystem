import { type NextRequest, NextResponse } from "next/server"
import { neon } from "@neondatabase/serverless"

const sql = neon(process.env.DATABASE_URL!)

export async function GET(request: NextRequest) {
  try {
    const settings = await sql`
      SELECT * FROM print_settings 
      WHERE company_id = 1
      ORDER BY id
      LIMIT 1
    `

    // Return first record or default values if none exists
    const result = settings[0] || {
      company_id: 1,
      paper_size: "A4",
      orientation: "portrait",
      margin_top: 20,
      margin_bottom: 20,
      margin_left: 20,
      margin_right: 20,
      show_header: true,
      show_footer: true,
      show_logo: true,
      show_company_info: true,
      show_page_numbers: true,
      show_print_date: true,
      show_payment_terms: true,
      show_bank_details: true,
      font_family: "Arial",
      font_size: 12,
      primary_color: "#000000",
      secondary_color: "#666666",
      use_colors: false,
      print_copies: 1,
      auto_print: false,
      default_printer: "",
      invoice_template: "standard",
      logo_position: "top-left",
      logo_size: "medium",
      header_text: "",
      footer_text: "",
    }

    return NextResponse.json(result)
  } catch (error) {
    console.error("Database query error:", error)
    return NextResponse.json({ error: "Failed to fetch print settings" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()

    const existingSettings = await sql`
      SELECT id FROM print_settings 
      WHERE company_id = 1
      LIMIT 1
    `

    if (existingSettings.length > 0) {
      const result = await sql`
        UPDATE print_settings 
        SET 
          paper_size = ${data.paper_size || "A4"},
          orientation = ${data.orientation || "portrait"},
          margin_top = ${data.margin_top || 20},
          margin_bottom = ${data.margin_bottom || 20},
          margin_left = ${data.margin_left || 20},
          margin_right = ${data.margin_right || 20},
          show_header = ${data.show_header !== undefined ? data.show_header : true},
          show_footer = ${data.show_footer !== undefined ? data.show_footer : true},
          show_logo = ${data.show_logo !== undefined ? data.show_logo : true},
          show_company_info = ${data.show_company_info !== undefined ? data.show_company_info : true},
          show_page_numbers = ${data.show_page_numbers !== undefined ? data.show_page_numbers : true},
          show_print_date = ${data.show_print_date !== undefined ? data.show_print_date : true},
          show_payment_terms = ${data.show_payment_terms !== undefined ? data.show_payment_terms : true},
          show_bank_details = ${data.show_bank_details !== undefined ? data.show_bank_details : true},
          font_family = ${data.font_family || "Arial"},
          font_size = ${data.font_size || 12},
          primary_color = ${data.primary_color || "#000000"},
          secondary_color = ${data.secondary_color || "#666666"},
          use_colors = ${data.use_colors !== undefined ? data.use_colors : false},
          print_copies = ${data.print_copies || 1},
          auto_print = ${data.auto_print !== undefined ? data.auto_print : false},
          default_printer = ${data.default_printer || ""},
          invoice_template = ${data.invoice_template || "standard"},
          logo_position = ${data.logo_position || "top-left"},
          logo_size = ${data.logo_size || "medium"},
          header_text = ${data.header_text || ""},
          footer_text = ${data.footer_text || ""},
          updated_at = CURRENT_TIMESTAMP
        WHERE company_id = 1
        RETURNING *
      `
      return NextResponse.json(result[0])
    } else {
      const result = await sql`
        INSERT INTO print_settings (
          company_id, paper_size, orientation,
          margin_top, margin_bottom, margin_left, margin_right,
          show_header, show_footer, show_logo, show_company_info,
          show_page_numbers, show_print_date, show_payment_terms, show_bank_details,
          font_family, font_size, primary_color, secondary_color, use_colors,
          print_copies, auto_print, default_printer, invoice_template,
          logo_position, logo_size, header_text, footer_text,
          created_at, updated_at
        ) VALUES (
          1, ${data.paper_size || "A4"}, ${data.orientation || "portrait"},
          ${data.margin_top || 20}, ${data.margin_bottom || 20}, 
          ${data.margin_left || 20}, ${data.margin_right || 20},
          ${data.show_header !== undefined ? data.show_header : true}, 
          ${data.show_footer !== undefined ? data.show_footer : true},
          ${data.show_logo !== undefined ? data.show_logo : true}, 
          ${data.show_company_info !== undefined ? data.show_company_info : true},
          ${data.show_page_numbers !== undefined ? data.show_page_numbers : true},
          ${data.show_print_date !== undefined ? data.show_print_date : true},
          ${data.show_payment_terms !== undefined ? data.show_payment_terms : true},
          ${data.show_bank_details !== undefined ? data.show_bank_details : true},
          ${data.font_family || "Arial"}, ${data.font_size || 12}, 
          ${data.primary_color || "#000000"}, ${data.secondary_color || "#666666"},
          ${data.use_colors !== undefined ? data.use_colors : false},
          ${data.print_copies || 1}, 
          ${data.auto_print !== undefined ? data.auto_print : false},
          ${data.default_printer || ""}, ${data.invoice_template || "standard"},
          ${data.logo_position || "top-left"}, ${data.logo_size || "medium"},
          ${data.header_text || ""}, ${data.footer_text || ""},
          CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
        )
        RETURNING *
      `
      return NextResponse.json(result[0])
    }
  } catch (error) {
    console.error("Database operation error:", error)
    return NextResponse.json({ error: "Failed to save print settings" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    const data = await request.json()

    const result = await sql`
      UPDATE print_settings 
      SET 
        paper_size = ${data.paper_size},
        orientation = ${data.orientation},
        margin_top = ${data.margin_top},
        margin_bottom = ${data.margin_bottom},
        margin_left = ${data.margin_left},
        margin_right = ${data.margin_right},
        show_header = ${data.show_header},
        show_footer = ${data.show_footer},
        show_logo = ${data.show_logo},
        show_company_info = ${data.show_company_info},
        show_page_numbers = ${data.show_page_numbers},
        show_print_date = ${data.show_print_date},
        show_payment_terms = ${data.show_payment_terms},
        show_bank_details = ${data.show_bank_details},
        font_family = ${data.font_family},
        font_size = ${data.font_size},
        primary_color = ${data.primary_color},
        secondary_color = ${data.secondary_color},
        use_colors = ${data.use_colors},
        print_copies = ${data.print_copies},
        auto_print = ${data.auto_print},
        default_printer = ${data.default_printer},
        invoice_template = ${data.invoice_template},
        logo_position = ${data.logo_position},
        logo_size = ${data.logo_size},
        header_text = ${data.header_text},
        footer_text = ${data.footer_text},
        updated_at = CURRENT_TIMESTAMP
      WHERE company_id = 1
      RETURNING *
    `

    return NextResponse.json(result[0])
  } catch (error) {
    console.error("Database update error:", error)
    return NextResponse.json({ error: "Failed to update print settings" }, { status: 500 })
  }
}
