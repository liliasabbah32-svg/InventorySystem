import { type NextRequest, NextResponse } from "next/server"
import { neon } from "@neondatabase/serverless"
import { generateCustomerNumber } from "@/lib/number-generator"

const sql = neon(process.env.DATABASE_URL!)

export async function POST(request: NextRequest) {
  try {
    const { data } = await request.json()

    if (!Array.isArray(data) || data.length === 0) {
      return NextResponse.json({ error: "لا توجد بيانات للاستيراد" }, { status: 400 })
    }

    let success = 0
    let failed = 0
    let duplicates = 0
    const errors: string[] = []

    for (const item of data) {
      try {
        // Check for required fields
        if (!item.customer_name) {
          errors.push(`السطر ${data.indexOf(item) + 1}: اسم الزبون مطلوب`)
          failed++
          continue
        }

        // Generate customer code if not provided
        let customerCode = item.customer_code
        if (!customerCode) {
          customerCode = await generateCustomerNumber()
        }

        // Check for duplicates
        const existing = await sql`
          SELECT id FROM customers WHERE customer_code = ${customerCode}
        `

        if (existing.length > 0) {
          duplicates++
          continue
        }

        // Insert the customer
        await sql`
          INSERT INTO customers (
            customer_code, customer_name, phone1, phone2, whatsapp1,
            city, address, email, status, classification,
            account_opening_date, api_key
          ) VALUES (
            ${customerCode},
            ${item.customer_name},
            ${item.phone1 || ""},
            ${item.phone2 || ""},
            ${item.whatsapp1 || ""},
            ${item.city || ""},
            ${item.address || ""},
            ${item.email || ""},
            ${item.status || "نشط"},
            ${item.classification || "عادي"},
            ${new Date().toISOString()},
            ${`API_${customerCode}_${Date.now()}`}
          )
        `
        success++
      } catch (error) {
        console.error(`Error importing customer ${item.customer_name}:`, error)
        errors.push(`السطر ${data.indexOf(item) + 1}: ${error.message}`)
        failed++
      }
    }

    return NextResponse.json({
      success,
      failed,
      duplicates,
      errors: errors.slice(0, 10),
    })
  } catch (error) {
    console.error("Error importing customers:", error)
    return NextResponse.json({ error: "خطأ في استيراد الزبائن" }, { status: 500 })
  }
}
