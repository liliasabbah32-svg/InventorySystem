import { type NextRequest, NextResponse } from "next/server"
import { neon } from "@neondatabase/serverless"
import { createLotTransaction, changeLotStatus } from "@/lib/lot-management"

const sql = neon(process.env.DATABASE_URL!)

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const productId = searchParams.get("product_id")
    const lotNumber = searchParams.get("lot_number")
    const transactionType = searchParams.get("transaction_type")
    const dateFrom = searchParams.get("date_from")
    const dateTo = searchParams.get("date_to")
    const limit = searchParams.get("limit") || "100"

    console.log("[v0] Batch movements API called with params:", {
      productId,
      lotNumber,
      transactionType,
      dateFrom,
      dateTo,
      limit,
    })

    const limitValue = Number.parseInt(limit)

    // Build base query
    let result

    // Apply filters conditionally
    if (productId && productId !== "all") {
      const productIdNum = Number.parseInt(productId)

      if (lotNumber && transactionType && transactionType !== "all" && dateFrom && dateTo) {
        // All filters
        result = await sql`
          SELECT 
            lt.id,
            lt.lot_id,
            pl.lot_number,
            pl.product_id,
            p.product_name,
            p.product_code,
            lt.transaction_type,
            lt.quantity,
            lt.reference_type,
            lt.reference_id,
            lt.unit_cost,
            lt.notes,
            lt.created_by,
            lt.created_at,
            CASE 
              WHEN lt.transaction_type = 'status_change' THEN
                SPLIT_PART(lt.notes, ' إلى ', 1)
            END as old_status,
            CASE 
              WHEN lt.transaction_type = 'status_change' THEN
                SPLIT_PART(lt.notes, ' إلى ', 2)
            END as new_status
          FROM lot_transactions lt
          JOIN product_lots pl ON lt.lot_id = pl.id
          JOIN products p ON pl.product_id = p.id
          WHERE pl.product_id = ${productIdNum}
            AND pl.lot_number ILIKE ${`%${lotNumber}%`}
            AND lt.transaction_type = ${transactionType}
            AND lt.created_at >= ${dateFrom}
            AND lt.created_at <= ${dateTo}::date + INTERVAL '1 day'
          ORDER BY lt.created_at DESC 
          LIMIT ${limitValue}
        `
      } else if (lotNumber && transactionType && transactionType !== "all" && dateFrom) {
        result = await sql`
          SELECT 
            lt.id,
            lt.lot_id,
            pl.lot_number,
            pl.product_id,
            p.product_name,
            p.product_code,
            lt.transaction_type,
            lt.quantity,
            lt.reference_type,
            lt.reference_id,
            lt.unit_cost,
            lt.notes,
            lt.created_by,
            lt.created_at,
            CASE 
              WHEN lt.transaction_type = 'status_change' THEN
                SPLIT_PART(lt.notes, ' إلى ', 1)
            END as old_status,
            CASE 
              WHEN lt.transaction_type = 'status_change' THEN
                SPLIT_PART(lt.notes, ' إلى ', 2)
            END as new_status
          FROM lot_transactions lt
          JOIN product_lots pl ON lt.lot_id = pl.id
          JOIN products p ON pl.product_id = p.id
          WHERE pl.product_id = ${productIdNum}
            AND pl.lot_number ILIKE ${`%${lotNumber}%`}
            AND lt.transaction_type = ${transactionType}
            AND lt.created_at >= ${dateFrom}
          ORDER BY lt.created_at DESC 
          LIMIT ${limitValue}
        `
      } else if (lotNumber && transactionType && transactionType !== "all") {
        result = await sql`
          SELECT 
            lt.id,
            lt.lot_id,
            pl.lot_number,
            pl.product_id,
            p.product_name,
            p.product_code,
            lt.transaction_type,
            lt.quantity,
            lt.reference_type,
            lt.reference_id,
            lt.unit_cost,
            lt.notes,
            lt.created_by,
            lt.created_at,
            CASE 
              WHEN lt.transaction_type = 'status_change' THEN
                SPLIT_PART(lt.notes, ' إلى ', 1)
            END as old_status,
            CASE 
              WHEN lt.transaction_type = 'status_change' THEN
                SPLIT_PART(lt.notes, ' إلى ', 2)
            END as new_status
          FROM lot_transactions lt
          JOIN product_lots pl ON lt.lot_id = pl.id
          JOIN products p ON pl.product_id = p.id
          WHERE pl.product_id = ${productIdNum}
            AND pl.lot_number ILIKE ${`%${lotNumber}%`}
            AND lt.transaction_type = ${transactionType}
          ORDER BY lt.created_at DESC 
          LIMIT ${limitValue}
        `
      } else if (lotNumber && dateFrom && dateTo) {
        result = await sql`
          SELECT 
            lt.id,
            lt.lot_id,
            pl.lot_number,
            pl.product_id,
            p.product_name,
            p.product_code,
            lt.transaction_type,
            lt.quantity,
            lt.reference_type,
            lt.reference_id,
            lt.unit_cost,
            lt.notes,
            lt.created_by,
            lt.created_at,
            CASE 
              WHEN lt.transaction_type = 'status_change' THEN
                SPLIT_PART(lt.notes, ' إلى ', 1)
            END as old_status,
            CASE 
              WHEN lt.transaction_type = 'status_change' THEN
                SPLIT_PART(lt.notes, ' إلى ', 2)
            END as new_status
          FROM lot_transactions lt
          JOIN product_lots pl ON lt.lot_id = pl.id
          JOIN products p ON pl.product_id = p.id
          WHERE pl.product_id = ${productIdNum}
            AND pl.lot_number ILIKE ${`%${lotNumber}%`}
            AND lt.created_at >= ${dateFrom}
            AND lt.created_at <= ${dateTo}::date + INTERVAL '1 day'
          ORDER BY lt.created_at DESC 
          LIMIT ${limitValue}
        `
      } else if (lotNumber && dateFrom) {
        result = await sql`
          SELECT 
            lt.id,
            lt.lot_id,
            pl.lot_number,
            pl.product_id,
            p.product_name,
            p.product_code,
            lt.transaction_type,
            lt.quantity,
            lt.reference_type,
            lt.reference_id,
            lt.unit_cost,
            lt.notes,
            lt.created_by,
            lt.created_at,
            CASE 
              WHEN lt.transaction_type = 'status_change' THEN
                SPLIT_PART(lt.notes, ' إلى ', 1)
            END as old_status,
            CASE 
              WHEN lt.transaction_type = 'status_change' THEN
                SPLIT_PART(lt.notes, ' إلى ', 2)
            END as new_status
          FROM lot_transactions lt
          JOIN product_lots pl ON lt.lot_id = pl.id
          JOIN products p ON pl.product_id = p.id
          WHERE pl.product_id = ${productIdNum}
            AND pl.lot_number ILIKE ${`%${lotNumber}%`}
            AND lt.created_at >= ${dateFrom}
          ORDER BY lt.created_at DESC 
          LIMIT ${limitValue}
        `
      } else if (lotNumber) {
        result = await sql`
          SELECT 
            lt.id,
            lt.lot_id,
            pl.lot_number,
            pl.product_id,
            p.product_name,
            p.product_code,
            lt.transaction_type,
            lt.quantity,
            lt.reference_type,
            lt.reference_id,
            lt.unit_cost,
            lt.notes,
            lt.created_by,
            lt.created_at,
            CASE 
              WHEN lt.transaction_type = 'status_change' THEN
                SPLIT_PART(lt.notes, ' إلى ', 1)
            END as old_status,
            CASE 
              WHEN lt.transaction_type = 'status_change' THEN
                SPLIT_PART(lt.notes, ' إلى ', 2)
            END as new_status
          FROM lot_transactions lt
          JOIN product_lots pl ON lt.lot_id = pl.id
          JOIN products p ON pl.product_id = p.id
          WHERE pl.product_id = ${productIdNum}
            AND pl.lot_number ILIKE ${`%${lotNumber}%`}
          ORDER BY lt.created_at DESC 
          LIMIT ${limitValue}
        `
      } else if (transactionType && transactionType !== "all" && dateFrom && dateTo) {
        result = await sql`
          SELECT 
            lt.id,
            lt.lot_id,
            pl.lot_number,
            pl.product_id,
            p.product_name,
            p.product_code,
            lt.transaction_type,
            lt.quantity,
            lt.reference_type,
            lt.reference_id,
            lt.unit_cost,
            lt.notes,
            lt.created_by,
            lt.created_at,
            CASE 
              WHEN lt.transaction_type = 'status_change' THEN
                SPLIT_PART(lt.notes, ' إلى ', 1)
            END as old_status,
            CASE 
              WHEN lt.transaction_type = 'status_change' THEN
                SPLIT_PART(lt.notes, ' إلى ', 2)
            END as new_status
          FROM lot_transactions lt
          JOIN product_lots pl ON lt.lot_id = pl.id
          JOIN products p ON pl.product_id = p.id
          WHERE lt.transaction_type = ${transactionType}
            AND lt.created_at >= ${dateFrom}
            AND lt.created_at <= ${dateTo}::date + INTERVAL '1 day'
          ORDER BY lt.created_at DESC 
          LIMIT ${limitValue}
        `
      } else if (transactionType && transactionType !== "all" && dateFrom) {
        result = await sql`
          SELECT 
            lt.id,
            lt.lot_id,
            pl.lot_number,
            pl.product_id,
            p.product_name,
            p.product_code,
            lt.transaction_type,
            lt.quantity,
            lt.reference_type,
            lt.reference_id,
            lt.unit_cost,
            lt.notes,
            lt.created_by,
            lt.created_at,
            CASE 
              WHEN lt.transaction_type = 'status_change' THEN
                SPLIT_PART(lt.notes, ' إلى ', 1)
            END as old_status,
            CASE 
              WHEN lt.transaction_type = 'status_change' THEN
                SPLIT_PART(lt.notes, ' إلى ', 2)
            END as new_status
          FROM lot_transactions lt
          JOIN product_lots pl ON lt.lot_id = pl.id
          JOIN products p ON pl.product_id = p.id
          WHERE lt.transaction_type = ${transactionType}
            AND lt.created_at >= ${dateFrom}
          ORDER BY lt.created_at DESC 
          LIMIT ${limitValue}
        `
      } else if (transactionType && transactionType !== "all") {
        result = await sql`
          SELECT 
            lt.id,
            lt.lot_id,
            pl.lot_number,
            pl.product_id,
            p.product_name,
            p.product_code,
            lt.transaction_type,
            lt.quantity,
            lt.reference_type,
            lt.reference_id,
            lt.unit_cost,
            lt.notes,
            lt.created_by,
            lt.created_at,
            CASE 
              WHEN lt.transaction_type = 'status_change' THEN
                SPLIT_PART(lt.notes, ' إلى ', 1)
            END as old_status,
            CASE 
              WHEN lt.transaction_type = 'status_change' THEN
                SPLIT_PART(lt.notes, ' إلى ', 2)
            END as new_status
          FROM lot_transactions lt
          JOIN product_lots pl ON lt.lot_id = pl.id
          JOIN products p ON pl.product_id = p.id
          WHERE lt.transaction_type = ${transactionType}
          ORDER BY lt.created_at DESC 
          LIMIT ${limitValue}
        `
      } else if (dateFrom && dateTo) {
        result = await sql`
          SELECT 
            lt.id,
            lt.lot_id,
            pl.lot_number,
            pl.product_id,
            p.product_name,
            p.product_code,
            lt.transaction_type,
            lt.quantity,
            lt.reference_type,
            lt.reference_id,
            lt.unit_cost,
            lt.notes,
            lt.created_by,
            lt.created_at,
            CASE 
              WHEN lt.transaction_type = 'status_change' THEN
                SPLIT_PART(lt.notes, ' إلى ', 1)
            END as old_status,
            CASE 
              WHEN lt.transaction_type = 'status_change' THEN
                SPLIT_PART(lt.notes, ' إلى ', 2)
            END as new_status
          FROM lot_transactions lt
          JOIN product_lots pl ON lt.lot_id = pl.id
          JOIN products p ON pl.product_id = p.id
          WHERE lt.created_at >= ${dateFrom}
            AND lt.created_at <= ${dateTo}::date + INTERVAL '1 day'
          ORDER BY lt.created_at DESC 
          LIMIT ${limitValue}
        `
      } else if (dateFrom) {
        result = await sql`
          SELECT 
            lt.id,
            lt.lot_id,
            pl.lot_number,
            pl.product_id,
            p.product_name,
            p.product_code,
            lt.transaction_type,
            lt.quantity,
            lt.reference_type,
            lt.reference_id,
            lt.unit_cost,
            lt.notes,
            lt.created_by,
            lt.created_at,
            CASE 
              WHEN lt.transaction_type = 'status_change' THEN
                SPLIT_PART(lt.notes, ' إلى ', 1)
            END as old_status,
            CASE 
              WHEN lt.transaction_type = 'status_change' THEN
                SPLIT_PART(lt.notes, ' إلى ', 2)
            END as new_status
          FROM lot_transactions lt
          JOIN product_lots pl ON lt.lot_id = pl.id
          JOIN products p ON pl.product_id = p.id
          WHERE lt.created_at >= ${dateFrom}
          ORDER BY lt.created_at DESC 
          LIMIT ${limitValue}
        `
      } else {
        // No filters - get all
        result = await sql`
          SELECT 
            lt.id,
            lt.lot_id,
            pl.lot_number,
            pl.product_id,
            p.product_name,
            p.product_code,
            lt.transaction_type,
            lt.quantity,
            lt.reference_type,
            lt.reference_id,
            lt.unit_cost,
            lt.notes,
            lt.created_by,
            lt.created_at,
            CASE 
              WHEN lt.transaction_type = 'status_change' THEN
                SPLIT_PART(lt.notes, ' إلى ', 1)
            END as old_status,
            CASE 
              WHEN lt.transaction_type = 'status_change' THEN
                SPLIT_PART(lt.notes, ' إلى ', 2)
            END as new_status
          FROM lot_transactions lt
          JOIN product_lots pl ON lt.lot_id = pl.id
          JOIN products p ON pl.product_id = p.id
          ORDER BY lt.created_at DESC 
          LIMIT ${limitValue}
        `
      }
    } else if (lotNumber && transactionType && transactionType !== "all" && dateFrom && dateTo) {
      result = await sql`
        SELECT 
          lt.id,
          lt.lot_id,
          pl.lot_number,
          pl.product_id,
          p.product_name,
          p.product_code,
          lt.transaction_type,
          lt.quantity,
          lt.reference_type,
          lt.reference_id,
          lt.unit_cost,
          lt.notes,
          lt.created_by,
          lt.created_at,
          CASE 
            WHEN lt.transaction_type = 'status_change' THEN
              SPLIT_PART(lt.notes, ' إلى ', 1)
          END as old_status,
          CASE 
            WHEN lt.transaction_type = 'status_change' THEN
              SPLIT_PART(lt.notes, ' إلى ', 2)
          END as new_status
        FROM lot_transactions lt
        JOIN product_lots pl ON lt.lot_id = pl.id
        JOIN products p ON pl.product_id = p.id
        WHERE pl.lot_number ILIKE ${`%${lotNumber}%`}
          AND lt.transaction_type = ${transactionType}
          AND lt.created_at >= ${dateFrom}
          AND lt.created_at <= ${dateTo}::date + INTERVAL '1 day'
        ORDER BY lt.created_at DESC 
        LIMIT ${limitValue}
      `
    } else if (lotNumber && transactionType && transactionType !== "all" && dateFrom) {
      result = await sql`
        SELECT 
          lt.id,
          lt.lot_id,
          pl.lot_number,
          pl.product_id,
          p.product_name,
          p.product_code,
          lt.transaction_type,
          lt.quantity,
          lt.reference_type,
          lt.reference_id,
          lt.unit_cost,
          lt.notes,
          lt.created_by,
          lt.created_at,
          CASE 
            WHEN lt.transaction_type = 'status_change' THEN
              SPLIT_PART(lt.notes, ' إلى ', 1)
          END as old_status,
          CASE 
            WHEN lt.transaction_type = 'status_change' THEN
              SPLIT_PART(lt.notes, ' إلى ', 2)
          END as new_status
        FROM lot_transactions lt
        JOIN product_lots pl ON lt.lot_id = pl.id
        JOIN products p ON pl.product_id = p.id
        WHERE pl.lot_number ILIKE ${`%${lotNumber}%`}
          AND lt.transaction_type = ${transactionType}
          AND lt.created_at >= ${dateFrom}
        ORDER BY lt.created_at DESC 
        LIMIT ${limitValue}
      `
    } else if (lotNumber && transactionType && transactionType !== "all") {
      result = await sql`
        SELECT 
          lt.id,
          lt.lot_id,
          pl.lot_number,
          pl.product_id,
          p.product_name,
          p.product_code,
          lt.transaction_type,
          lt.quantity,
          lt.reference_type,
          lt.reference_id,
          lt.unit_cost,
          lt.notes,
          lt.created_by,
          lt.created_at,
          CASE 
            WHEN lt.transaction_type = 'status_change' THEN
              SPLIT_PART(lt.notes, ' إلى ', 1)
          END as old_status,
          CASE 
            WHEN lt.transaction_type = 'status_change' THEN
              SPLIT_PART(lt.notes, ' إلى ', 2)
          END as new_status
        FROM lot_transactions lt
        JOIN product_lots pl ON lt.lot_id = pl.id
        JOIN products p ON pl.product_id = p.id
        WHERE pl.lot_number ILIKE ${`%${lotNumber}%`}
          AND lt.transaction_type = ${transactionType}
        ORDER BY lt.created_at DESC 
        LIMIT ${limitValue}
      `
    } else if (lotNumber && dateFrom && dateTo) {
      result = await sql`
        SELECT 
          lt.id,
          lt.lot_id,
          pl.lot_number,
          pl.product_id,
          p.product_name,
          p.product_code,
          lt.transaction_type,
          lt.quantity,
          lt.reference_type,
          lt.reference_id,
          lt.unit_cost,
          lt.notes,
          lt.created_by,
          lt.created_at,
          CASE 
            WHEN lt.transaction_type = 'status_change' THEN
              SPLIT_PART(lt.notes, ' إلى ', 1)
          END as old_status,
          CASE 
            WHEN lt.transaction_type = 'status_change' THEN
              SPLIT_PART(lt.notes, ' إلى ', 2)
          END as new_status
        FROM lot_transactions lt
        JOIN product_lots pl ON lt.lot_id = pl.id
        JOIN products p ON pl.product_id = p.id
        WHERE pl.lot_number ILIKE ${`%${lotNumber}%`}
          AND lt.created_at >= ${dateFrom}
          AND lt.created_at <= ${dateTo}::date + INTERVAL '1 day'
        ORDER BY lt.created_at DESC 
        LIMIT ${limitValue}
      `
    } else if (lotNumber && dateFrom) {
      result = await sql`
        SELECT 
          lt.id,
          lt.lot_id,
          pl.lot_number,
          pl.product_id,
          p.product_name,
          p.product_code,
          lt.transaction_type,
          lt.quantity,
          lt.reference_type,
          lt.reference_id,
          lt.unit_cost,
          lt.notes,
          lt.created_by,
          lt.created_at,
          CASE 
            WHEN lt.transaction_type = 'status_change' THEN
              SPLIT_PART(lt.notes, ' إلى ', 1)
          END as old_status,
          CASE 
            WHEN lt.transaction_type = 'status_change' THEN
              SPLIT_PART(lt.notes, ' إلى ', 2)
          END as new_status
        FROM lot_transactions lt
        JOIN product_lots pl ON lt.lot_id = pl.id
        JOIN products p ON pl.product_id = p.id
        WHERE pl.lot_number ILIKE ${`%${lotNumber}%`}
          AND lt.created_at >= ${dateFrom}
        ORDER BY lt.created_at DESC 
        LIMIT ${limitValue}
      `
    } else if (lotNumber) {
      result = await sql`
        SELECT 
          lt.id,
          lt.lot_id,
          pl.lot_number,
          pl.product_id,
          p.product_name,
          p.product_code,
          lt.transaction_type,
          lt.quantity,
          lt.reference_type,
          lt.reference_id,
          lt.unit_cost,
          lt.notes,
          lt.created_by,
          lt.created_at,
          CASE 
            WHEN lt.transaction_type = 'status_change' THEN
              SPLIT_PART(lt.notes, ' إلى ', 1)
          END as old_status,
          CASE 
            WHEN lt.transaction_type = 'status_change' THEN
              SPLIT_PART(lt.notes, ' إلى ', 2)
          END as new_status
        FROM lot_transactions lt
        JOIN product_lots pl ON lt.lot_id = pl.id
        JOIN products p ON pl.product_id = p.id
        WHERE pl.lot_number ILIKE ${`%${lotNumber}%`}
        ORDER BY lt.created_at DESC 
        LIMIT ${limitValue}
      `
    } else if (transactionType && transactionType !== "all" && dateFrom && dateTo) {
      result = await sql`
        SELECT 
          lt.id,
          lt.lot_id,
          pl.lot_number,
          pl.product_id,
          p.product_name,
          p.product_code,
          lt.transaction_type,
          lt.quantity,
          lt.reference_type,
          lt.reference_id,
          lt.unit_cost,
          lt.notes,
          lt.created_by,
          lt.created_at,
          CASE 
            WHEN lt.transaction_type = 'status_change' THEN
              SPLIT_PART(lt.notes, ' إلى ', 1)
          END as old_status,
          CASE 
            WHEN lt.transaction_type = 'status_change' THEN
              SPLIT_PART(lt.notes, ' إلى ', 2)
          END as new_status
        FROM lot_transactions lt
        JOIN product_lots pl ON lt.lot_id = pl.id
        JOIN products p ON pl.product_id = p.id
        WHERE lt.transaction_type = ${transactionType}
          AND lt.created_at >= ${dateFrom}
          AND lt.created_at <= ${dateTo}::date + INTERVAL '1 day'
        ORDER BY lt.created_at DESC 
        LIMIT ${limitValue}
      `
    } else if (transactionType && transactionType !== "all" && dateFrom) {
      result = await sql`
        SELECT 
          lt.id,
          lt.lot_id,
          pl.lot_number,
          pl.product_id,
          p.product_name,
          p.product_code,
          lt.transaction_type,
          lt.quantity,
          lt.reference_type,
          lt.reference_id,
          lt.unit_cost,
          lt.notes,
          lt.created_by,
          lt.created_at,
          CASE 
            WHEN lt.transaction_type = 'status_change' THEN
              SPLIT_PART(lt.notes, ' إلى ', 1)
          END as old_status,
          CASE 
            WHEN lt.transaction_type = 'status_change' THEN
              SPLIT_PART(lt.notes, ' إلى ', 2)
          END as new_status
        FROM lot_transactions lt
        JOIN product_lots pl ON lt.lot_id = pl.id
        JOIN products p ON pl.product_id = p.id
        WHERE lt.transaction_type = ${transactionType}
          AND lt.created_at >= ${dateFrom}
        ORDER BY lt.created_at DESC 
        LIMIT ${limitValue}
      `
    } else if (transactionType && transactionType !== "all") {
      result = await sql`
        SELECT 
          lt.id,
          lt.lot_id,
          pl.lot_number,
          pl.product_id,
          p.product_name,
          p.product_code,
          lt.transaction_type,
          lt.quantity,
          lt.reference_type,
          lt.reference_id,
          lt.unit_cost,
          lt.notes,
          lt.created_by,
          lt.created_at,
          CASE 
            WHEN lt.transaction_type = 'status_change' THEN
              SPLIT_PART(lt.notes, ' إلى ', 1)
          END as old_status,
          CASE 
            WHEN lt.transaction_type = 'status_change' THEN
              SPLIT_PART(lt.notes, ' إلى ', 2)
          END as new_status
        FROM lot_transactions lt
        JOIN product_lots pl ON lt.lot_id = pl.id
        JOIN products p ON pl.product_id = p.id
        WHERE lt.transaction_type = ${transactionType}
        ORDER BY lt.created_at DESC 
        LIMIT ${limitValue}
      `
    } else if (dateFrom && dateTo) {
      result = await sql`
        SELECT 
          lt.id,
          lt.lot_id,
          pl.lot_number,
          pl.product_id,
          p.product_name,
          p.product_code,
          lt.transaction_type,
          lt.quantity,
          lt.reference_type,
          lt.reference_id,
          lt.unit_cost,
          lt.notes,
          lt.created_by,
          lt.created_at,
          CASE 
            WHEN lt.transaction_type = 'status_change' THEN
              SPLIT_PART(lt.notes, ' إلى ', 1)
          END as old_status,
          CASE 
            WHEN lt.transaction_type = 'status_change' THEN
              SPLIT_PART(lt.notes, ' إلى ', 2)
          END as new_status
        FROM lot_transactions lt
        JOIN product_lots pl ON lt.lot_id = pl.id
        JOIN products p ON pl.product_id = p.id
        WHERE lt.created_at >= ${dateFrom}
          AND lt.created_at <= ${dateTo}::date + INTERVAL '1 day'
        ORDER BY lt.created_at DESC 
        LIMIT ${limitValue}
      `
    } else if (dateFrom) {
      result = await sql`
        SELECT 
          lt.id,
          lt.lot_id,
          pl.lot_number,
          pl.product_id,
          p.product_name,
          p.product_code,
          lt.transaction_type,
          lt.quantity,
          lt.reference_type,
          lt.reference_id,
          lt.unit_cost,
          lt.notes,
          lt.created_by,
          lt.created_at,
          CASE 
            WHEN lt.transaction_type = 'status_change' THEN
              SPLIT_PART(lt.notes, ' إلى ', 1)
          END as old_status,
          CASE 
            WHEN lt.transaction_type = 'status_change' THEN
              SPLIT_PART(lt.notes, ' إلى ', 2)
          END as new_status
        FROM lot_transactions lt
        JOIN product_lots pl ON lt.lot_id = pl.id
        JOIN products p ON pl.product_id = p.id
        WHERE lt.created_at >= ${dateFrom}
        ORDER BY lt.created_at DESC 
        LIMIT ${limitValue}
      `
    } else {
      // No filters - get all
      result = await sql`
        SELECT 
          lt.id,
          lt.lot_id,
          pl.lot_number,
          pl.product_id,
          p.product_name,
          p.product_code,
          lt.transaction_type,
          lt.quantity,
          lt.reference_type,
          lt.reference_id,
          lt.unit_cost,
          lt.notes,
          lt.created_by,
          lt.created_at,
          CASE 
            WHEN lt.transaction_type = 'status_change' THEN
              SPLIT_PART(lt.notes, ' إلى ', 1)
          END as old_status,
          CASE 
            WHEN lt.transaction_type = 'status_change' THEN
              SPLIT_PART(lt.notes, ' إلى ', 2)
          END as new_status
        FROM lot_transactions lt
        JOIN product_lots pl ON lt.lot_id = pl.id
        JOIN products p ON pl.product_id = p.id
        ORDER BY lt.created_at DESC 
        LIMIT ${limitValue}
      `
    }

    console.log("[v0] Query result:", result?.length || 0, "rows")

    const movements = Array.isArray(result) ? result : []

    return NextResponse.json(movements)
  } catch (error) {
    console.error("[v0] Error fetching batch movements:", error)
    return NextResponse.json({ error: "فشل في تحميل حركات الدفعات" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    const requiredFields = ["lot_id", "transaction_type"]
    for (const field of requiredFields) {
      if (!body[field]) {
        return NextResponse.json({ error: `الحقل ${field} مطلوب` }, { status: 400 })
      }
    }

    // Validate quantity for non-status-change transactions
    if (body.transaction_type !== "status_change" && (!body.quantity || body.quantity <= 0)) {
      return NextResponse.json({ error: "الكمية مطلوبة ويجب أن تكون أكبر من صفر" }, { status: 400 })
    }

    // Validate new status for status change transactions
    if (body.transaction_type === "status_change" && !body.new_status) {
      return NextResponse.json({ error: "الحالة الجديدة مطلوبة لتغيير الحالة" }, { status: 400 })
    }

    const lotId = Number.parseInt(body.lot_id)

    // Get current lot information
    const lotInfo = await sql`
      SELECT pl.*, p.product_name, p.product_code
      FROM product_lots pl
      JOIN products p ON pl.product_id = p.id
      WHERE pl.id = ${lotId}
    `

    if (lotInfo.length === 0) {
      return NextResponse.json({ error: "الدفعة غير موجودة" }, { status: 404 })
    }

    const lot = lotInfo[0]

    // Handle different transaction types
    let transaction
    let notes = body.notes || ""

    if (body.transaction_type === "status_change") {
      // Change lot status
      const oldStatus = lot.status
      const newStatus = body.new_status

      if (oldStatus === newStatus) {
        return NextResponse.json({ error: "الحالة الجديدة مطابقة للحالة الحالية" }, { status: 400 })
      }

      await changeLotStatus(lotId, newStatus, body.notes, body.created_by)

      // Create status change transaction
      notes = `تغيير حالة من ${getStatusDisplay(oldStatus)} إلى ${getStatusDisplay(newStatus)}`
      if (body.notes) {
        notes += ` - ${body.notes}`
      }

      transaction = await createLotTransaction({
        lot_id: lotId,
        transaction_type: "status_change",
        quantity: 0,
        reference_type: body.reference_type,
        reference_id: body.reference_id ? Number.parseInt(body.reference_id) : undefined,
        unit_cost: body.unit_cost,
        notes,
        created_by: body.created_by,
      })
    } else {
      // Handle quantity-based transactions
      const quantity = Number.parseFloat(body.quantity)

      // Validate available quantity for outbound transactions
      if (["sale", "transfer", "damage"].includes(body.transaction_type)) {
        if (quantity > lot.available_quantity) {
          return NextResponse.json(
            {
              error: `الكمية المطلوبة (${quantity}) أكبر من الكمية المتاحة (${lot.available_quantity})`,
            },
            { status: 400 },
          )
        }
      }

      // Create the transaction
      transaction = await createLotTransaction({
        lot_id: lotId,
        transaction_type: body.transaction_type,
        quantity,
        reference_type: body.reference_type,
        reference_id: body.reference_id ? Number.parseInt(body.reference_id) : undefined,
        unit_cost: body.unit_cost,
        notes,
        created_by: body.created_by,
      })

      // Auto-close lot if quantity reaches zero
      if (body.transaction_type === "sale" || body.transaction_type === "damage") {
        const updatedLot = await sql`
          SELECT current_quantity FROM product_lots WHERE id = ${lotId}
        `

        if (updatedLot[0]?.current_quantity <= 0) {
          await changeLotStatus(lotId, "finished", "تم إغلاق الدفعة تلقائياً - نفدت الكمية", body.created_by)

          await createLotTransaction({
            lot_id: lotId,
            transaction_type: "close",
            quantity: 0,
            notes: "إغلاق تلقائي - نفدت الكمية",
            created_by: body.created_by,
          })
        }
      }
    }

    // Return the created transaction with lot details
    const result = await sql`
      SELECT 
        lt.*,
        pl.lot_number,
        p.product_name,
        p.product_code
      FROM lot_transactions lt
      JOIN product_lots pl ON lt.lot_id = pl.id
      JOIN products p ON pl.product_id = p.id
      WHERE lt.id = ${transaction.id}
    `

    return NextResponse.json(result[0], { status: 201 })
  } catch (error) {
    console.error("[v0] Error creating batch movement:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "فشل في إنشاء حركة الدفعة" },
      { status: 500 },
    )
  }
}

function getStatusDisplay(status: string): string {
  const statusMap = {
    new: "جديد",
    in_use: "قيد الاستخدام",
    finished: "منتهي",
    damaged: "تالف",
  }
  return statusMap[status as keyof typeof statusMap] || status
}
