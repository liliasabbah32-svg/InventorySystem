import { type NextRequest, NextResponse } from "next/server"
import { neon } from "@neondatabase/serverless"

const sql = neon(process.env.DATABASE_URL!)

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const organizationId = Number.parseInt(searchParams.get("organizationId") || "1")

    const products = await sql`
      SELECT 
        p.*,
        COALESCE(ps.current_stock, 0) as current_stock,
        COALESCE(ps.reserved_stock, 0) as reserved_stock,
        COALESCE(ps.available_stock, 0) as available_stock,
        COALESCE(ps.reorder_level, 0) as min_stock_level,
        ps.max_stock_level,
        ps.last_updated as stock_last_updated,
        CASE 
          WHEN COALESCE(ps.current_stock, 0) <= COALESCE(ps.reorder_level, 0) AND COALESCE(ps.current_stock, 0) > 0 THEN 'low'
          WHEN COALESCE(ps.current_stock, 0) = 0 THEN 'out'
          ELSE 'available'
        END as stock_status
      FROM products p
      LEFT JOIN product_stock ps ON p.id = ps.product_id AND ps.organization_id = ${organizationId}
      ORDER BY p.created_at DESC
    `

    const mappedProducts = products.map((product) => ({
      ...product,
      // Map database fields to UI expected fields for compatibility
      batch_tracking: product.has_batch,
      expiry_tracking: product.has_expiry,
    }))

    return NextResponse.json(mappedProducts)
  } catch (error) {
    console.error("Products API error:", error)
    return NextResponse.json({ error: "حدث خطأ في جلب البيانات" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const productData = await request.json()
    const organizationId = 1 // Get from auth context in real app

    console.log("[v0] Received product data:", JSON.stringify(productData, null, 2))

    const image_url = productData.image_url || productData.product_image || ""

    const stockFields = {
      current_stock: Number(productData.available_quantity || productData.current_stock || 0),
      reserved_stock: Number(productData.reserved_quantity || productData.reserved_stock || 0),
      reorder_level: Number(productData.reorder_point || productData.min_stock_level || 0),
      max_stock_level: productData.max_stock_level ? Number(productData.max_stock_level) : null,
    }

    console.log("[v0] Stock fields:", JSON.stringify(stockFields, null, 2))

    const cleanProductData = {
      product_code: productData.product_code,
      product_name: productData.product_name,
      barcode: productData.barcode,
      description: productData.description,
      category: productData.category,
      main_unit: productData.main_unit,
      secondary_unit: productData.secondary_unit,
      conversion_factor: productData.conversion_factor,
      last_purchase_price: productData.last_purchase_price,
      currency: productData.currency,
      general_notes: productData.notes || productData.description,
      product_type: productData.product_type,
      classifications: productData.classifications || productData.category,
      order_quantity: productData.order_quantity,
      original_number: productData.original_number,
      manufacturer_number: productData.manufacturer_number,
      has_colors: productData.has_colors,
      has_expiry: productData.expiry_tracking,
      has_batch: productData.batch_tracking,
      status: productData.status,
      max_quantity: productData.max_quantity,
      product_image: image_url,
      attachments: productData.attachments,
      entry_date: productData.entry_date,
    }

    console.log("[v0] Clean product data:", JSON.stringify(cleanProductData, null, 2))

    const existingProduct = await sql`
      SELECT id FROM products WHERE product_code = ${cleanProductData.product_code}
    `

    if (existingProduct.length > 0) {
      const productId = existingProduct[0].id
      const { product_code, ...updateData } = cleanProductData

      const result = await sql`
        UPDATE products SET
          product_name = ${updateData.product_name || ""},
          barcode = ${updateData.barcode || ""},
          description = ${updateData.description || ""},
          category = ${updateData.category || ""},
          main_unit = ${updateData.main_unit || "قطعة"},
          secondary_unit = ${updateData.secondary_unit || ""},
          conversion_factor = ${updateData.conversion_factor || 1},
          last_purchase_price = ${updateData.last_purchase_price || 0},
          currency = ${updateData.currency || "ريال سعودي"},
          general_notes = ${updateData.general_notes || ""},
          product_type = ${updateData.product_type || "منتج نهائي"},
          classifications = ${updateData.classifications || ""},
          order_quantity = ${updateData.order_quantity || 1},
          original_number = ${updateData.original_number || product_code},
          manufacturer_number = ${updateData.manufacturer_number || product_code},
          has_colors = ${updateData.has_colors || false},
          has_expiry = ${updateData.has_expiry || false},
          has_batch = ${updateData.has_batch || false},
          status = ${updateData.status || "نشط"},
          max_quantity = ${updateData.max_quantity || 0},
          product_image = ${updateData.product_image || ""},
          attachments = ${updateData.attachments || ""},
          entry_date = ${updateData.entry_date || new Date().toISOString().split("T")[0]}
        WHERE id = ${productId}
        RETURNING *
      `

      await sql`
        INSERT INTO product_stock (
          product_id, current_stock, reserved_stock,
          reorder_level, max_stock_level, organization_id
        ) VALUES (
          ${productId}, 
          ${stockFields.current_stock}, 
          ${stockFields.reserved_stock}, 
          ${stockFields.reorder_level},
          ${stockFields.max_stock_level}, 
          ${organizationId}
        )
        ON CONFLICT (product_id, organization_id) 
        DO UPDATE SET
          current_stock = ${stockFields.current_stock},
          reserved_stock = ${stockFields.reserved_stock},
          reorder_level = ${stockFields.reorder_level},
          max_stock_level = ${stockFields.max_stock_level},
          updated_at = CURRENT_TIMESTAMP
      `

      return NextResponse.json({ ...result[0], isUpdate: true })
    }

    if (!cleanProductData.product_code || cleanProductData.product_code.trim() === "") {
      const lastProduct = await sql`
        SELECT product_code FROM products 
        WHERE product_code ~ '^[A-Z0-9]+$' 
        ORDER BY LENGTH(product_code) DESC, product_code DESC 
        LIMIT 1
      `

      let nextCode = "A0000001"
      if (lastProduct.length > 0) {
        const lastCode = lastProduct[0].product_code
        const match = lastCode.match(/^([A-Z]*)(\d+)$/)
        if (match) {
          const prefix = match[1] || "A"
          const number = Number.parseInt(match[2]) + 1
          nextCode = prefix + number.toString().padStart(7, "0")
        }
      }

      cleanProductData.product_code = nextCode
    }

    console.log("[v0] About to insert product with code:", cleanProductData.product_code)

    const result = await sql`
      INSERT INTO products (
        product_code, product_name, barcode, description, category,
        main_unit, secondary_unit, conversion_factor, last_purchase_price,
        currency, general_notes, product_type, classifications, order_quantity,
        original_number, manufacturer_number, has_colors, has_expiry, has_batch,
        status, max_quantity, product_image, attachments, entry_date
      ) VALUES (
        ${cleanProductData.product_code}, 
        ${cleanProductData.product_name || ""}, 
        ${cleanProductData.barcode || ""}, 
        ${cleanProductData.description || ""}, 
        ${cleanProductData.category || ""},
        ${cleanProductData.main_unit || "قطعة"}, 
        ${cleanProductData.secondary_unit || ""}, 
        ${cleanProductData.conversion_factor || 1},
        ${cleanProductData.last_purchase_price || 0}, 
        ${cleanProductData.currency || "ريال سعودي"},
        ${cleanProductData.general_notes || ""}, 
        ${cleanProductData.product_type || "منتج نهائي"},
        ${cleanProductData.classifications || ""}, 
        ${cleanProductData.order_quantity || 1},
        ${cleanProductData.original_number || cleanProductData.product_code}, 
        ${cleanProductData.manufacturer_number || cleanProductData.product_code},
        ${cleanProductData.has_colors || false}, 
        ${cleanProductData.has_expiry || false}, 
        ${cleanProductData.has_batch || false},
        ${cleanProductData.status || "نشط"}, 
        ${cleanProductData.max_quantity || 0},
        ${cleanProductData.product_image || ""}, 
        ${cleanProductData.attachments || ""}, 
        ${cleanProductData.entry_date || new Date().toISOString().split("T")[0]}
      ) RETURNING *
    `

    const product = result[0]
    console.log("[v0] Product inserted successfully:", product.id)

    try {
      await sql`
        INSERT INTO product_stock (
          product_id, current_stock, reserved_stock,
          reorder_level, max_stock_level, organization_id
        ) VALUES (
          ${product.id}, 
          ${stockFields.current_stock}, 
          ${stockFields.reserved_stock}, 
          ${stockFields.reorder_level},
          ${stockFields.max_stock_level}, 
          ${organizationId}
        )
      `
      console.log("[v0] Stock record inserted successfully")
    } catch (stockError) {
      console.error("[v0] Stock insertion error:", stockError)
      return NextResponse.json(
        {
          error: "تم إنشاء المنتج ولكن حدث خطأ في إدارة المخزون: " + stockError.message,
        },
        { status: 500 },
      )
    }

    return NextResponse.json({ ...product, isUpdate: false })
  } catch (error) {
    console.error("Create product API error:", error)
    if (error.message && error.message.includes("duplicate key value violates unique constraint")) {
      return NextResponse.json(
        {
          error: "رقم الصنف موجود مسبقاً. يرجى استخدام رقم مختلف أو ترك الحقل فارغاً للتوليد التلقائي.",
        },
        { status: 409 },
      )
    }
    return NextResponse.json({ error: "حدث خطأ في إنشاء المنتج" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    const productData = await request.json()
    const { id, ...updateData } = productData

    console.log("[v0] PUT request - received data:", JSON.stringify(updateData, null, 2))

    const result = await sql`
      UPDATE products SET
        product_name = ${updateData.product_name || updateData.product_name_en || ""},
        barcode = ${updateData.barcode || ""},
        description = ${updateData.description || ""},
        category = ${updateData.category || ""},
        main_unit = ${updateData.main_unit || "قطعة"},
        secondary_unit = ${updateData.secondary_unit || ""},
        conversion_factor = ${updateData.conversion_factor || 1},
        last_purchase_price = ${updateData.last_purchase_price || updateData.selling_price || 0},
        currency = ${updateData.currency || "ريال سعودي"},
        general_notes = ${updateData.notes || updateData.description || ""},
        product_type = ${updateData.product_type || "منتج نهائي"},
        classifications = ${updateData.classifications || updateData.category || ""},
        order_quantity = ${updateData.order_quantity || 1},
        original_number = ${updateData.original_number || updateData.product_code || ""},
        manufacturer_number = ${updateData.manufacturer_number || updateData.product_code || ""},
        has_colors = ${updateData.has_colors || false},
        has_expiry = ${updateData.has_expiry || updateData.expiry_tracking || false},
        has_batch = ${updateData.has_batch || updateData.batch_tracking || false},
        status = ${updateData.status || "نشط"},
        max_quantity = ${updateData.max_stock_level || updateData.max_quantity || 0},
        product_image = ${updateData.image_url || updateData.product_image || ""},
        attachments = ${updateData.attachments || ""},
        entry_date = ${updateData.entry_date || new Date().toISOString().split("T")[0]}
      WHERE id = ${id}
      RETURNING *
    `

    console.log("[v0] PUT request - product updated:", result[0])

    // Update main product stock
    await sql`
      UPDATE product_stock SET
        reorder_level = ${updateData.reorder_point || updateData.min_stock_level || 0},
        max_stock_level = ${updateData.max_stock_level || null},
        updated_at = CURRENT_TIMESTAMP
      WHERE product_id = ${id}
    `

    console.log("[v0] PUT request - stock updated")

    // Update warehouse stock if available_quantity or warehouse_name is provided
    if (updateData.available_quantity !== undefined || updateData.warehouse_name) {
      const warehouseName = updateData.warehouse_name || "المستودع الرئيسي"

      // Get warehouse ID by name
      const warehouse = await sql`
        SELECT id FROM warehouses WHERE warehouse_name = ${warehouseName} LIMIT 1
      `

      if (warehouse.length > 0) {
        const warehouseId = warehouse[0].id

        // Check if product warehouse record exists
        const existingStock = await sql`
          SELECT id FROM product_warehouses 
          WHERE product_id = ${id} AND warehouse_id = ${warehouseId}
        `

        if (existingStock.length > 0) {
          // Update existing warehouse stock record
          await sql`
            UPDATE product_warehouses SET
              quantity = ${updateData.available_quantity || 0},
              reserved_quantity = ${updateData.reserved_quantity || 0},
              max_stock_level = ${updateData.max_stock_level || null},
              min_stock_level = ${updateData.reorder_point || 0},
              area = ${updateData.location || ""},
              shelf = ${updateData.shelf || ""},
              floor = ${updateData.floor || ""},
              updated_at = CURRENT_TIMESTAMP
            WHERE product_id = ${id} AND warehouse_id = ${warehouseId}
          `
        } else {
          // Insert new warehouse stock record
          await sql`
            INSERT INTO product_warehouses (
              product_id, warehouse_id, quantity, reserved_quantity,
              max_stock_level, min_stock_level, area, shelf, floor
            ) VALUES (
              ${id}, ${warehouseId}, ${updateData.available_quantity || 0}, 
              ${updateData.reserved_quantity || 0}, ${updateData.max_stock_level || null}, 
              ${updateData.reorder_point || 0}, ${updateData.location || ""}, 
              ${updateData.shelf || ""}, ${updateData.floor || ""}
            )
          `
        }
      }
    }

    const mappedResult = {
      ...result[0],
      batch_tracking: result[0].has_batch,
      expiry_tracking: result[0].has_expiry,
    }

    return NextResponse.json(mappedResult)
  } catch (error) {
    console.error("Update product API error:", error)
    return NextResponse.json({ error: "حدث خطأ في تحديث المنتج" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get("id")

    if (!id) {
      return NextResponse.json({ error: "Product ID is required" }, { status: 400 })
    }

    console.log("[v0] Attempting to delete product with ID:", id)

    const existingProduct = await sql`
      SELECT id, product_name FROM products WHERE id = ${id}
    `

    if (existingProduct.length === 0) {
      return NextResponse.json({ error: "المنتج غير موجود" }, { status: 404 })
    }

    console.log("[v0] Found product to delete:", existingProduct[0].product_name)

    try {
      await sql`
        DELETE FROM product_warehouses WHERE product_id = ${id}
      `
      console.log("[v0] Deleted warehouse stock records")
    } catch (warehouseError) {
      console.log("[v0] Warehouse stock deletion error:", warehouseError.message)
    }

    try {
      // Delete from product_stock
      await sql`
        DELETE FROM product_stock WHERE product_id = ${id}
      `
      console.log("[v0] Deleted stock records")
    } catch (stockError) {
      console.log("[v0] Stock deletion error:", stockError.message)
    }

    const deleteResult = await sql`
      DELETE FROM products WHERE id = ${id}
      RETURNING id, product_name
    `

    if (deleteResult.length === 0) {
      return NextResponse.json({ error: "فشل في حذف المنتج" }, { status: 500 })
    }

    console.log("[v0] Successfully deleted product:", deleteResult[0].product_name)

    return NextResponse.json({
      message: "تم حذف المنتج بنجاح",
      deletedProduct: deleteResult[0],
    })
  } catch (error) {
    console.error("Delete product API error:", error)
    return NextResponse.json({ error: "حدث خطأ في حذف المنتج" }, { status: 500 })
  }
}
