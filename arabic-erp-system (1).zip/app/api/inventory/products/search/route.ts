import { type NextRequest, NextResponse } from "next/server"
import { neon } from "@neondatabase/serverless"

const sql = neon(process.env.DATABASE_URL!)

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const code = searchParams.get("code")

    if (!code) {
      return NextResponse.json({ error: "Product code is required" }, { status: 400 })
    }

    console.log("[v0] Searching for product with code:", code)

    const products = await sql`
      SELECT * FROM products 
      WHERE product_code = ${code}
      LIMIT 1
    `

    if (products.length === 0) {
      return NextResponse.json({ error: "Product not found" }, { status: 404 })
    }

    console.log("[v0] Found product:", products[0])
    return NextResponse.json(products[0])
  } catch (error) {
    console.error("[v0] Error searching for product:", error)
    return NextResponse.json({ error: "Failed to search for product" }, { status: 500 })
  }
}
