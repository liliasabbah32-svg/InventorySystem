import { type NextRequest, NextResponse } from "next/server"
import { updateCustomerPassword } from "@/lib/customer-auth"

export async function PUT(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const userId = Number.parseInt(id)
    const body = await request.json()
    const { password } = body

    if (!password) {
      return NextResponse.json({ error: "كلمة المرور مطلوبة" }, { status: 400 })
    }

    await updateCustomerPassword(userId, password)

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Update password error:", error)
    return NextResponse.json({ error: "حدث خطأ أثناء تغيير كلمة المرور" }, { status: 500 })
  }
}
