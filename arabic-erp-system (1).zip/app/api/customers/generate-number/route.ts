import { NextResponse } from "next/server"
import { generateCustomerNumber } from "@/lib/number-generator"

export async function GET() {
  try {
    console.log("[v0] API: Starting customer number generation...")

    if (!process.env.DATABASE_URL) {
      console.error("[v0] API: DATABASE_URL not found")
      return NextResponse.json(
        { message: "خطأ في إعدادات قاعدة البيانات", error: "DATABASE_URL not configured" },
        { status: 500 },
      )
    }

    const customerNumber = await generateCustomerNumber()
    console.log("[v0] API: Generated customer number:", customerNumber)

    return NextResponse.json({ customerNumber })
  } catch (error) {
    console.error("[v0] API: Error generating customer number:", error)

    const errorMessage = error instanceof Error ? error.message : "Unknown error"
    return NextResponse.json(
      {
        message: "فشل في توليد رقم الزبون",
        error: errorMessage,
        details: "Database connection or query failed",
      },
      {
        status: 500,
        headers: {
          "Content-Type": "application/json",
        },
      },
    )
  }
}
