import { type NextRequest, NextResponse } from "next/server"
import { neon } from "@neondatabase/serverless"

export async function GET(request: NextRequest) {
  try {
    console.log("[v0] API: Starting order number generation")

    if (!process.env.DATABASE_URL) {
      console.error("[v0] API: DATABASE_URL not found")
      return NextResponse.json({ error: "DATABASE_URL environment variable is not set" }, { status: 500 })
    }

    console.log("[v0] API: DATABASE_URL found, creating connection")
    const sql = neon(process.env.DATABASE_URL)

    const systemSettings = await sql`
      SELECT order_prefix, auto_numbering, numbering_system
      FROM system_settings 
      ORDER BY id DESC 
      LIMIT 1
    `

    const settings = systemSettings[0] || {
      order_prefix: "O",
      auto_numbering: true,
      numbering_system: "sequential",
    }

    console.log("[v0] API: System settings:", settings)

    // If auto_numbering is disabled, return empty to let user enter manually
    if (!settings.auto_numbering) {
      console.log("[v0] API: Auto numbering is disabled")
      return NextResponse.json({
        orderNumber: "",
        autoNumbering: false,
        message: "الترقيم اليدوي مفعّل",
      })
    }

    const prefix = settings.order_prefix || "O"

    // Get the latest order number with this prefix
    const result = await sql`
      SELECT order_number 
      FROM sales_orders 
      WHERE order_number LIKE ${prefix + "%"}
      ORDER BY id DESC 
      LIMIT 1
    `

    console.log("[v0] API: Query result:", result)

    let nextNumber = 1
    if (result.length > 0 && result[0].order_number) {
      const currentCode = result[0].order_number as string
      // Extract numeric part after prefix
      const numericPart = currentCode.substring(prefix.length)
      const parsedNumber = Number.parseInt(numericPart, 10)

      if (!isNaN(parsedNumber)) {
        nextNumber = parsedNumber + 1
        console.log("[v0] API: Found existing code:", currentCode, "next number:", nextNumber)
      }
    } else {
      console.log("[v0] API: No existing codes found, starting with 1")
    }

    const paddedNumber = nextNumber.toString().padStart(7, "0")
    const orderNumber = `${prefix}${paddedNumber}`

    console.log("[v0] API: Generated order number:", orderNumber)

    return NextResponse.json({
      orderNumber,
      autoNumbering: true,
      prefix: prefix,
    })
  } catch (error) {
    console.error("[v0] API: Error generating sales order number:", error)

    const fallbackNumber = "O0000001"

    console.log("[v0] API: Using fallback number:", fallbackNumber)

    return NextResponse.json({
      orderNumber: fallbackNumber,
      autoNumbering: true,
      warning: "Generated fallback number due to database error",
    })
  }
}
