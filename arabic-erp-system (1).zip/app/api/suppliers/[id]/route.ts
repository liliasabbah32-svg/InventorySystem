import { type NextRequest, NextResponse } from "next/server"
import { neon } from "@neondatabase/serverless"

const sql = neon(process.env.DATABASE_URL!)

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { id } = params
    const data = await request.json()

    const result = await sql`
      UPDATE suppliers 
      SET 
        supplier_name = ${data.supplier_name || data.name},
        mobile1 = ${data.mobile1 || data.phone1},
        mobile2 = ${data.mobile2 || data.phone2},
        whatsapp1 = ${data.whatsapp1},
        whatsapp2 = ${data.whatsapp2},
        city = ${data.city},
        address = ${data.address},
        email = ${data.email},
        status = ${data.status},
        business_nature = ${data.business_nature},
        salesman = ${data.salesman || data.representative},
        classifications = ${data.classifications || data.classification},
        account_opening_date = ${data.account_opening_date},
        movement_notes = ${data.movement_notes || data.transaction_notes},
        general_notes = ${data.general_notes},
        web_username = ${data.web_username},
        web_password = ${data.web_password},
        api_number = ${data.api_number || ""}
      WHERE id = ${id}
      RETURNING *
    `

    return NextResponse.json(result[0])
  } catch (error) {
    console.error("Error updating supplier:", error)
    return NextResponse.json({ error: "Failed to update supplier" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { id } = params

    await sql`DELETE FROM suppliers WHERE id = ${id}`

    return NextResponse.json({ message: "Supplier deleted successfully" })
  } catch (error) {
    console.error("Error deleting supplier:", error)
    return NextResponse.json({ error: "Failed to delete supplier" }, { status: 500 })
  }
}
