import { type NextRequest, NextResponse } from "next/server"
import { neon } from "@neondatabase/serverless"

const sql = neon(process.env.DATABASE_URL!)

export async function GET() {
  try {
    const itemGroups = await sql`
      SELECT 
        id,
        group_number,
        group_name,
        description,
        parent_group_id,
        is_active,
        product_count,
        created_at,
        updated_at
      FROM item_groups_with_count
      ORDER BY created_at DESC
    `

    const formattedGroups = itemGroups.map((group) => ({
      ...group,
      status: group.is_active ? "نشط" : "غير نشط",
    }))

    return NextResponse.json(formattedGroups)
  } catch (error) {
    console.error("Error fetching item groups:", error)
    return NextResponse.json({ error: "Failed to fetch item groups" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()

    if (data.group_number) {
      const existingGroup = await sql`
        SELECT id FROM item_groups WHERE group_number = ${data.group_number}
      `
      if (existingGroup.length > 0) {
        return NextResponse.json({ error: "رقم المجموعة موجود مسبقاً" }, { status: 400 })
      }
    } else {
      // توليد رقم جديد إذا لم يتم توفيره
      const lastGroup = await sql`
        SELECT group_number FROM item_groups 
        ORDER BY created_at DESC 
        LIMIT 1
      `

      let newNumber = 1
      if (lastGroup.length > 0) {
        const lastCode = lastGroup[0].group_number
        const match = lastCode.match(/(\d+)$/)
        if (match) {
          newNumber = Number.parseInt(match[1]) + 1
        }
      }

      data.group_number = `G${newNumber.toString().padStart(7, "0")}`
    }

    const isActive = data.status === "نشط" || data.status !== "غير نشط"

    const result = await sql`
      INSERT INTO item_groups (
        group_number, group_name, description, is_active
      ) VALUES (
        ${data.group_number}, ${data.group_name}, ${data.description || ""}, ${isActive}
      ) RETURNING *
    `

    const formattedResult = {
      ...result[0],
      status: result[0].is_active ? "نشط" : "غير نشط",
    }

    return NextResponse.json(formattedResult, { status: 201 })
  } catch (error) {
    console.error("Error creating item group:", error)
    return NextResponse.json({ error: "Failed to create item group" }, { status: 500 })
  }
}
