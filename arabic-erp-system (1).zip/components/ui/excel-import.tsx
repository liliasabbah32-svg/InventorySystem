"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Upload, Download, FileSpreadsheet, AlertCircle, CheckCircle } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface ExcelImportProps {
  entityType: "products" | "customers" | "suppliers"
  isOpen: boolean
  onClose: () => void
  onImportComplete: () => void
}

interface ImportResult {
  success: number
  failed: number
  errors: string[]
  duplicates: number
}

export function ExcelImport({ entityType, isOpen, onClose, onImportComplete }: ExcelImportProps) {
  const [file, setFile] = useState<File | null>(null)
  const [isUploading, setIsUploading] = useState(false)
  const [progress, setProgress] = useState(0)
  const [previewData, setPreviewData] = useState<any[]>([])
  const [importResult, setImportResult] = useState<ImportResult | null>(null)
  const [step, setStep] = useState<"upload" | "preview" | "result">("upload")
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { toast } = useToast()

  const entityLabels = {
    products: "الأصناف",
    customers: "الزبائن",
    suppliers: "الموردين",
  }

  const templateColumns = {
    products: [
      { key: "product_code", label: "رقم الصنف" },
      { key: "product_name", label: "اسم الصنف" },
      { key: "description", label: "الوصف" },
      { key: "category", label: "الفئة" },
      { key: "main_unit", label: "الوحدة الأساسية" },
      { key: "secondary_unit", label: "الوحدة الثانوية" },
      { key: "conversion_factor", label: "معامل التحويل" },
      { key: "barcode", label: "الباركود" },
      { key: "last_purchase_price", label: "آخر سعر شراء" },
      { key: "currency", label: "العملة" },
    ],
    customers: [
      { key: "customer_code", label: "رقم الزبون" },
      { key: "customer_name", label: "اسم الزبون" },
      { key: "mobile1", label: "الجوال الأول" },
      { key: "mobile2", label: "الجوال الثاني" },
      { key: "whatsapp1", label: "واتساب الأول" },
      { key: "city", label: "المدينة" },
      { key: "address", label: "العنوان" },
      { key: "email", label: "البريد الإلكتروني" },
      { key: "status", label: "الحالة" },
      { key: "classifications", label: "التصنيف" },
    ],
    suppliers: [
      { key: "supplier_code", label: "رقم المورد" },
      { key: "supplier_name", label: "اسم المورد" },
      { key: "mobile1", label: "الجوال الأول" },
      { key: "mobile2", label: "الجوال الثاني" },
      { key: "whatsapp1", label: "واتساب الأول" },
      { key: "city", label: "المدينة" },
      { key: "address", label: "العنوان" },
      { key: "email", label: "البريد الإلكتروني" },
      { key: "status", label: "الحالة" },
      { key: "business_nature", label: "طبيعة العمل" },
    ],
  }

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0]
    if (selectedFile) {
      if (!selectedFile.name.match(/\.(xlsx|xls)$/)) {
        toast({
          title: "خطأ في نوع الملف",
          description: "يرجى اختيار ملف Excel (.xlsx أو .xls)",
          variant: "destructive",
        })
        return
      }
      setFile(selectedFile)
    }
  }

  const downloadTemplate = () => {
    const columns = templateColumns[entityType]
    const headers = columns.map((col) => col.label).join(",")
    const sampleRow = columns.map(() => "").join(",")
    const csvContent = `${headers}\n${sampleRow}`

    const blob = new Blob(["\uFEFF" + csvContent], { type: "text/csv;charset=utf-8;" })
    const link = document.createElement("a")
    const url = URL.createObjectURL(blob)
    link.setAttribute("href", url)
    link.setAttribute("download", `template_${entityLabels[entityType]}.csv`)
    link.style.visibility = "hidden"
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  const processFile = async () => {
    if (!file) return

    setIsUploading(true)
    setProgress(0)

    try {
      const formData = new FormData()
      formData.append("file", file)
      formData.append("entityType", entityType)

      const response = await fetch("/api/import/preview", {
        method: "POST",
        body: formData,
      })

      if (!response.ok) {
        throw new Error("فشل في معالجة الملف")
      }

      const data = await response.json()
      setPreviewData(data.preview)
      setStep("preview")

      toast({
        title: "تم تحليل الملف بنجاح",
        description: `تم العثور على ${data.preview.length} سجل`,
      })
    } catch (error) {
      toast({
        title: "خطأ في معالجة الملف",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setIsUploading(false)
      setProgress(0)
    }
  }

  const confirmImport = async () => {
    setIsUploading(true)
    setProgress(0)

    try {
      const response = await fetch(`/api/import/${entityType}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ data: previewData }),
      })

      if (!response.ok) {
        throw new Error("فشل في استيراد البيانات")
      }

      const result = await response.json()
      setImportResult(result)
      setStep("result")

      if (result.success > 0) {
        onImportComplete()
        toast({
          title: "تم الاستيراد بنجاح",
          description: `تم استيراد ${result.success} سجل بنجاح`,
        })
      }
    } catch (error) {
      toast({
        title: "خطأ في الاستيراد",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setIsUploading(false)
      setProgress(0)
    }
  }

  const resetImport = () => {
    setFile(null)
    setPreviewData([])
    setImportResult(null)
    setStep("upload")
    setProgress(0)
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const handleClose = () => {
    resetImport()
    onClose()
  }

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileSpreadsheet className="h-5 w-5" />
            استيراد {entityLabels[entityType]} من Excel
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 overflow-auto">
          {step === "upload" && (
            <div className="space-y-6">
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  يرجى تحميل ملف Excel يحتوي على البيانات المطلوبة. يمكنك تحميل نموذج فارغ للمساعدة في تنسيق البيانات.
                </AlertDescription>
              </Alert>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <Label htmlFor="file-upload" className="text-lg font-semibold">
                    اختيار ملف Excel
                  </Label>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                    <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                    <Input
                      ref={fileInputRef}
                      id="file-upload"
                      type="file"
                      accept=".xlsx,.xls"
                      onChange={handleFileSelect}
                      className="hidden"
                    />
                    <Button variant="outline" onClick={() => fileInputRef.current?.click()} className="mb-2">
                      اختيار ملف
                    </Button>
                    <p className="text-sm text-gray-500">{file ? file.name : "لم يتم اختيار ملف"}</p>
                  </div>
                </div>

                <div className="space-y-4">
                  <Label className="text-lg font-semibold">تحميل نموذج فارغ</Label>
                  <div className="border rounded-lg p-6 text-center">
                    <Download className="mx-auto h-12 w-12 text-blue-500 mb-4" />
                    <Button variant="outline" onClick={downloadTemplate}>
                      <Download className="ml-2 h-4 w-4" />
                      تحميل نموذج {entityLabels[entityType]}
                    </Button>
                    <p className="text-sm text-gray-500 mt-2">نموذج Excel جاهز للتعبئة</p>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <Label className="text-lg font-semibold">الأعمدة المطلوبة:</Label>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
                  {templateColumns[entityType].map((col, index) => (
                    <div key={index} className="bg-gray-50 p-2 rounded text-sm">
                      {col.label}
                    </div>
                  ))}
                </div>
              </div>

              {isUploading && (
                <div className="space-y-2">
                  <Progress value={progress} className="w-full" />
                  <p className="text-sm text-center">جاري معالجة الملف...</p>
                </div>
              )}

              <div className="flex justify-end gap-3">
                <Button variant="outline" onClick={handleClose}>
                  إلغاء
                </Button>
                <Button onClick={processFile} disabled={!file || isUploading}>
                  معاينة البيانات
                </Button>
              </div>
            </div>
          )}

          {step === "preview" && (
            <div className="space-y-6">
              <Alert>
                <CheckCircle className="h-4 w-4" />
                <AlertDescription>
                  تم تحليل الملف بنجاح. يرجى مراجعة البيانات أدناه قبل الاستيراد النهائي.
                </AlertDescription>
              </Alert>

              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="font-semibold mb-2">ملخص البيانات:</h3>
                <p>عدد السجلات: {previewData.length}</p>
                <p>نوع البيانات: {entityLabels[entityType]}</p>
              </div>

              <div className="border rounded-lg overflow-hidden">
                <div className="max-h-96 overflow-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        {templateColumns[entityType].slice(0, 6).map((col, index) => (
                          <TableHead key={index} className="text-right">
                            {col.label}
                          </TableHead>
                        ))}
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {previewData.slice(0, 10).map((row, index) => (
                        <TableRow key={index}>
                          {templateColumns[entityType].slice(0, 6).map((col, colIndex) => (
                            <TableCell key={colIndex} className="text-right">
                              {row[col.key] || "-"}
                            </TableCell>
                          ))}
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
                {previewData.length > 10 && (
                  <div className="p-3 bg-gray-50 text-center text-sm text-gray-600">
                    وعرض {previewData.length - 10} سجل إضافي...
                  </div>
                )}
              </div>

              {isUploading && (
                <div className="space-y-2">
                  <Progress value={progress} className="w-full" />
                  <p className="text-sm text-center">جاري استيراد البيانات...</p>
                </div>
              )}

              <div className="flex justify-end gap-3">
                <Button variant="outline" onClick={resetImport}>
                  العودة
                </Button>
                <Button onClick={confirmImport} disabled={isUploading} className="bg-green-600 hover:bg-green-700">
                  تأكيد الاستيراد
                </Button>
              </div>
            </div>
          )}

          {step === "result" && importResult && (
            <div className="space-y-6">
              <div className="text-center">
                <CheckCircle className="mx-auto h-16 w-16 text-green-500 mb-4" />
                <h3 className="text-xl font-semibold mb-2">تم الاستيراد بنجاح!</h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-green-50 p-4 rounded-lg text-center">
                  <div className="text-2xl font-bold text-green-600">{importResult.success}</div>
                  <div className="text-sm text-green-700">تم استيرادها بنجاح</div>
                </div>
                <div className="bg-red-50 p-4 rounded-lg text-center">
                  <div className="text-2xl font-bold text-red-600">{importResult.failed}</div>
                  <div className="text-sm text-red-700">فشل في الاستيراد</div>
                </div>
                <div className="bg-yellow-50 p-4 rounded-lg text-center">
                  <div className="text-2xl font-bold text-yellow-600">{importResult.duplicates}</div>
                  <div className="text-sm text-yellow-700">مكررة</div>
                </div>
              </div>

              {importResult.errors.length > 0 && (
                <div className="space-y-2">
                  <Label className="font-semibold text-red-600">الأخطاء:</Label>
                  <div className="bg-red-50 p-4 rounded-lg max-h-32 overflow-auto">
                    {importResult.errors.map((error, index) => (
                      <div key={index} className="text-sm text-red-700 mb-1">
                        • {error}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex justify-end gap-3">
                <Button onClick={handleClose}>إغلاق</Button>
                <Button variant="outline" onClick={resetImport}>
                  استيراد ملف آخر
                </Button>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
