"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Plus, Edit, Building, MapPin, Package, Users, CreditCard, Settings } from "lucide-react"
import { UniversalToolbar } from "@/components/ui/universal-toolbar"
import { WorkflowStagesManagement } from "@/components/workflow/workflow-stages-management"
import { WorkflowSequencesManagement } from "@/components/workflow/workflow-sequences-management"
import { cn } from "@/lib/utils"

const cities = [
  { id: "C001", name: "نابلس", region: "الضفة الغربية", isActive: true },
  { id: "C002", name: "رام الله", region: "الضفة الغربية", isActive: true },
  { id: "C003", name: "الخليل", region: "الضفة الغربية", isActive: true },
  { id: "C004", name: "بيت لحم", region: "الضفة الغربية", isActive: true },
  { id: "C005", name: "جنين", region: "الضفة الغربية", isActive: true },
]

const warehouses = [
  {
    id: "W001",
    name: "المستودع الرئيسي",
    location: "نابلس",
    departments: ["المبيعات", "المشتريات"],
    printer: "HP LaserJet Pro 400",
    capacity: "5000 متر مكعب",
    isActive: true,
  },
  {
    id: "W002",
    name: "مستودع الفرع الثاني",
    location: "رام الله",
    departments: ["المبيعات"],
    printer: "Canon ImageClass MF445dw",
    capacity: "3000 متر مكعب",
    isActive: true,
  },
]

const customerCategories = [
  { id: "CC001", name: "زبائن VIP", discount: 15, customers: ["أحمد محمد", "علي حسن"], color: "#10B981" },
  { id: "CC002", name: "زبائن عاديين", discount: 5, customers: ["محمد علي", "خالد أحمد"], color: "#6B7280" },
  { id: "CC003", name: "زبائن الجملة", discount: 20, customers: ["شركة الأمل", "مؤسسة النور"], color: "#3B82F6" },
]

const supplierCategories = [
  {
    id: "SC001",
    name: "موردين محليين",
    paymentTerms: "30 يوم",
    suppliers: ["شركة الأمل", "مؤسسة النور"],
    color: "#F59E0B",
  },
  {
    id: "SC002",
    name: "موردين دوليين",
    paymentTerms: "60 يوم",
    suppliers: ["شركة عالمية", "مؤسسة دولية"],
    color: "#EF4444",
  },
  { id: "SC003", name: "موردين استراتيجيين", paymentTerms: "45 يوم", suppliers: ["الشركة الكبرى"], color: "#8B5CF6" },
]

const productCategories = [
  { id: "PC001", name: "إلكترونيات", taxRate: 16, products: ["لابتوب", "موبايل", "تابلت"], color: "#06B6D4" },
  { id: "PC002", name: "ملابس", taxRate: 16, products: ["قميص", "بنطلون", "فستان"], color: "#EC4899" },
  { id: "PC003", name: "أجهزة منزلية", taxRate: 16, products: ["ثلاجة", "غسالة", "مكيف"], color: "#84CC16" },
]

const currencies = [
  { code: "USD", name: "دولار أمريكي", sellPrice: 3.65, buyPrice: 3.6, exchangeRate: 3.62, isDefault: false },
  { code: "EUR", name: "يورو", sellPrice: 4.1, buyPrice: 4.05, exchangeRate: 4.07, isDefault: false },
  { code: "JOD", name: "دينار أردني", sellPrice: 5.15, buyPrice: 5.1, exchangeRate: 5.12, isDefault: false },
  { code: "ILS", name: "شيكل إسرائيلي", sellPrice: 1.0, buyPrice: 1.0, exchangeRate: 1.0, isDefault: true },
]

const branches = [
  {
    id: "B001",
    name: "الفرع الرئيسي",
    address: "نابلس - شارع فيصل",
    manager: "أحمد محمد",
    phone: "09-2345678",
    isActive: true,
  },
  {
    id: "B002",
    name: "فرع رام الله",
    address: "رام الله - المنارة",
    manager: "محمد علي",
    phone: "02-2987654",
    isActive: true,
  },
]

const departments = [
  {
    id: "D001",
    name: "المبيعات",
    branch: "الفرع الرئيسي",
    manager: "محمد أحمد",
    employeeCount: 8,
    isActive: true,
  },
  {
    id: "D002",
    name: "المشتريات",
    branch: "الفرع الرئيسي",
    manager: "علي حسن",
    employeeCount: 5,
    isActive: true,
  },
]

function Definitions() {
  const [showCityForm, setShowCityForm] = useState(false)
  const [showWarehouseForm, setShowWarehouseForm] = useState(false)
  const [showCurrencyForm, setShowCurrencyForm] = useState(false)
  const [showBranchForm, setShowBranchForm] = useState(false)
  const [showDepartmentForm, setShowDepartmentForm] = useState(false)
  const [showCustomerCategoryForm, setShowCustomerCategoryForm] = useState(false)
  const [showSupplierCategoryForm, setShowSupplierCategoryForm] = useState(false)
  const [showProductCategoryForm, setShowProductCategoryForm] = useState(false)
  const [currentBranchIndex, setCurrentBranchIndex] = useState(0)
  const [currentDepartmentIndex, setCurrentDepartmentIndex] = useState(0)
  const [currentCityIndex, setCurrentCityIndex] = useState(0)
  const [currentWarehouseIndex, setCurrentWarehouseIndex] = useState(0)

  return (
    <div className="p-6" dir="rtl">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <Settings className="h-8 w-8 text-primary" />
          <h1 className="text-2xl font-heading font-bold text-primary">الملفات والتعريفات</h1>
        </div>
        <Badge variant="outline" className="text-sm">
          إدارة شاملة للنظام
        </Badge>
      </div>

      <Tabs defaultValue="departments" className="w-full" dir="rtl">
        <TabsList className="grid w-full grid-cols-4 mb-6">
          <TabsTrigger value="departments" className="flex items-center gap-2">
            <Building className="h-4 w-4" />
            الأقسام والفروع
          </TabsTrigger>
          <TabsTrigger value="definitions" className="flex items-center gap-2">
            <Package className="h-4 w-4" />
            التعريفات الأساسية
          </TabsTrigger>
          <TabsTrigger value="workflow-stages" className="flex items-center gap-2">
            <Settings className="h-4 w-4" />
            مراحل العمل
          </TabsTrigger>
          <TabsTrigger value="workflow-sequences" className="flex items-center gap-2">
            <Settings className="h-4 w-4" />
            تسلسلات العمل
          </TabsTrigger>
        </TabsList>

        <TabsContent value="departments" className="space-y-6">
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            <Card dir="rtl">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Building className="h-5 w-5 text-primary" />
                    الفروع ({branches.length})
                  </CardTitle>
                  <Button className="erp-btn-primary" size="sm" onClick={() => setShowBranchForm(!showBranchForm)}>
                    <Plus className="h-4 w-4 mr-2" />
                    إضافة فرع
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <UniversalToolbar
                  currentIndex={currentBranchIndex}
                  totalRecords={branches.length}
                  onFirst={() => setCurrentBranchIndex(0)}
                  onPrevious={() => setCurrentBranchIndex(Math.max(0, currentBranchIndex - 1))}
                  onNext={() => setCurrentBranchIndex(Math.min(branches.length - 1, currentBranchIndex + 1))}
                  onLast={() => setCurrentBranchIndex(branches.length - 1)}
                  isFirstRecord={currentBranchIndex === 0}
                  isLastRecord={currentBranchIndex === branches.length - 1}
                  isSaving={false}
                />

                {showBranchForm && (
                  <div className="bg-muted/30 rounded-lg p-4 border" dir="rtl">
                    <h3 className="font-heading font-semibold mb-4 text-right">إضافة فرع جديد</h3>
                    <form className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="text-right">
                          <Label className="erp-label text-right block">اسم الفرع *</Label>
                          <Input required className="erp-input text-right" placeholder="مثال: فرع رام الله" dir="rtl" />
                        </div>
                        <div className="text-right">
                          <Label className="erp-label text-right block">رقم الهاتف</Label>
                          <Input className="erp-input text-right" placeholder="09-1234567" dir="rtl" />
                        </div>
                      </div>
                      <div className="text-right">
                        <Label className="erp-label text-right block">العنوان</Label>
                        <Input className="erp-input text-right" placeholder="العنوان الكامل للفرع" dir="rtl" />
                      </div>
                      <div className="text-right">
                        <Label className="erp-label text-right block">مسؤول الفرع</Label>
                        <Select dir="rtl">
                          <SelectTrigger className="erp-input text-right">
                            <SelectValue placeholder="اختر المسؤول" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="ahmed">أحمد محمد</SelectItem>
                            <SelectItem value="ali">علي حسن</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="flex justify-start gap-2 pt-2">
                        <Button type="submit" className="erp-btn-primary" size="sm">
                          حفظ الفرع
                        </Button>
                        <Button type="button" variant="outline" size="sm" onClick={() => setShowBranchForm(false)}>
                          إلغاء
                        </Button>
                      </div>
                    </form>
                  </div>
                )}

                <div className="space-y-3">
                  {branches.map((branch, index) => (
                    <div
                      key={branch.id}
                      className={cn(
                        "p-4 rounded-lg border transition-all cursor-pointer",
                        index === currentBranchIndex
                          ? "bg-primary/10 border-primary shadow-sm"
                          : "bg-background hover:bg-muted/50",
                      )}
                      onClick={() => setCurrentBranchIndex(index)}
                      dir="rtl"
                    >
                      <div className="flex items-center justify-between">
                        <div className="space-y-1 text-right">
                          <h4 className="font-heading font-semibold">{branch.name}</h4>
                          <p className="text-sm text-muted-foreground flex items-center gap-1">
                            <MapPin className="h-3 w-3" />
                            {branch.address}
                          </p>
                          <div className="flex items-center gap-4 text-xs text-muted-foreground">
                            <span>المسؤول: {branch.manager}</span>
                            <span>الهاتف: {branch.phone}</span>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button variant="outline" size="sm">
                            <Edit className="h-3 w-3" />
                          </Button>
                          <Badge variant={branch.isActive ? "default" : "secondary"}>
                            {branch.isActive ? "نشط" : "غير نشط"}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card dir="rtl">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Users className="h-5 w-5 text-primary" />
                    الأقسام ({departments.length})
                  </CardTitle>
                  <Button
                    className="erp-btn-primary"
                    size="sm"
                    onClick={() => setShowDepartmentForm(!showDepartmentForm)}
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    إضافة قسم
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <UniversalToolbar
                  currentIndex={currentDepartmentIndex}
                  totalRecords={departments.length}
                  onFirst={() => setCurrentDepartmentIndex(0)}
                  onPrevious={() => setCurrentDepartmentIndex(Math.max(0, currentDepartmentIndex - 1))}
                  onNext={() => setCurrentDepartmentIndex(Math.min(departments.length - 1, currentDepartmentIndex + 1))}
                  onLast={() => setCurrentDepartmentIndex(departments.length - 1)}
                  isFirstRecord={currentDepartmentIndex === 0}
                  isLastRecord={currentDepartmentIndex === departments.length - 1}
                  isSaving={false}
                />

                {showDepartmentForm && (
                  <div className="bg-muted/30 rounded-lg p-4 border" dir="rtl">
                    <h3 className="font-heading font-semibold mb-4 text-right">إضافة قسم جديد</h3>
                    <form className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="text-right">
                          <Label className="erp-label text-right block">اسم القسم *</Label>
                          <Input required className="erp-input text-right" placeholder="مثال: المحاسبة" dir="rtl" />
                        </div>
                        <div className="text-right">
                          <Label className="erp-label text-right block">تابع لفرع</Label>
                          <Select dir="rtl">
                            <SelectTrigger className="erp-input text-right">
                              <SelectValue placeholder="اختر الفرع" />
                            </SelectTrigger>
                            <SelectContent>
                              {branches.map((branch) => (
                                <SelectItem key={branch.id} value={branch.id}>
                                  {branch.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <div className="text-right">
                        <Label className="erp-label text-right block">مسؤول القسم</Label>
                        <Select dir="rtl">
                          <SelectTrigger className="erp-input text-right">
                            <SelectValue placeholder="اختر المسؤول" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="mohamed">محمد أحمد</SelectItem>
                            <SelectItem value="ali">علي حسن</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="flex justify-start gap-2 pt-2">
                        <Button type="submit" className="erp-btn-primary" size="sm">
                          حفظ القسم
                        </Button>
                        <Button type="button" variant="outline" size="sm" onClick={() => setShowDepartmentForm(false)}>
                          إلغاء
                        </Button>
                      </div>
                    </form>
                  </div>
                )}

                <div className="space-y-3">
                  {departments.map((dept, index) => (
                    <div
                      key={dept.id}
                      className={cn(
                        "p-4 rounded-lg border transition-all cursor-pointer",
                        index === currentDepartmentIndex
                          ? "bg-primary/10 border-primary shadow-sm"
                          : "bg-background hover:bg-muted/50",
                      )}
                      onClick={() => setCurrentDepartmentIndex(index)}
                      dir="rtl"
                    >
                      <div className="flex items-center justify-between">
                        <div className="space-y-1 text-right">
                          <h4 className="font-heading font-semibold">{dept.name}</h4>
                          <p className="text-sm text-muted-foreground">الفرع: {dept.branch}</p>
                          <div className="flex items-center gap-4 text-xs text-muted-foreground">
                            <span>المسؤول: {dept.manager}</span>
                            <span>الموظفين: {dept.employeeCount}</span>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button variant="outline" size="sm">
                            <Edit className="h-3 w-3" />
                          </Button>
                          <Badge variant={dept.isActive ? "default" : "secondary"}>
                            {dept.isActive ? "نشط" : "غير نشط"}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="definitions" className="space-y-6">
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            <Card dir="rtl">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <MapPin className="h-5 w-5 text-primary" />
                    المدن ({cities.length})
                  </CardTitle>
                  <Button className="erp-btn-primary" size="sm" onClick={() => setShowCityForm(!showCityForm)}>
                    <Plus className="h-4 w-4 mr-2" />
                    إضافة مدينة
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <UniversalToolbar
                  currentIndex={currentCityIndex}
                  totalRecords={cities.length}
                  onFirst={() => setCurrentCityIndex(0)}
                  onPrevious={() => setCurrentCityIndex(Math.max(0, currentCityIndex - 1))}
                  onNext={() => setCurrentCityIndex(Math.min(cities.length - 1, currentCityIndex + 1))}
                  onLast={() => setCurrentCityIndex(cities.length - 1)}
                  isFirstRecord={currentCityIndex === 0}
                  isLastRecord={currentCityIndex === cities.length - 1}
                  isSaving={false}
                />

                {showCityForm && (
                  <div className="bg-muted/30 rounded-lg p-4 border" dir="rtl">
                    <h3 className="font-heading font-semibold mb-4 text-right">إضافة مدينة جديدة</h3>
                    <form className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="text-right">
                          <Label className="erp-label text-right block">اسم المدينة *</Label>
                          <Input required className="erp-input text-right" placeholder="مثال: طولكرم" dir="rtl" />
                        </div>
                        <div className="text-right">
                          <Label className="erp-label text-right block">المنطقة</Label>
                          <Select dir="rtl">
                            <SelectTrigger className="erp-input text-right">
                              <SelectValue placeholder="اختر المنطقة" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="west-bank">الضفة الغربية</SelectItem>
                              <SelectItem value="gaza">قطاع غزة</SelectItem>
                              <SelectItem value="jerusalem">القدس</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <div className="flex justify-start gap-2 pt-2">
                        <Button type="submit" className="erp-btn-primary" size="sm">
                          حفظ المدينة
                        </Button>
                        <Button type="button" variant="outline" size="sm" onClick={() => setShowCityForm(false)}>
                          إلغاء
                        </Button>
                      </div>
                    </form>
                  </div>
                )}

                <div className="space-y-2 max-h-80 overflow-y-auto">
                  {cities.map((city, index) => (
                    <div
                      key={city.id}
                      className={cn(
                        "p-3 rounded-lg border transition-all cursor-pointer",
                        index === currentCityIndex ? "bg-primary/10 border-primary" : "bg-background hover:bg-muted/50",
                      )}
                      onClick={() => setCurrentCityIndex(index)}
                      dir="rtl"
                    >
                      <div className="flex items-center justify-between">
                        <div className="text-right">
                          <h4 className="font-medium">{city.name}</h4>
                          <p className="text-sm text-muted-foreground">{city.region}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button variant="outline" size="sm">
                            <Edit className="h-3 w-3" />
                          </Button>
                          <Badge variant={city.isActive ? "default" : "secondary"} className="text-xs">
                            {city.isActive ? "نشط" : "غير نشط"}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card dir="rtl">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Package className="h-5 w-5 text-primary" />
                    المستودعات ({warehouses.length})
                  </CardTitle>
                  <Button
                    className="erp-btn-primary"
                    size="sm"
                    onClick={() => setShowWarehouseForm(!showWarehouseForm)}
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    إضافة مستودع
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <UniversalToolbar
                  currentIndex={currentWarehouseIndex}
                  totalRecords={warehouses.length}
                  onFirst={() => setCurrentWarehouseIndex(0)}
                  onPrevious={() => setCurrentWarehouseIndex(Math.max(0, currentWarehouseIndex - 1))}
                  onNext={() => setCurrentWarehouseIndex(Math.min(warehouses.length - 1, currentWarehouseIndex + 1))}
                  onLast={() => setCurrentWarehouseIndex(warehouses.length - 1)}
                  isFirstRecord={currentWarehouseIndex === 0}
                  isLastRecord={currentWarehouseIndex === warehouses.length - 1}
                  isSaving={false}
                />

                {showWarehouseForm && (
                  <div className="bg-muted/30 rounded-lg p-4 border" dir="rtl">
                    <h3 className="font-heading font-semibold mb-4 text-right">إضافة مستودع جديد</h3>
                    <form className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="text-right">
                          <Label className="erp-label text-right block">اسم المستودع *</Label>
                          <Input
                            required
                            className="erp-input text-right"
                            placeholder="مثال: مستودع الخليل"
                            dir="rtl"
                          />
                        </div>
                        <div className="text-right">
                          <Label className="erp-label text-right block">الموقع</Label>
                          <Select dir="rtl">
                            <SelectTrigger className="erp-input text-right">
                              <SelectValue placeholder="اختر المدينة" />
                            </SelectTrigger>
                            <SelectContent>
                              {cities.map((city) => (
                                <SelectItem key={city.id} value={city.id}>
                                  {city.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="text-right">
                          <Label className="erp-label text-right block">السعة</Label>
                          <Input className="erp-input text-right" placeholder="مثال: 2000 متر مكعب" dir="rtl" />
                        </div>
                        <div className="text-right">
                          <Label className="erp-label text-right block">الطابعة</Label>
                          <Input className="erp-input text-right" placeholder="مثال: HP LaserJet" dir="rtl" />
                        </div>
                      </div>
                      <div className="flex justify-start gap-2 pt-2">
                        <Button type="submit" className="erp-btn-primary" size="sm">
                          حفظ المستودع
                        </Button>
                        <Button type="button" variant="outline" size="sm" onClick={() => setShowWarehouseForm(false)}>
                          إلغاء
                        </Button>
                      </div>
                    </form>
                  </div>
                )}

                <div className="space-y-3">
                  {warehouses.map((warehouse, index) => (
                    <div
                      key={warehouse.id}
                      className={cn(
                        "p-4 rounded-lg border transition-all cursor-pointer",
                        index === currentWarehouseIndex
                          ? "bg-primary/10 border-primary shadow-sm"
                          : "bg-background hover:bg-muted/50",
                      )}
                      onClick={() => setCurrentWarehouseIndex(index)}
                      dir="rtl"
                    >
                      <div className="flex items-center justify-between">
                        <div className="space-y-1 text-right">
                          <h4 className="font-heading font-semibold">{warehouse.name}</h4>
                          <p className="text-sm text-muted-foreground flex items-center gap-1">
                            <MapPin className="h-3 w-3" />
                            {warehouse.location}
                          </p>
                          <div className="flex items-center gap-4 text-xs text-muted-foreground">
                            <span>السعة: {warehouse.capacity}</span>
                            <span>الطابعة: {warehouse.printer}</span>
                          </div>
                          <div className="flex flex-wrap gap-1 mt-2">
                            {warehouse.departments.map((dept) => (
                              <Badge key={dept} variant="outline" className="text-xs">
                                {dept}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button variant="outline" size="sm">
                            <Edit className="h-3 w-3" />
                          </Button>
                          <Badge variant={warehouse.isActive ? "default" : "secondary"}>
                            {warehouse.isActive ? "نشط" : "غير نشط"}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Customer Categories */}
            <Card dir="rtl">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2 text-base">
                    <Users className="h-4 w-4 text-primary" />
                    تصنيفات الزبائن
                  </CardTitle>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setShowCustomerCategoryForm(!showCustomerCategoryForm)}
                  >
                    <Plus className="h-3 w-3" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {showCustomerCategoryForm && (
                  <div className="bg-muted/30 rounded-lg p-3 border" dir="rtl">
                    <form className="space-y-3">
                      <div className="text-right">
                        <Label className="erp-label text-sm text-right block">اسم التصنيف</Label>
                        <Input className="erp-input text-right" placeholder="مثال: زبائن الجملة" dir="rtl" />
                      </div>
                      <div className="text-right">
                        <Label className="erp-label text-sm text-right block">نسبة الخصم (%)</Label>
                        <Input type="number" className="erp-input text-right" placeholder="10" dir="rtl" />
                      </div>
                      <div className="flex justify-start gap-2">
                        <Button type="submit" size="sm" className="erp-btn-primary">
                          حفظ
                        </Button>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => setShowCustomerCategoryForm(false)}
                        >
                          إلغاء
                        </Button>
                      </div>
                    </form>
                  </div>
                )}

                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {customerCategories.map((category) => (
                    <div
                      key={category.id}
                      className="p-3 rounded-lg border bg-background hover:bg-muted/50 transition-colors"
                      dir="rtl"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full" style={{ backgroundColor: category.color }} />
                          <div className="text-right">
                            <h4 className="font-medium text-sm">{category.name}</h4>
                            <p className="text-xs text-muted-foreground">خصم {category.discount}%</p>
                          </div>
                        </div>
                        <Button variant="outline" size="sm">
                          <Edit className="h-3 w-3" />
                        </Button>
                      </div>
                      <div className="mt-2">
                        <Badge variant="outline" className="text-xs">
                          {category.customers.length} زبون
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Supplier Categories */}
            <Card dir="rtl">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2 text-base">
                    <Package className="h-4 w-4 text-primary" />
                    تصنيفات الموردين
                  </CardTitle>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setShowSupplierCategoryForm(!showSupplierCategoryForm)}
                  >
                    <Plus className="h-3 w-3" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {showSupplierCategoryForm && (
                  <div className="bg-muted/30 rounded-lg p-3 border" dir="rtl">
                    <form className="space-y-3">
                      <div className="text-right">
                        <Label className="erp-label text-sm text-right block">اسم التصنيف</Label>
                        <Input className="erp-input text-right" placeholder="مثال: موردين أوروبيين" dir="rtl" />
                      </div>
                      <div className="text-right">
                        <Label className="erp-label text-sm text-right block">شروط الدفع</Label>
                        <Input className="erp-input text-right" placeholder="مثال: 30 يوم" dir="rtl" />
                      </div>
                      <div className="flex justify-start gap-2">
                        <Button type="submit" size="sm" className="erp-btn-primary">
                          حفظ
                        </Button>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => setShowSupplierCategoryForm(false)}
                        >
                          إلغاء
                        </Button>
                      </div>
                    </form>
                  </div>
                )}

                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {supplierCategories.map((category) => (
                    <div
                      key={category.id}
                      className="p-3 rounded-lg border bg-background hover:bg-muted/50 transition-colors"
                      dir="rtl"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full" style={{ backgroundColor: category.color }} />
                          <div className="text-right">
                            <h4 className="font-medium text-sm">{category.name}</h4>
                            <p className="text-xs text-muted-foreground">{category.paymentTerms}</p>
                          </div>
                        </div>
                        <Button variant="outline" size="sm">
                          <Edit className="h-3 w-3" />
                        </Button>
                      </div>
                      <div className="mt-2">
                        <Badge variant="outline" className="text-xs">
                          {category.suppliers.length} مورد
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Product Categories */}
            <Card dir="rtl">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2 text-base">
                    <Package className="h-4 w-4 text-primary" />
                    تصنيفات الأصناف
                  </CardTitle>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setShowProductCategoryForm(!showProductCategoryForm)}
                  >
                    <Plus className="h-3 w-3" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {showProductCategoryForm && (
                  <div className="bg-muted/30 rounded-lg p-3 border" dir="rtl">
                    <form className="space-y-3">
                      <div className="text-right">
                        <Label className="erp-label text-sm text-right block">اسم التصنيف</Label>
                        <Input className="erp-input text-right" placeholder="مثال: مواد غذائية" dir="rtl" />
                      </div>
                      <div className="text-right">
                        <Label className="erp-label text-sm text-right block">معدل الضريبة (%)</Label>
                        <Input type="number" className="erp-input text-right" placeholder="16" dir="rtl" />
                      </div>
                      <div className="flex justify-start gap-2">
                        <Button type="submit" size="sm" className="erp-btn-primary">
                          حفظ
                        </Button>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => setShowProductCategoryForm(false)}
                        >
                          إلغاء
                        </Button>
                      </div>
                    </form>
                  </div>
                )}

                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {productCategories.map((category) => (
                    <div
                      key={category.id}
                      className="p-3 rounded-lg border bg-background hover:bg-muted/50 transition-colors"
                      dir="rtl"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full" style={{ backgroundColor: category.color }} />
                          <div className="text-right">
                            <h4 className="font-medium text-sm">{category.name}</h4>
                            <p className="text-xs text-muted-foreground">ضريبة {category.taxRate}%</p>
                          </div>
                        </div>
                        <Button variant="outline" size="sm">
                          <Edit className="h-3 w-3" />
                        </Button>
                      </div>
                      <div className="mt-2">
                        <Badge variant="outline" className="text-xs">
                          {category.products.length} صنف
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          <Card dir="rtl">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <CreditCard className="h-5 w-5 text-primary" />
                  العملات ({currencies.length})
                </CardTitle>
                <Button className="erp-btn-primary" size="sm" onClick={() => setShowCurrencyForm(!showCurrencyForm)}>
                  <Plus className="h-4 w-4 mr-2" />
                  إضافة عملة
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {showCurrencyForm && (
                <div className="bg-muted/30 rounded-lg p-4 border" dir="rtl">
                  <h3 className="font-heading font-semibold mb-4 text-right">إضافة عملة جديدة</h3>
                  <form className="space-y-4">
                    <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                      <div className="text-right">
                        <Label className="erp-label text-right block">رمز العملة *</Label>
                        <Input className="erp-input text-right" placeholder="USD" dir="rtl" />
                      </div>
                      <div className="text-right">
                        <Label className="erp-label text-right block">اسم العملة *</Label>
                        <Input className="erp-input text-right" placeholder="دولار أمريكي" dir="rtl" />
                      </div>
                      <div className="text-right">
                        <Label className="erp-label text-right block">سعر البيع</Label>
                        <Input
                          type="number"
                          step="0.01"
                          className="erp-input text-right"
                          placeholder="3.65"
                          dir="rtl"
                        />
                      </div>
                      <div className="text-right">
                        <Label className="erp-label text-right block">سعر الشراء</Label>
                        <Input
                          type="number"
                          step="0.01"
                          className="erp-input text-right"
                          placeholder="3.60"
                          dir="rtl"
                        />
                      </div>
                      <div className="text-right">
                        <Label className="erp-label text-right block">سعر الصرف</Label>
                        <Input
                          type="number"
                          step="0.01"
                          className="erp-input text-right"
                          placeholder="3.62"
                          dir="rtl"
                        />
                      </div>
                    </div>
                    <div className="flex justify-start gap-2 pt-2">
                      <Button type="submit" className="erp-btn-primary" size="sm">
                        حفظ العملة
                      </Button>
                      <Button type="button" variant="outline" size="sm" onClick={() => setShowCurrencyForm(false)}>
                        إلغاء
                      </Button>
                    </div>
                  </form>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {currencies.map((currency) => (
                  <div
                    key={currency.code}
                    className="p-4 rounded-lg border bg-background hover:bg-muted/50 transition-colors"
                    dir="rtl"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <CreditCard className="h-4 w-4 text-primary" />
                        <span className="font-mono font-bold">{currency.code}</span>
                      </div>
                      {currency.isDefault && (
                        <Badge variant="default" className="text-xs">
                          افتراضي
                        </Badge>
                      )}
                    </div>
                    <h4 className="font-medium mb-3 text-right">{currency.name}</h4>
                    <div className="space-y-1 text-sm">
                      <div className="flex justify-between">
                        <span className="font-mono">{currency.sellPrice.toFixed(2)}</span>
                        <span className="text-muted-foreground">:البيع</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-mono">{currency.buyPrice.toFixed(2)}</span>
                        <span className="text-muted-foreground">:الشراء</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-mono">{currency.exchangeRate.toFixed(2)}</span>
                        <span className="text-muted-foreground">:الصرف</span>
                      </div>
                    </div>
                    <div className="flex justify-start mt-3">
                      <Button variant="outline" size="sm">
                        <Edit className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Workflow Stages Management Tab */}
        <TabsContent value="workflow-stages">
          <WorkflowStagesManagement />
        </TabsContent>

        {/* Workflow Sequences Management Tab */}
        <TabsContent value="workflow-sequences">
          <WorkflowSequencesManagement />
        </TabsContent>
      </Tabs>
    </div>
  )
}

export { Definitions }
export default Definitions
