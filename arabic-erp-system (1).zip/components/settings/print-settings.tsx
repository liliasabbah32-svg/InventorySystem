"use client"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { Separator } from "@/components/ui/separator"
import { Printer, FileText, Settings, ImageIcon, Layout, Save, Loader2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface PrintSettings {
  id?: number
  company_id: number
  paper_size: string
  orientation: string
  margin_top: number
  margin_bottom: number
  margin_left: number
  margin_right: number
  show_header: boolean
  show_footer: boolean
  show_logo: boolean
  show_company_info: boolean
  show_page_numbers: boolean
  show_print_date: boolean
  show_payment_terms: boolean
  show_bank_details: boolean
  font_family: string
  font_size: number
  primary_color: string
  secondary_color: string
  use_colors: boolean
  print_copies: number
  auto_print: boolean
  default_printer: string
  invoice_template: string
  logo_position: string
  logo_size: string
  header_text: string
  footer_text: string
}

export default function PrintSettings() {
  const { toast } = useToast()
  const [settings, setSettings] = useState<PrintSettings>({
    company_id: 1,
    paper_size: "A4",
    orientation: "portrait",
    margin_top: 20,
    margin_bottom: 20,
    margin_left: 20,
    margin_right: 20,
    show_header: true,
    show_footer: true,
    show_logo: true,
    show_company_info: true,
    show_page_numbers: true,
    show_print_date: true,
    show_payment_terms: true,
    show_bank_details: true,
    font_family: "Arial",
    font_size: 12,
    primary_color: "#000000",
    secondary_color: "#666666",
    use_colors: false,
    print_copies: 1,
    auto_print: false,
    default_printer: "",
    invoice_template: "standard",
    logo_position: "top-left",
    logo_size: "medium",
    header_text: "",
    footer_text: "",
  })
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)

  const fetchPrintSettings = async () => {
    try {
      setLoading(true)
      const response = await fetch("/api/settings/print")
      if (response.ok) {
        const data = await response.json()
        if (data && Object.keys(data).length > 0) {
          setSettings(data)
        }
      }
    } catch (error) {
      console.error("Error fetching print settings:", error)
      toast({
        title: "خطأ",
        description: "فشل في تحميل إعدادات الطباعة",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const savePrintSettings = async () => {
    try {
      setSaving(true)
      const method = settings.id ? "PUT" : "POST"
      const response = await fetch("/api/settings/print", {
        method,
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(settings),
      })

      if (response.ok) {
        const result = await response.json()
        setSettings(result)
        toast({
          title: "تم الحفظ",
          description: "تم حفظ إعدادات الطباعة بنجاح",
        })
      } else {
        throw new Error("فشل في حفظ الإعدادات")
      }
    } catch (error) {
      console.error("Error saving print settings:", error)
      toast({
        title: "خطأ",
        description: "فشل في حفظ إعدادات الطباعة",
        variant: "destructive",
      })
    } finally {
      setSaving(false)
    }
  }

  useEffect(() => {
    fetchPrintSettings()
  }, [])

  const printSummary = [
    {
      title: "حجم الورق",
      value: settings.paper_size,
      icon: FileText,
      color: "text-blue-600",
    },
    {
      title: "الطابعة الافتراضية",
      value: settings.default_printer || "غير محدد",
      icon: Printer,
      color: "text-green-600",
    },
    { title: "قالب الفاتورة", value: settings.invoice_template, icon: Layout, color: "text-purple-600" },
    { title: "عدد النسخ", value: settings.print_copies.toString(), icon: ImageIcon, color: "text-orange-600" },
  ]

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64" dir="rtl">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
          <p>جاري تحميل إعدادات الطباعة...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6 p-6" dir="rtl">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">إعدادات الطباعة</h1>
          <p className="text-gray-600">إدارة إعدادات طباعة السندات والتقارير والنماذج</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={fetchPrintSettings} disabled={loading}>
            <Settings className="w-4 h-4 ml-2" />
            إعادة تحميل
          </Button>
          <Button onClick={savePrintSettings} disabled={saving} className="bg-blue-600 hover:bg-blue-700">
            {saving ? (
              <>
                <Loader2 className="w-4 h-4 ml-2 animate-spin" />
                جاري الحفظ...
              </>
            ) : (
              <>
                <Save className="w-4 h-4 ml-2" />
                حفظ الإعدادات
              </>
            )}
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {printSummary.map((item, index) => (
          <Card key={index}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{item.title}</p>
                  <p className={`text-2xl font-bold ${item.color}`}>{item.value}</p>
                </div>
                <div className={`p-2 ${item.color.replace("text-", "bg-").replace("-600", "-100")} rounded-lg`}>
                  <item.icon className={`w-5 h-5 ${item.color}`} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Tabs defaultValue="basic" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="basic">الإعدادات الأساسية</TabsTrigger>
          <TabsTrigger value="layout">التخطيط والهوامش</TabsTrigger>
          <TabsTrigger value="display">خيارات العرض</TabsTrigger>
          <TabsTrigger value="advanced">إعدادات متقدمة</TabsTrigger>
        </TabsList>

        <TabsContent value="basic">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5" />
                الإعدادات الأساسية للطباعة
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>الطابعة الافتراضية</Label>
                  <Input
                    value={settings.default_printer}
                    onChange={(e) => setSettings({ ...settings, default_printer: e.target.value })}
                    placeholder="اسم الطابعة"
                  />
                </div>

                <div className="space-y-2">
                  <Label>نوع الخط</Label>
                  <Select
                    value={settings.font_family}
                    onValueChange={(value) => setSettings({ ...settings, font_family: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Arial">Arial</SelectItem>
                      <SelectItem value="Times New Roman">Times New Roman</SelectItem>
                      <SelectItem value="Tahoma">Tahoma</SelectItem>
                      <SelectItem value="Traditional Arabic">Traditional Arabic</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>حجم الخط</Label>
                  <Select
                    value={settings.font_size.toString()}
                    onValueChange={(value) => setSettings({ ...settings, font_size: Number.parseInt(value) })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="8">8 نقطة</SelectItem>
                      <SelectItem value="10">10 نقطة</SelectItem>
                      <SelectItem value="12">12 نقطة</SelectItem>
                      <SelectItem value="14">14 نقطة</SelectItem>
                      <SelectItem value="16">16 نقطة</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>حجم الورق</Label>
                  <Select
                    value={settings.paper_size}
                    onValueChange={(value) => setSettings({ ...settings, paper_size: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="A4">A4 (210 × 297 مم)</SelectItem>
                      <SelectItem value="A5">A5 (148 × 210 مم)</SelectItem>
                      <SelectItem value="Letter">Letter (216 × 279 مم)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>اتجاه الطباعة</Label>
                  <Select
                    value={settings.orientation}
                    onValueChange={(value) => setSettings({ ...settings, orientation: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="portrait">عمودي (Portrait)</SelectItem>
                      <SelectItem value="landscape">أفقي (Landscape)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>عدد النسخ</Label>
                  <Input
                    type="number"
                    value={settings.print_copies}
                    onChange={(e) => setSettings({ ...settings, print_copies: Number.parseInt(e.target.value) || 1 })}
                    min="1"
                    max="10"
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="layout">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Layout className="w-5 h-5" />
                التخطيط والهوامش
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="space-y-2">
                  <Label>الهامش العلوي (مم)</Label>
                  <Input
                    type="number"
                    value={settings.margin_top}
                    onChange={(e) => setSettings({ ...settings, margin_top: Number.parseFloat(e.target.value) || 0 })}
                    min="0"
                    max="50"
                  />
                </div>
                <div className="space-y-2">
                  <Label>الهامش السفلي (مم)</Label>
                  <Input
                    type="number"
                    value={settings.margin_bottom}
                    onChange={(e) =>
                      setSettings({ ...settings, margin_bottom: Number.parseFloat(e.target.value) || 0 })
                    }
                    min="0"
                    max="50"
                  />
                </div>
                <div className="space-y-2">
                  <Label>الهامش الأيمن (مم)</Label>
                  <Input
                    type="number"
                    value={settings.margin_right}
                    onChange={(e) => setSettings({ ...settings, margin_right: Number.parseFloat(e.target.value) || 0 })}
                    min="0"
                    max="50"
                  />
                </div>
                <div className="space-y-2">
                  <Label>الهامش الأيسر (مم)</Label>
                  <Input
                    type="number"
                    value={settings.margin_left}
                    onChange={(e) => setSettings({ ...settings, margin_left: Number.parseFloat(e.target.value) || 0 })}
                    min="0"
                    max="50"
                  />
                </div>
              </div>

              <Separator />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>موضع الشعار</Label>
                  <Select
                    value={settings.logo_position}
                    onValueChange={(value) => setSettings({ ...settings, logo_position: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="top-left">أعلى اليمين</SelectItem>
                      <SelectItem value="top-center">أعلى الوسط</SelectItem>
                      <SelectItem value="top-right">أعلى اليسار</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>حجم الشعار</Label>
                  <Select
                    value={settings.logo_size}
                    onValueChange={(value) => setSettings({ ...settings, logo_size: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="small">صغير</SelectItem>
                      <SelectItem value="medium">متوسط</SelectItem>
                      <SelectItem value="large">كبير</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>نص الترويسة</Label>
                  <Textarea
                    value={settings.header_text}
                    onChange={(e) => setSettings({ ...settings, header_text: e.target.value })}
                    placeholder="نص إضافي في الترويسة"
                    rows={2}
                  />
                </div>

                <div className="space-y-2">
                  <Label>نص التذييل</Label>
                  <Textarea
                    value={settings.footer_text}
                    onChange={(e) => setSettings({ ...settings, footer_text: e.target.value })}
                    placeholder="نص إضافي في التذييل"
                    rows={2}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="display">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="w-5 h-5" />
                خيارات العرض
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">عناصر الترويسة</h3>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <Label>إظهار الترويسة</Label>
                      <Switch
                        checked={settings.show_header}
                        onCheckedChange={(checked) => setSettings({ ...settings, show_header: checked })}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label>إظهار الشعار</Label>
                      <Switch
                        checked={settings.show_logo}
                        onCheckedChange={(checked) => setSettings({ ...settings, show_logo: checked })}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label>إظهار معلومات الشركة</Label>
                      <Switch
                        checked={settings.show_company_info}
                        onCheckedChange={(checked) => setSettings({ ...settings, show_company_info: checked })}
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">عناصر التذييل</h3>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <Label>إظهار التذييل</Label>
                      <Switch
                        checked={settings.show_footer}
                        onCheckedChange={(checked) => setSettings({ ...settings, show_footer: checked })}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label>إظهار أرقام الصفحات</Label>
                      <Switch
                        checked={settings.show_page_numbers}
                        onCheckedChange={(checked) => setSettings({ ...settings, show_page_numbers: checked })}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label>إظهار تاريخ الطباعة</Label>
                      <Switch
                        checked={settings.show_print_date}
                        onCheckedChange={(checked) => setSettings({ ...settings, show_print_date: checked })}
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">معلومات إضافية</h3>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <Label>إظهار شروط الدفع</Label>
                      <Switch
                        checked={settings.show_payment_terms}
                        onCheckedChange={(checked) => setSettings({ ...settings, show_payment_terms: checked })}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label>إظهار تفاصيل البنك</Label>
                      <Switch
                        checked={settings.show_bank_details}
                        onCheckedChange={(checked) => setSettings({ ...settings, show_bank_details: checked })}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="advanced">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="w-5 h-5" />
                الإعدادات المتقدمة
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">الألوان</h3>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <Label>استخدام الألوان</Label>
                      <Switch
                        checked={settings.use_colors}
                        onCheckedChange={(checked) => setSettings({ ...settings, use_colors: checked })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>اللون الأساسي</Label>
                      <Input
                        type="color"
                        value={settings.primary_color}
                        onChange={(e) => setSettings({ ...settings, primary_color: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>اللون الثانوي</Label>
                      <Input
                        type="color"
                        value={settings.secondary_color}
                        onChange={(e) => setSettings({ ...settings, secondary_color: e.target.value })}
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">خيارات متقدمة</h3>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <Label>الطباعة التلقائية</Label>
                      <Switch
                        checked={settings.auto_print}
                        onCheckedChange={(checked) => setSettings({ ...settings, auto_print: checked })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>قالب الفاتورة</Label>
                      <Select
                        value={settings.invoice_template}
                        onValueChange={(value) => setSettings({ ...settings, invoice_template: value })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="standard">قياسي</SelectItem>
                          <SelectItem value="modern">حديث</SelectItem>
                          <SelectItem value="classic">كلاسيكي</SelectItem>
                          <SelectItem value="minimal">بسيط</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
