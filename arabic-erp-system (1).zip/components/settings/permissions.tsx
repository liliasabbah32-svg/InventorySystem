"use client"

import { useState, useEffect, useMemo } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
  PaginationEllipsis,
} from "@/components/ui/pagination"
import { Search, RefreshCw, Users, UserPlus } from "lucide-react"

interface User {
  id: string
  user_id: string
  username: string
  email: string
  full_name: string
  role: string
  department: string
  phone?: string
  last_login?: string
  is_active: boolean
  permissions?: any
  created_at: string
}

interface ActivityLog {
  id: number
  datetime: string
  user: string
  action: string
  module: string
  details: string
  ip: string
  status: string
}

const activityLogs: ActivityLog[] = [
  {
    id: 1,
    datetime: "2024/01/15 14:30:25",
    user: "محمد أحمد",
    action: "إضافة",
    module: "الزبائن",
    details: "إضافة زبون جديد: أحمد محمد علي",
    ip: "192.168.1.100",
    status: "نجح",
  },
  {
    id: 2,
    datetime: "2024/01/15 14:25:12",
    user: "علي حسن",
    action: "تعديل",
    module: "طلبيات المبيعات",
    details: "تعديل طلبية رقم SO-2024-001",
    ip: "192.168.1.105",
    status: "نجح",
  },
  {
    id: 3,
    datetime: "2024/01/15 14:20:45",
    user: "محمد أحمد",
    action: "محاولة حذف",
    module: "الأصناف",
    details: "محاولة حذف صنف: لابتوب ديل",
    ip: "192.168.1.100",
    status: "فشل - لا توجد صلاحية",
  },
]

export default function Permissions() {
  const [users, setUsers] = useState<User[]>([])
  const [selectedUser, setSelectedUser] = useState("")
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")
  const [activeTab, setActiveTab] = useState("users")

  const [searchTerm, setSearchTerm] = useState("")
  const [currentPage, setCurrentPage] = useState(1)
  const [usersPerPage] = useState(10)
  const [roleFilter, setRoleFilter] = useState("all")
  const [statusFilter, setStatusFilter] = useState("all")

  const filteredUsers = useMemo(() => {
    return users.filter((user) => {
      const matchesSearch =
        user.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        false ||
        user.username?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        false ||
        user.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        false ||
        user.department?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        false

      const matchesRole = roleFilter === "all" || user.role === roleFilter
      const matchesStatus =
        statusFilter === "all" ||
        (statusFilter === "active" && user.is_active) ||
        (statusFilter === "inactive" && !user.is_active)

      return matchesSearch && matchesRole && matchesStatus
    })
  }, [users, searchTerm, roleFilter, statusFilter])

  const totalPages = Math.ceil(filteredUsers.length / usersPerPage)
  const startIndex = (currentPage - 1) * usersPerPage
  const paginatedUsers = filteredUsers.slice(startIndex, startIndex + usersPerPage)

  useEffect(() => {
    setCurrentPage(1)
  }, [searchTerm, roleFilter, statusFilter])

  const fetchUsers = async () => {
    try {
      setLoading(true)
      console.log("[v0] Starting to fetch users from API...")
      const response = await fetch("/api/settings/user")

      console.log("[v0] API response status:", response.status)
      console.log("[v0] API response ok:", response.ok)

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}))
        console.error("[v0] API returned error:", errorData)
        throw new Error(errorData.error || "فشل في جلب بيانات المستخدمين")
      }

      const userData = await response.json()
      console.log("[v0] Fetched users from database:", userData)
      console.log("[v0] Number of users:", userData.length)

      setUsers(userData)

      if (userData.length > 0 && !selectedUser) {
        setSelectedUser(userData[0].user_id || userData[0].id)
      }

      setError("")
    } catch (err) {
      console.error("[v0] Error fetching users:", err)
      console.error("[v0] Error type:", typeof err)
      console.error("[v0] Error message:", err instanceof Error ? err.message : String(err))
      setError(err instanceof Error ? err.message : "حدث خطأ في جلب بيانات المستخدمين")
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchUsers()
  }, [])

  const handleRefreshUsers = () => {
    fetchUsers()
  }

  const getUserStatus = (user: User) => {
    if (!user.is_active) return { status: "غير نشط", color: "bg-red-100 text-red-800" }

    const lastLogin = user.last_login
    if (!lastLogin) return { status: "لم يسجل دخول", color: "bg-gray-100 text-gray-800" }

    const loginDate = new Date(lastLogin)
    const now = new Date()
    const diffMinutes = Math.floor((now.getTime() - loginDate.getTime()) / (1000 * 60))

    if (diffMinutes < 30) return { status: "متصل", color: "bg-emerald-100 text-emerald-800" }
    if (diffMinutes < 1440) return { status: `قبل ${diffMinutes} دقيقة`, color: "bg-yellow-100 text-yellow-800" }

    const diffDays = Math.floor(diffMinutes / 1440)
    return { status: `قبل ${diffDays} يوم`, color: "bg-gray-100 text-gray-800" }
  }

  const getUserAvatar = (user: User) => {
    return user.full_name ? user.full_name.charAt(0) : user.username.charAt(0)
  }

  const savePermissions = async () => {
    try {
      console.log("[v0] Saving permissions for user:", selectedUser)

      if (!selectedUser) {
        alert("يرجى اختيار مستخدم أولاً")
        return
      }

      const permissionsData = {
        customers: {
          view:
            (document.querySelector('input[data-module="customers"][data-action="view"]') as HTMLInputElement)
              ?.checked || false,
          add:
            (document.querySelector('input[data-module="customers"][data-action="add"]') as HTMLInputElement)
              ?.checked || false,
          edit:
            (document.querySelector('input[data-module="customers"][data-action="edit"]') as HTMLInputElement)
              ?.checked || false,
        },
        suppliers: {
          view:
            (document.querySelector('input[data-module="suppliers"][data-action="view"]') as HTMLInputElement)
              ?.checked || false,
          add:
            (document.querySelector('input[data-module="suppliers"][data-action="add"]') as HTMLInputElement)
              ?.checked || false,
          edit:
            (document.querySelector('input[data-module="suppliers"][data-action="edit"]') as HTMLInputElement)
              ?.checked || false,
        },
        products: {
          view:
            (document.querySelector('input[data-module="products"][data-action="view"]') as HTMLInputElement)
              ?.checked || false,
          add:
            (document.querySelector('input[data-module="products"][data-action="add"]') as HTMLInputElement)?.checked ||
            false,
          edit:
            (document.querySelector('input[data-module="products"][data-action="edit"]') as HTMLInputElement)
              ?.checked || false,
        },
        sales_orders: {
          view:
            (document.querySelector('input[data-module="sales_orders"][data-action="view"]') as HTMLInputElement)
              ?.checked || false,
          add:
            (document.querySelector('input[data-module="sales_orders"][data-action="add"]') as HTMLInputElement)
              ?.checked || false,
          edit:
            (document.querySelector('input[data-module="sales_orders"][data-action="edit"]') as HTMLInputElement)
              ?.checked || false,
        },
        purchase_orders: {
          view:
            (document.querySelector('input[data-module="purchase_orders"][data-action="view"]') as HTMLInputElement)
              ?.checked || false,
          add:
            (document.querySelector('input[data-module="purchase_orders"][data-action="add"]') as HTMLInputElement)
              ?.checked || false,
          edit:
            (document.querySelector('input[data-module="purchase_orders"][data-action="edit"]') as HTMLInputElement)
              ?.checked || false,
        },
        exchange_rates: {
          view:
            (document.querySelector('input[data-module="exchange_rates"][data-action="view"]') as HTMLInputElement)
              ?.checked || false,
          add:
            (document.querySelector('input[data-module="exchange_rates"][data-action="add"]') as HTMLInputElement)
              ?.checked || false,
          edit:
            (document.querySelector('input[data-module="exchange_rates"][data-action="edit"]') as HTMLInputElement)
              ?.checked || false,
        },
        reports: {
          orders:
            (document.querySelector('input[data-module="reports"][data-action="orders"]') as HTMLInputElement)
              ?.checked || false,
          export:
            (document.querySelector('input[data-module="reports"][data-action="export"]') as HTMLInputElement)
              ?.checked || false,
          print:
            (document.querySelector('input[data-module="reports"][data-action="print"]') as HTMLInputElement)
              ?.checked || false,
        },
        products_reports: {
          view:
            (document.querySelector('input[data-module="products_reports"][data-action="view"]') as HTMLInputElement)
              ?.checked || false,
          export:
            (document.querySelector('input[data-module="products_reports"][data-action="export"]') as HTMLInputElement)
              ?.checked || false,
          print:
            (document.querySelector('input[data-module="products_reports"][data-action="print"]') as HTMLInputElement)
              ?.checked || false,
        },
      }

      console.log("[v0] Permissions data to save:", permissionsData)

      const response = await fetch("/api/settings/user", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          user_id: selectedUser,
          permissions: permissionsData,
        }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "فشل في حفظ الصلاحيات")
      }

      const result = await response.json()
      console.log("[v0] Permissions saved successfully:", result)
      alert("تم حفظ الصلاحيات بنجاح")

      // Refresh users list to show updated data
      await fetchUsers()
    } catch (err) {
      console.error("[v0] Error saving permissions:", err)
      alert(`حدث خطأ في حفظ الصلاحيات: ${err instanceof Error ? err.message : "خطأ غير معروف"}`)
    }
  }

  const handleEditPermissions = (userId: string) => {
    console.log("[v0] Editing permissions for user:", userId)
    setSelectedUser(userId)
    setActiveTab("permissions")
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <h1 className="text-2xl font-bold text-gray-900">إدارة المستخدمين والصلاحيات</h1>
        <div className="flex items-center justify-center p-8">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-600 mx-auto mb-4"></div>
            <p>جاري تحميل بيانات المستخدمين...</p>
          </div>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="space-y-6">
        <h1 className="text-2xl font-bold text-gray-900">إدارة المستخدمين والصلاحيات</h1>
        <div className="flex items-center justify-center p-8">
          <div className="text-center text-red-600">
            <p>{error}</p>
            <Button onClick={fetchUsers} className="mt-4">
              إعادة المحاولة
            </Button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="h-full flex flex-col space-y-6" dir="rtl">
      <div className="flex items-center justify-between flex-shrink-0">
        <h1 className="text-2xl font-bold text-gray-900">إدارة المستخدمين والصلاحيات</h1>
        <div className="flex items-center gap-2">
          <Button onClick={handleRefreshUsers} variant="outline" size="sm">
            <RefreshCw className="h-4 w-4 ml-2" />
            تحديث
          </Button>
          <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700">
            <UserPlus className="h-4 w-4 ml-2" />
            إضافة مستخدم
          </Button>
        </div>
      </div>

      <div className="flex-1 overflow-auto">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full h-full">
          <TabsList className="grid w-full grid-cols-3 flex-shrink-0">
            <TabsTrigger value="users">المستخدمون والأدوار</TabsTrigger>
            <TabsTrigger value="permissions">الصلاحيات المخصصة</TabsTrigger>
            <TabsTrigger value="logs">سجل العمليات</TabsTrigger>
          </TabsList>

          <TabsContent value="users" className="mt-4">
            <Card>
              <CardHeader className="flex-shrink-0">
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Users className="h-5 w-5" />
                    نظام الأدوار المتدرج
                  </CardTitle>
                  <Badge variant="secondary" className="text-sm">
                    {filteredUsers.length} من {users.length} مستخدم
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="flex-1 overflow-auto">
                <div className="space-y-4 mb-6 flex-shrink-0">
                  <div className="flex flex-col sm:flex-row gap-4">
                    <div className="flex-1 relative">
                      <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                      <Input
                        placeholder="البحث في المستخدمين..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pr-10"
                      />
                    </div>
                    <div className="flex gap-2">
                      <Select value={roleFilter} onValueChange={setRoleFilter}>
                        <SelectTrigger className="w-40">
                          <SelectValue placeholder="فلترة بالدور" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">جميع الأدوار</SelectItem>
                          <SelectItem value="مدير عام">مدير عام</SelectItem>
                          <SelectItem value="مدير قسم">مدير قسم</SelectItem>
                          <SelectItem value="موظف">موظف</SelectItem>
                          <SelectItem value="عميل">عميل</SelectItem>
                        </SelectContent>
                      </Select>
                      <Select value={statusFilter} onValueChange={setStatusFilter}>
                        <SelectTrigger className="w-32">
                          <SelectValue placeholder="الحالة" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">جميع الحالات</SelectItem>
                          <SelectItem value="active">نشط</SelectItem>
                          <SelectItem value="inactive">غير نشط</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6 flex-shrink-0">
                  <div className="p-4 border rounded-lg text-center cursor-pointer hover:bg-gray-50">
                    <div className="text-2xl mb-2">👑</div>
                    <div className="font-medium">مدير عام</div>
                  </div>
                  <div className="p-4 border rounded-lg text-center cursor-pointer hover:bg-gray-50">
                    <div className="text-2xl mb-2">📊</div>
                    <div className="font-medium">مدير قسم</div>
                  </div>
                  <div className="p-4 border rounded-lg text-center cursor-pointer hover:bg-gray-50">
                    <div className="text-2xl mb-2">👤</div>
                    <div className="font-medium">موظف</div>
                  </div>
                  <div className="p-4 border rounded-lg text-center cursor-pointer hover:bg-gray-50">
                    <div className="text-2xl mb-2">🛍️</div>
                    <div className="font-medium">عميل</div>
                  </div>
                </div>

                <div className="overflow-x-auto max-h-96 overflow-y-auto border rounded-lg">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-right p-3">م</th>
                        <th className="text-right p-3">المستخدم</th>
                        <th className="text-right p-3">الدور الحالي</th>
                        <th className="text-right p-3">القسم</th>
                        <th className="text-right p-3">الهاتف</th>
                        <th className="text-right p-3">آخر دخول</th>
                        <th className="text-right p-3">الحالة</th>
                        <th className="text-right p-3">الإجراءات</th>
                      </tr>
                    </thead>
                    <tbody>
                      {paginatedUsers.map((user, index) => {
                        const userStatus = getUserStatus(user)
                        const serialNumber = startIndex + index + 1
                        return (
                          <tr key={user.id} className="border-b hover:bg-gray-50">
                            <td className="p-3 font-medium text-gray-600">{serialNumber}</td>
                            <td className="p-3">
                              <div className="flex items-center gap-3">
                                <div className="w-8 h-8 bg-emerald-600 rounded-full flex items-center justify-center text-white font-bold">
                                  {getUserAvatar(user)}
                                </div>
                                <div>
                                  <div className="font-medium">{user.full_name || user.username}</div>
                                  <div className="text-sm text-gray-500">{user.email}</div>
                                </div>
                              </div>
                            </td>
                            <td className="p-3">
                              <Badge className="bg-amber-100 text-amber-900">👑 {user.role}</Badge>
                            </td>
                            <td className="p-3">{user.department || "غير محدد"}</td>
                            <td className="p-3">{user.phone || "غير محدد"}</td>
                            <td className="p-3">{userStatus.status}</td>
                            <td className="p-3">
                              <Badge className={userStatus.color}>{user.is_active ? "نشط" : "غير نشط"}</Badge>
                            </td>
                            <td className="p-3">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleEditPermissions(user.user_id || user.id)}
                              >
                                تعديل الصلاحيات
                              </Button>
                            </td>
                          </tr>
                        )
                      })}
                    </tbody>
                  </table>
                </div>

                {totalPages > 1 && (
                  <div className="mt-6 flex justify-center">
                    <Pagination>
                      <PaginationContent>
                        <PaginationItem>
                          <PaginationPrevious
                            href="#"
                            onClick={(e) => {
                              e.preventDefault()
                              if (currentPage > 1) setCurrentPage(currentPage - 1)
                            }}
                            className={currentPage === 1 ? "pointer-events-none opacity-50" : ""}
                          >
                            السابق
                          </PaginationPrevious>
                        </PaginationItem>

                        {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => {
                          if (
                            page === 1 ||
                            page === totalPages ||
                            (page >= currentPage - 1 && page <= currentPage + 1)
                          ) {
                            return (
                              <PaginationItem key={page}>
                                <PaginationLink
                                  href="#"
                                  onClick={(e) => {
                                    e.preventDefault()
                                    setCurrentPage(page)
                                  }}
                                  isActive={currentPage === page}
                                >
                                  {page}
                                </PaginationLink>
                              </PaginationItem>
                            )
                          } else if (page === currentPage - 2 || page === currentPage + 2) {
                            return (
                              <PaginationItem key={page}>
                                <PaginationEllipsis />
                              </PaginationItem>
                            )
                          }
                          return null
                        })}

                        <PaginationItem>
                          <PaginationNext
                            href="#"
                            onClick={(e) => {
                              e.preventDefault()
                              if (currentPage < totalPages) setCurrentPage(currentPage + 1)
                            }}
                            className={currentPage === totalPages ? "pointer-events-none opacity-50" : ""}
                          >
                            التالي
                          </PaginationNext>
                        </PaginationItem>
                      </PaginationContent>
                    </Pagination>
                  </div>
                )}

                {filteredUsers.length === 0 && !loading && (
                  <div className="text-center py-8 text-gray-500">
                    {searchTerm || roleFilter !== "all" || statusFilter !== "all" ? (
                      <div>
                        <p>لا توجد نتائج تطابق البحث</p>
                        <Button
                          variant="outline"
                          className="mt-4 bg-transparent"
                          onClick={() => {
                            setSearchTerm("")
                            setRoleFilter("all")
                            setStatusFilter("all")
                          }}
                        >
                          مسح الفلاتر
                        </Button>
                      </div>
                    ) : (
                      <div>
                        <p>لا توجد مستخدمين في النظام</p>
                        <Button className="mt-4" onClick={fetchUsers}>
                          إعادة تحميل
                        </Button>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="permissions" className="mt-4">
            <Card className="h-full flex flex-col">
              <CardHeader className="flex-shrink-0">
                <CardTitle>صلاحيات مخصصة</CardTitle>
              </CardHeader>
              <CardContent className="flex-1 overflow-auto">
                <div className="space-y-6">
                  <div className="space-y-2">
                    <Label>اختر المستخدم</Label>
                    <Select value={selectedUser} onValueChange={setSelectedUser}>
                      <SelectTrigger className="max-w-md">
                        <SelectValue placeholder="اختر مستخدم" />
                      </SelectTrigger>
                      <SelectContent>
                        {users.map((user) => (
                          <SelectItem key={user.id} value={user.user_id || user.id}>
                            {user.full_name || user.username} - {user.role}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {selectedUser && (
                    <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-emerald-600 rounded-full flex items-center justify-center text-white font-bold">
                          {users.find((u) => (u.user_id || u.id) === selectedUser)?.full_name?.charAt(0) || "U"}
                        </div>
                        <div>
                          <div className="font-medium">
                            {users.find((u) => (u.user_id || u.id) === selectedUser)?.full_name || "مستخدم غير معروف"}
                          </div>
                          <div className="text-sm text-gray-600">
                            {users.find((u) => (u.user_id || u.id) === selectedUser)?.role || "دور غير محدد"}
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  <div className="space-y-4">
                    <h4 className="font-semibold">الملفات والتعريفات</h4>
                    <div className="grid grid-cols-4 gap-4 p-4 bg-gray-50 rounded-lg">
                      <div className="font-medium text-sm">الوحدة</div>
                      <div className="font-medium text-sm">عرض</div>
                      <div className="font-medium text-sm">إضافة</div>
                      <div className="font-medium text-sm">تعديل/حذف</div>

                      <div className="text-sm">الزبائن</div>
                      <div>
                        <input
                          type="checkbox"
                          defaultChecked
                          className="rounded"
                          data-module="customers"
                          data-action="view"
                        />
                      </div>
                      <div>
                        <input
                          type="checkbox"
                          defaultChecked
                          className="rounded"
                          data-module="customers"
                          data-action="add"
                        />
                      </div>
                      <div>
                        <input type="checkbox" className="rounded" data-module="customers" data-action="edit" />
                      </div>

                      <div className="text-sm">الموردين</div>
                      <div>
                        <input
                          type="checkbox"
                          defaultChecked
                          className="rounded"
                          data-module="suppliers"
                          data-action="view"
                        />
                      </div>
                      <div>
                        <input type="checkbox" className="rounded" data-module="suppliers" data-action="add" />
                      </div>
                      <div>
                        <input type="checkbox" className="rounded" data-module="suppliers" data-action="edit" />
                      </div>

                      <div className="text-sm">الأصناف</div>
                      <div>
                        <input
                          type="checkbox"
                          defaultChecked
                          className="rounded"
                          data-module="products"
                          data-action="view"
                        />
                      </div>
                      <div>
                        <input
                          type="checkbox"
                          defaultChecked
                          className="rounded"
                          data-module="products"
                          data-action="add"
                        />
                      </div>
                      <div>
                        <input
                          type="checkbox"
                          defaultChecked
                          className="rounded"
                          data-module="products"
                          data-action="edit"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h4 className="font-semibold">الحركات</h4>
                    <div className="grid grid-cols-4 gap-4 p-4 bg-gray-50 rounded-lg">
                      <div className="font-medium text-sm">الوحدة</div>
                      <div className="font-medium text-sm">عرض</div>
                      <div className="font-medium text-sm">إضافة</div>
                      <div className="font-medium text-sm">تعديل/حذف</div>

                      <div className="text-sm">طلبيات المبيعات</div>
                      <div>
                        <input
                          type="checkbox"
                          defaultChecked
                          className="rounded"
                          data-module="sales_orders"
                          data-action="view"
                        />
                      </div>
                      <div>
                        <input
                          type="checkbox"
                          defaultChecked
                          className="rounded"
                          data-module="sales_orders"
                          data-action="add"
                        />
                      </div>
                      <div>
                        <input type="checkbox" className="rounded" data-module="sales_orders" data-action="edit" />
                      </div>

                      <div className="text-sm">طلبيات المشتريات</div>
                      <div>
                        <input
                          type="checkbox"
                          defaultChecked
                          className="rounded"
                          data-module="purchase_orders"
                          data-action="view"
                        />
                      </div>
                      <div>
                        <input type="checkbox" className="rounded" data-module="purchase_orders" data-action="add" />
                      </div>
                      <div>
                        <input type="checkbox" className="rounded" data-module="purchase_orders" data-action="edit" />
                      </div>

                      <div className="text-sm">أسعار الصرف</div>
                      <div>
                        <input
                          type="checkbox"
                          defaultChecked
                          className="rounded"
                          data-module="exchange_rates"
                          data-action="view"
                        />
                      </div>
                      <div>
                        <input
                          type="checkbox"
                          defaultChecked
                          className="rounded"
                          data-module="exchange_rates"
                          data-action="add"
                        />
                      </div>
                      <div>
                        <input type="checkbox" className="rounded" data-module="exchange_rates" data-action="edit" />
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h4 className="font-semibold">التقارير</h4>
                    <div className="grid grid-cols-4 gap-4 p-4 bg-gray-50 rounded-lg">
                      <div className="font-medium text-sm">التقرير</div>
                      <div className="font-medium text-sm">عرض</div>
                      <div className="font-medium text-sm">تصدير</div>
                      <div className="font-medium text-sm">طباعة</div>

                      <div className="text-sm">تقارير الطلبيات</div>
                      <div>
                        <input
                          type="checkbox"
                          defaultChecked
                          className="rounded"
                          data-module="reports"
                          data-action="orders"
                        />
                      </div>
                      <div>
                        <input
                          type="checkbox"
                          defaultChecked
                          className="rounded"
                          data-module="reports"
                          data-action="export"
                        />
                      </div>
                      <div>
                        <input type="checkbox" className="rounded" data-module="reports" data-action="print" />
                      </div>

                      <div className="text-sm">تقارير الأصناف</div>
                      <div>
                        <input type="checkbox" className="rounded" data-module="products_reports" data-action="view" />
                      </div>
                      <div>
                        <input
                          type="checkbox"
                          className="rounded"
                          data-module="products_reports"
                          data-action="export"
                        />
                      </div>
                      <div>
                        <input type="checkbox" className="rounded" data-module="products_reports" data-action="print" />
                      </div>
                    </div>
                  </div>

                  <div className="flex justify-end gap-2">
                    <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={savePermissions}>
                      حفظ الصلاحيات
                    </Button>
                    <Button variant="outline">نسخ من مستخدم آخر</Button>
                    <Button variant="outline" className="text-orange-600 hover:text-orange-700 bg-transparent">
                      إعادة تعيين
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="logs" className="mt-4">
            <Card className="h-full flex flex-col">
              <CardHeader className="flex-shrink-0">
                <CardTitle>سجل شامل لجميع العمليات</CardTitle>
              </CardHeader>
              <CardContent className="flex-1 overflow-auto">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6 flex-shrink-0">
                  <div className="space-y-2">
                    <Label>من تاريخ</Label>
                    <Input
                      type="date"
                      defaultValue={new Date(new Date().getFullYear(), 0, 1).toISOString().split("T")[0]}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>إلى تاريخ</Label>
                    <Input type="date" defaultValue={new Date().toISOString().split("T")[0]} />
                  </div>
                  <div className="space-y-2">
                    <Label>المستخدم</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="جميع المستخدمين" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">جميع المستخدمين</SelectItem>
                        {users.map((user) => (
                          <SelectItem key={user.id} value={user.user_id || user.id}>
                            {user.full_name || user.username}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>نوع العملية</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="جميع العمليات" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">جميع العمليات</SelectItem>
                        <SelectItem value="login">تسجيل دخول</SelectItem>
                        <SelectItem value="add">إضافة</SelectItem>
                        <SelectItem value="edit">تعديل</SelectItem>
                        <SelectItem value="delete">حذف</SelectItem>
                        <SelectItem value="print">طباعة</SelectItem>
                        <SelectItem value="export">تصدير</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="overflow-x-auto max-h-96 overflow-y-auto border rounded-lg">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-right p-3">التاريخ والوقت</th>
                        <th className="text-right p-3">المستخدم</th>
                        <th className="text-right p-3">نوع العملية</th>
                        <th className="text-right p-3">الوحدة</th>
                        <th className="text-right p-3">التفاصيل</th>
                        <th className="text-right p-3">عنوان IP</th>
                        <th className="text-right p-3">الحالة</th>
                      </tr>
                    </thead>
                    <tbody>
                      {activityLogs.map((log) => (
                        <tr key={log.id} className="border-b hover:bg-gray-50">
                          <td className="p-3 text-sm">{log.datetime}</td>
                          <td className="p-3">{log.user}</td>
                          <td className="p-3">{log.action}</td>
                          <td className="p-3">{log.module}</td>
                          <td className="p-3 text-sm">{log.details}</td>
                          <td className="p-3 text-sm">{log.ip}</td>
                          <td className="p-3">
                            <Badge
                              className={
                                log.status.includes("نجح")
                                  ? "bg-emerald-100 text-emerald-800"
                                  : "bg-red-100 text-red-800"
                              }
                            >
                              {log.status}
                            </Badge>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
