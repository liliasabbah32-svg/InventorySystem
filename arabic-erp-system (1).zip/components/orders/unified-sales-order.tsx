"use client"

import { useState, useEffect, useMemo } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Separator } from "@/components/ui/separator"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { UniversalToolbar } from "@/components/ui/universal-toolbar"
import { ReportGenerator } from "@/components/ui/report-generator"
import { useRecordNavigation } from "@/hooks/use-record-navigation"
import {
  Plus,
  Trash2,
  Search,
  Calculator,
  User,
  Package,
  FileText,
  Percent,
  MessageSquare,
  TrendingUp,
} from "lucide-react"
import { useDocumentSettings } from "@/hooks/use-document-settings"
import { LotSelector } from "@/components/inventory/lot-selector"

const InlineCustomerSearch = ({ onSelect, onClose, customers }: any) => {
  const [searchTerm, setSearchTerm] = useState("")

  const safeCustomers = Array.isArray(customers) ? customers : []

  const filteredCustomers = safeCustomers.filter(
    (customer: any) =>
      customer.customer_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      customer.customer_code?.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
      <div className="bg-white p-4 rounded-lg shadow-lg max-w-md w-full">
        <h3 className="text-lg font-semibold mb-4">بحث العملاء</h3>
        <input
          type="text"
          placeholder="ابحث عن عميل..."
          className="mb-4 p-2 border rounded w-full text-right"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          dir="rtl"
        />
        <div className="space-y-2 max-h-60 overflow-y-auto">
          {filteredCustomers.map((customer: any) => (
            <button
              key={customer.id}
              onClick={() => onSelect(customer)}
              className="block w-full text-right p-2 hover:bg-gray-100 rounded"
            >
              {customer.customer_name} ({customer.customer_code})
            </button>
          ))}
          {filteredCustomers.length === 0 && <div className="text-center text-gray-500 py-4">لا توجد نتائج</div>}
        </div>
        <div className="flex justify-end mt-4">
          <Button variant="outline" onClick={onClose}>
            إغلاق
          </Button>
        </div>
      </div>
    </div>
  )
}

const InlineProductSearch = ({ onSelect, onClose, products }: any) => {
  const [searchTerm, setSearchTerm] = useState("")

  const safeProducts = Array.isArray(products) ? products : []

  const filteredProducts = safeProducts.filter(
    (product: any) =>
      product.product_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.product_code?.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
      <div className="bg-white p-4 rounded-lg shadow-lg max-w-md w-full">
        <h3 className="text-lg font-semibold mb-4">بحث المنتجات</h3>
        <input
          type="text"
          placeholder="ابحث عن منتج..."
          className="mb-4 p-2 border rounded w-full text-right"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          dir="rtl"
        />
        <div className="space-y-2 max-h-60 overflow-y-auto">
          {filteredProducts.map((product: any) => (
            <button
              key={product.id}
              onClick={() => onSelect(product)}
              className="block w-full text-right p-2 hover:bg-gray-100 rounded"
            >
              <div className="font-medium">{product.product_name}</div>
              <div className="text-sm text-gray-500">
                {product.product_code} - {product.main_unit} - {product.selling_price || product.last_purchase_price}
                ر.س
              </div>
            </button>
          ))}
          {filteredProducts.length === 0 && <div className="text-center text-gray-500 py-4">لا توجد نتائج</div>}
        </div>
        <div className="flex justify-end mt-4">
          <Button variant="outline" onClick={onClose}>
            إغلاق
          </Button>
        </div>
      </div>
    </div>
  )
}

interface SalesOrder {
  id: number
  order_number: string
  order_date: string
  customer_name: string
  customer_id: number
  order_status: string
  financial_status: string
  total_amount: number
  salesman: string
  delivery_datetime: string
  workflow_sequence_id: number
  currency_code: string
  exchange_rate: number
  notes: string
  created_at: string
  updated_at: string
  items?: OrderItem[] // Assuming order items are nested
}

interface UnifiedSalesOrderProps {
  order?: any // Assuming 'order' is the data for an existing order
  allOrders?: SalesOrder[] // إضافة prop جديد لجميع الطلبيات
  onOrderSaved?: (data: any) => void
  onCancel: () => void
  setEditingOrder?: (order: any | null) => void
  open?: boolean
  onOpenChange?: (open: boolean) => void
}

interface Customer {
  id: number
  customer_code: string
  customer_name: string
  email?: string
  mobile1?: string
  address?: string
  tax_number?: string
  credit_limit?: number
  payment_terms?: string
}

interface Product {
  id: number
  product_code: string
  product_name: string
  main_unit: string
  last_purchase_price: number
  selling_price?: number
  current_stock: number
  barcode?: string
}

interface OrderItem {
  id: string
  product_id: number | null
  product_code: string
  product_name: string
  barcode: string
  warehouse: string
  quantity: number
  bonus_quantity: number
  unit: string
  unit_price: number
  discount_percentage: number
  discount_amount: number
  tax_percentage: number
  tax_amount: number
  total_price: number
  expiry_date: string
  batch_number: string
  notes: string
  // New fields for lot selection
  lot_id?: number | null
  lotAllocations?: any[] // To store detailed lot allocations
}

interface OrderFormData {
  id?: number
  order_number: string | null
  order_date: string | null
  invoice_number: string | null
  reference_number: string | null
  customer_id: number | null
  customer_name: string | null
  customer_code: string | null
  customer_address: string | null
  customer_tax_number: string | null
  salesman: string | null
  sales_representative: string | null
  currency_code: string
  currency_name: string
  exchange_rate: number
  payment_terms: string | null
  delivery_date: string | null
  delivery_address: string | null
  delivery_notes: string | null
  order_status: string
  financial_status: string
  priority: string
  source: string
  notes: string | null
  internal_notes: string | null
  discount_type: string
  discount_value: number
  discount_amount: number
  tax_percentage: number
  tax_amount: number
  shipping_cost: number
  other_charges: number
  total_before_discount: number
  total_after_discount: number
  total_tax: number
  grand_total: number
  // New fields from updates
  customer_number?: string | null
  customer_phone?: string | null
  order_source: string
}

const initialFormData: OrderFormData = {
  order_number: "",
  order_date: new Date().toISOString().split("T")[0],
  invoice_number: "",
  reference_number: "",
  customer_id: null,
  customer_name: "",
  customer_code: "",
  customer_address: "",
  customer_tax_number: "",
  salesman: "",
  sales_representative: "",
  currency_code: "SAR",
  currency_name: "ريال سعودي",
  exchange_rate: 1.0,
  payment_terms: "نقدي",
  delivery_date: "",
  delivery_address: "",
  delivery_notes: "",
  order_status: "pending",
  financial_status: "unpaid",
  priority: "عادي",
  source: "مباشر",
  notes: "",
  internal_notes: "",
  discount_type: "percentage",
  discount_value: 0,
  discount_amount: 0,
  tax_percentage: 15,
  tax_amount: 0,
  shipping_cost: 0,
  other_charges: 0,
  total_before_discount: 0,
  total_after_discount: 0,
  total_tax: 0,
  grand_total: 0,
  // New fields from updates
  customer_number: "",
  customer_phone: "",
  order_source: "manual",
}

const initialOrderItem: OrderItem = {
  id: "",
  product_id: null,
  product_code: "",
  product_name: "",
  barcode: "",
  warehouse: "المستودع الرئيسي",
  quantity: 1,
  bonus_quantity: 0,
  unit: "قطعة",
  unit_price: 0,
  discount_percentage: 0,
  discount_amount: 0,
  tax_percentage: 15,
  tax_amount: 0,
  total_price: 0,
  expiry_date: "",
  batch_number: "",
  notes: "",
  lot_id: null,
  lotAllocations: [],
}

function UnifiedSalesOrder({
  order,
  allOrders = [],
  onOrderSaved,
  onCancel,
  setEditingOrder,
  open = true,
  onOpenChange,
}: UnifiedSalesOrderProps) {
  const {
    settings,
    loading: settingsLoading,
    isFieldVisible,
    getFieldDisplayName,
    getVisibleFields,
  } = useDocumentSettings("sales-order")

  const [state, setState] = useState({
    isSubmitting: false,
    customers: [] as Customer[],
    products: [] as Product[],
    formData: order ? { ...initialFormData, ...order } : initialFormData,
    orderItems:
      order && order.items
        ? order.items.map((item: any) => ({ ...initialOrderItem, ...item, id: item.id || Date.now().toString() }))
        : [{ ...initialOrderItem, id: "1" }],
    customerSearch: "",
    productSearch: "",
    showCustomerDropdown: false,
    showProductDropdown: false,
    activeTab: "items", // Changed default tab to items for faster data entry
    // New state from updates
    showCustomerSearch: false,
    showProductSearch: false,
    activeItemId: null as string | null,
    showLotSelector: false,
    selectedProductForLots: null as any,
    selectedItemIdForLots: null as string | null,
    // new state for navigation
    currentRecordId: order?.id || null,
    totalRecords: allOrders?.length || 0,
    isSaving: false,
    isDeleting: false,
  })

  const [showReport, setShowReport] = useState(false)

  const createNewOrder = (): SalesOrder => ({
    id: 0,
    order_number: "",
    order_date: new Date().toISOString().split("T")[0],
    customer_name: "",
    customer_id: 0,
    order_status: "pending",
    financial_status: "unpaid",
    total_amount: 0,
    salesman: "",
    delivery_datetime: "",
    workflow_sequence_id: 0,
    currency_code: "ريال",
    exchange_rate: 1,
    notes: "",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  })

  const {
    currentRecord,
    currentIndex,
    isNew,
    isLoading: navLoading,
    totalRecords: navTotalRecords,
    goToFirst,
    goToPrevious,
    goToNext,
    goToLast,
    createNew,
    saveRecord,
    deleteRecord,
    updateRecord,
    canSave,
    canDelete,
    isFirstRecord,
    isLastRecord,
  } = useRecordNavigation({
    data: allOrders,
    onSave: handleSaveOrder,
    onDelete: handleDeleteOrder,
    createNewRecord: createNewOrder,
  })

  useEffect(() => {
    setState((prev) => ({
      ...prev,
      totalRecords: allOrders?.length || 0,
      currentRecordId: currentRecord?.id || null,
    }))
  }, [currentRecord, allOrders])

  useEffect(() => {
    if (currentRecord && currentRecord.id !== state.formData.id) {
      setState((prev) => ({
        ...prev,
        formData: { ...initialFormData, ...currentRecord },
        orderItems: currentRecord.items
          ? currentRecord.items.map((item: any) => ({
              ...initialOrderItem,
              ...item,
              id: item.id || Date.now().toString(),
            }))
          : [{ ...initialOrderItem, id: "1" }],
      }))
    }
  }, [currentRecord, state.formData.id])

  const currencies = [
    { code: "SAR", name: "ريال سعودي" },
    { code: "USD", name: "دولار أمريكي" },
    { code: "EUR", name: "يورو" },
    { code: "ILS", name: "شيكل إسرائيلي" },
  ]

  const paymentTerms = ["نقدي", "آجل 30 يوم", "آجل 60 يوم", "آجل 90 يوم", "تقسيط"]
  const priorities = ["عادي", "عاجل", "مستعجل جداً"]
  const sources = ["مباشر", "هاتف", "إيميل", "موقع إلكتروني", "تطبيق جوال"]
  const warehouses = ["المستودع الرئيسي", "مستودع فرعي 1", "مستودع فرعي 2"]
  const units = ["قطعة", "كيلو", "جرام", "لتر", "متر", "صندوق", "كرتون", "علبة"]

  useEffect(() => {
    if (order) {
      setState((prev) => ({
        ...prev,
        formData: { ...initialFormData, ...order },
        orderItems: order.items.map((item: any) => ({
          ...initialOrderItem,
          ...item,
          id: item.id || Date.now().toString(),
        })),
      }))
    }
  }, [order])

  useEffect(() => {
    fetchCustomers()
    fetchProducts()
    generateOrderNumber()
  }, [])

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // F2 for customer search
      if (e.key === "F2" && !e.ctrlKey && !e.altKey) {
        e.preventDefault()
        setState((prev) => ({ ...prev, showCustomerSearch: true }))
      }
      // F3 for product search in focused row
      if (e.key === "F3" && !e.ctrlKey && !e.altKey) {
        e.preventDefault()
        const activeElement = document.activeElement as HTMLElement
        if (activeElement?.closest("[data-product-row]")) {
          const rowId = activeElement.closest("[data-product-row]")?.getAttribute("data-product-row")
          if (rowId) {
            setState((prev) => ({ ...prev, showProductSearch: true, activeItemId: rowId }))
          }
        }
      }
      // Escape to close search
      if (e.key === "Escape") {
        setState((prev) => ({
          ...prev,
          showCustomerSearch: false,
          showProductSearch: false,
          activeItemId: null,
          showLotSelector: false,
        }))
      }
      // Ctrl+S for save
      if (e.key === "s" && e.ctrlKey) {
        e.preventDefault()
        handleSave()
      }
    }

    document.addEventListener("keydown", handleKeyDown)
    return () => document.removeEventListener("keydown", handleKeyDown)
  }, [state.showCustomerSearch, state.showProductSearch, state.activeItemId, state.showLotSelector])

  const fetchCustomers = async () => {
    try {
      console.log("[v0] Calling customers API...")
      const response = await fetch("/api/orders/customers")
      console.log("[v0] Customers API response status:", response.status)

      if (response.ok) {
        const data = await response.json()
        console.log("[v0] Customers data received:", data.length, "records")
        console.log("[v0] First customer:", data[0])
        setState((prev) => ({ ...prev, customers: Array.isArray(data) ? data : [] }))
      } else {
        console.error("[v0] Customers API failed with status:", response.status)
      }
    } catch (error) {
      console.error("[v0] Error fetching customers:", error)
    }
  }

  const fetchProducts = async () => {
    try {
      console.log("[v0] Calling products API...")
      const response = await fetch("/api/inventory/products")
      console.log("[v0] Products API response status:", response.status)

      if (response.ok) {
        const data = await response.json()
        console.log("[v0] Products data received:", data.length, "records")
        setState((prev) => ({ ...prev, products: Array.isArray(data) ? data : [] }))
      } else {
        console.error("[v0] Products API failed with status:", response.status)
      }
    } catch (error) {
      console.error("[v0] Error fetching products:", error)
    }
  }

  const generateOrderNumber = async () => {
    try {
      const response = await fetch("/api/orders/generate-number")
      if (!response.ok) {
        throw new Error("Failed to generate order number")
      }
      const data = await response.json()

      console.log("[v0] Order number generation response:", data)

      // If auto numbering is disabled, leave field empty for manual entry
      if (data.autoNumbering === false) {
        setState((prev) => ({
          ...prev,
          formData: { ...prev.formData, order_number: "" },
        }))
        return
      }

      setState((prev) => ({
        ...prev,
        formData: { ...prev.formData, order_number: data.orderNumber },
      }))
    } catch (error) {
      console.error("Error generating order number:", error)
      // Fallback to timestamp-based number
      const now = new Date()
      const timestamp = now.getTime().toString()
      const lastSeven = timestamp.slice(-7).padStart(7, "0")
      const orderNumber = `O${lastSeven}`
      setState((prev) => ({
        ...prev,
        formData: { ...prev.formData, order_number: orderNumber },
      }))
    }
  }

  const addOrderItem = () => {
    const newItem: OrderItem = {
      ...initialOrderItem,
      id: Date.now().toString(),
    }
    setState((prev) => ({
      ...prev,
      orderItems: [...prev.orderItems, newItem],
    }))
  }

  const removeOrderItem = (id: string) => {
    if (state.orderItems.length > 1) {
      setState((prev) => ({
        ...prev,
        orderItems: prev.orderItems.filter((item) => item.id !== id),
      }))
    }
  }

  const updateOrderItem = (id: string, field: keyof OrderItem, value: any) => {
    setState((prev) => ({
      ...prev,
      orderItems: prev.orderItems.map((item) => {
        if (item.id === id) {
          const updatedItem = { ...item, [field]: value }

          // Auto-calculate amounts when quantity or price changes
          if (
            field === "quantity" ||
            field === "unit_price" ||
            field === "discount_percentage" ||
            field === "tax_percentage"
          ) {
            const subtotal = updatedItem.quantity * updatedItem.unit_price
            updatedItem.discount_amount = (subtotal * updatedItem.discount_percentage) / 100
            const afterDiscount = subtotal - updatedItem.discount_amount
            updatedItem.tax_amount = (afterDiscount * updatedItem.tax_percentage) / 100
            updatedItem.total_price = afterDiscount + updatedItem.tax_amount
          }

          return updatedItem
        }
        return item
      }),
    }))
  }

  const handleCustomerSelect = (customer: any) => {
    setState((prev) => ({
      ...prev,
      formData: {
        ...prev.formData,
        customer_id: customer.id,
        customer_code: customer.customer_code,
        customer_name: customer.customer_name,
        customer_address: customer.address || "", // Use address from customer data
        customer_tax_number: customer.tax_number || "",
        payment_terms: customer.payment_terms || "نقدي",
        customer_phone: customer.mobile1 || "",
      },
      customerSearch: customer.customer_name, // Update customerSearch for consistency
      showCustomerSearch: false,
    }))
  }

  const handleProductSelect = (product: any, itemId: string) => {
    updateOrderItem(itemId, "product_id", product.id)
    updateOrderItem(itemId, "product_code", product.product_code)
    updateOrderItem(itemId, "product_name", product.product_name)
    updateOrderItem(itemId, "barcode", product.barcode || "")
    updateOrderItem(itemId, "unit", product.main_unit)
    updateOrderItem(itemId, "unit_price", product.selling_price || product.last_purchase_price)
    setState((prev) => ({ ...prev, showProductSearch: false, activeItemId: null }))
  }

  const selectCustomer = (customer: Customer) => {
    setState((prev) => ({
      ...prev,
      formData: {
        ...prev.formData,
        customer_id: customer.id,
        customer_name: customer.customer_name,
        customer_code: customer.customer_code,
        customer_address: customer.address || "",
        customer_tax_number: customer.tax_number || "",
        payment_terms: customer.payment_terms || "نقدي",
        customer_phone: customer.mobile1 || "",
      },
      customerSearch: customer.customer_name,
      showCustomerDropdown: false,
    }))
  }

  const selectProduct = (product: Product, itemId: string) => {
    updateOrderItem(itemId, "product_id", product.id)
    updateOrderItem(itemId, "product_code", product.product_code)
    updateOrderItem(itemId, "product_name", product.product_name)
    updateOrderItem(itemId, "barcode", product.barcode || "")
    updateOrderItem(itemId, "unit", product.main_unit)
    updateOrderItem(itemId, "unit_price", product.selling_price || product.last_purchase_price)

    setState((prev) => ({ ...prev, showProductDropdown: false }))
  }

  const calculateItemTotal = (item: OrderItem) => {
    const subtotal = item.quantity * item.unit_price
    const discountAmount = (subtotal * item.discount_percentage) / 100
    const afterDiscount = subtotal - discountAmount
    const taxAmount = (afterDiscount * item.tax_percentage) / 100
    return afterDiscount + taxAmount
  }

  const totals = useMemo(() => {
    const subtotal = state.orderItems.reduce((sum, item) => sum + item.quantity * item.unit_price, 0)
    let discount = 0
    if (state.formData.discount_type === "percentage") {
      discount = (subtotal * state.formData.discount_value) / 100
    } else {
      discount = state.formData.discount_value
    }
    const tax = (subtotal - discount) * (state.formData.tax_percentage / 100)
    const total = subtotal - discount + tax + state.formData.shipping_cost + state.formData.other_charges

    return {
      subtotal,
      discount,
      tax,
      total,
    }
  }, [
    state.orderItems,
    state.formData.discount_type,
    state.formData.discount_value,
    state.formData.tax_percentage,
    state.formData.shipping_cost,
    state.formData.other_charges,
  ])

  async function handleSaveOrder(orderToSave: SalesOrder, isNewRecord: boolean): Promise<void> {
    console.log("[v0] Starting save process...")

    // Validation
    if (!state.formData.customer_name.trim()) {
      throw new Error("اسم العميل مطلوب")
    }

    if (state.orderItems.length === 0 || state.orderItems.every((item) => !item.product_name)) {
      throw new Error("يجب إضافة صنف واحد على الأقل")
    }

    const orderData = {
      order_number: state.formData.order_number,
      order_date: state.formData.order_date,
      customer_id: state.formData.customer_id,
      customer_name: state.formData.customer_name,
      salesman: state.formData.salesman || "",
      total_amount: totals.total,
      currency_code: state.formData.currency_code || "SAR",
      currency_name: state.formData.currency_name || "ريال سعودي",
      exchange_rate: state.formData.exchange_rate || 1.0,
      order_status: state.formData.order_status || "pending",
      financial_status: state.formData.financial_status || "unpaid",
      delivery_datetime: state.formData.delivery_date ? new Date(state.formData.delivery_date).toISOString() : null,
      manual_document: state.formData.reference_number || null,
      notes: state.formData.notes || null,
      invoice_number: state.formData.invoice_number || null,
      barcode: null,
      attachments: null,
      workflow_sequence_id: null,
      // Added order_source to the data sent to the API
      order_source: state.formData.order_source,
    }

    const items = state.orderItems
      .filter((item) => item.product_name && item.quantity > 0)
      .map((item) => ({
        product_id: item.product_id,
        product_name: item.product_name,
        product_code: item.product_code,
        quantity: Number(item.quantity),
        unit_price: Number(item.unit_price),
        discount_percentage: Number(item.discount_percentage) || 0,
        total_price: Number(item.total_price),
        notes: item.notes || null,
        barcode: item.barcode || null,
        unit: item.unit || "قطعة",
        warehouse: item.warehouse || "المستودع الرئيسي",
        bonus_quantity: Number(item.bonus_quantity) || 0,
        delivered_quantity: 0,
        expiry_date: item.expiry_date || null,
        batch_number: item.batch_number || null,
        item_status: "pending",
        lot_id: item.lot_id || null,
        lotAllocations: item.lotAllocations || [],
      }))

    console.log("[v0] Sending order data:", orderData)
    console.log("[v0] Sending items data:", items)

    const method = isNewRecord ? "POST" : "PUT"
    const url = isNewRecord ? "/api/orders/sales" : `/api/orders/sales/${orderToSave.id}`

    const response = await fetch(url, {
      method,
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify({ orderData, items }),
    })

    console.log("[v0] Response status:", response.status)

    if (!response.ok) {
      const responseText = await response.text()
      console.error("[v0] API Error Response Text:", responseText)

      let errorData
      try {
        errorData = JSON.parse(responseText)
      } catch {
        errorData = { error: `HTTP ${response.status}: ${responseText}` }
      }

      throw new Error(errorData.error || "فشل في حفظ طلبية المبيعات")
    }

    const result = await response.json()
    console.log("[v0] Save successful:", result)

    if (onOrderSaved) {
      onOrderSaved(result)
    }
  }

  async function handleDeleteOrder(orderToDelete: SalesOrder): Promise<void> {
    if (!orderToDelete || !orderToDelete.id) {
      throw new Error("لا توجد طلبية محددة للحذف")
    }

    if (!confirm("هل أنت متأكد من حذف هذه الطلبية؟")) {
      throw new Error("تم إلغاء العملية")
    }

    const response = await fetch(`/api/orders/sales/${orderToDelete.id}`, {
      method: "DELETE",
    })

    if (!response.ok) {
      throw new Error("فشل في حذف طلبية المبيعات")
    }

    if (onOrderSaved) {
      onOrderSaved(null)
    }
  }

  // Handle navigation for UniversalToolbar
  const handleNavigate = (direction: "first" | "previous" | "next" | "last") => {
    switch (direction) {
      case "first":
        goToFirst()
        break
      case "previous":
        goToPrevious()
        break
      case "next":
        goToNext()
        break
      case "last":
        goToLast()
        break
      default:
        break
    }
  }

  const handleNew = () => {
    setEditingOrder?.(null)
    setState((prev) => ({
      ...initialFormData,
      formData: initialFormData,
      orderItems: [{ ...initialOrderItem, id: "1" }],
      customerSearch: "",
      activeTab: "basic", // Reset to basic tab
      showCustomerSearch: false,
      showProductSearch: false,
      activeItemId: null,
      showLotSelector: false,
      selectedProductForLots: null,
      selectedItemIdForLots: null,
    }))
    generateOrderNumber() // Generate a new order number for the new order
  }

  const handleSave = async () => {
    setState((prev) => ({ ...prev, isSaving: true }))
    try {
      // Check if it's an existing order or a new one
      const isNewRecord = !state.formData.id

      // Call the saveRecord from useRecordNavigation hook
      // We need to construct a minimal SalesOrder object for saveRecord
      const currentOrderForNavigation = {
        ...createNewOrder(), // Start with a fresh object
        id: state.formData.id || 0, // Use current ID if exists, otherwise 0
        order_number: state.formData.order_number,
        order_date: state.formData.order_date,
        customer_name: state.formData.customer_name,
        customer_id: state.formData.customer_id || 0,
        total_amount: totals.total,
        order_status: state.formData.order_status,
        financial_status: state.formData.financial_status,
        delivery_datetime: state.formData.delivery_date ? new Date(state.formData.delivery_date).toISOString() : null,
        salesman: state.formData.salesman,
        currency_code: state.formData.currency_code,
        exchange_rate: state.formData.exchange_rate,
        notes: state.formData.notes,
        // Add other relevant fields if needed by useRecordNavigation for its save logic
      }

      await saveRecord(currentOrderForNavigation, isNewRecord)
      alert("تم حفظ الطلبية بنجاح")

      // After successful save, update the state with the latest data if it was a new record
      if (isNewRecord) {
        // If the save operation returns the saved data, update formData accordingly
        // For now, we assume saveRecord implicitly updates the navigation state and potentially returns the saved data.
        // If not, we might need to re-fetch or update state based on API response.
        // A common pattern is that saveRecord might return the saved item, which then needs to be used to update state.
        // For simplicity here, we'll rely on the onOrderSaved callback.
        if (onOpenChange) {
          onOpenChange(false)
        } else {
          onCancel()
        }
      } else {
        // If it was an existing record, we might want to keep the dialog open or refresh data.
        // For now, we assume the onOrderSaved callback handles further actions.
      }
    } catch (err: any) {
      console.error("Error saving sales order:", err)
      alert(err.message || "حدث خطأ أثناء حفظ البيانات")
    } finally {
      setState((prev) => ({ ...prev, isSaving: false }))
    }
  }

  const handleDelete = async () => {
    setState((prev) => ({ ...prev, isDeleting: true }))
    try {
      // The deleteRecord from useRecordNavigation hook handles the deletion logic
      // It expects the currentRecord to be passed or it uses the internally tracked current record.
      await deleteRecord()
      alert("تم حذف الطلبية بنجاح")

      // Close the dialog after deletion
      if (onOpenChange) {
        onOpenChange(false)
      } else {
        onCancel()
      }
    } catch (err: any) {
      console.error("Error deleting sales order:", err)
      alert(err.message || "حدث خطأ أثناء حذف البيانات")
    } finally {
      setState((prev) => ({ ...prev, isDeleting: false }))
    }
  }

  const filteredCustomers = state.customers.filter(
    (customer) =>
      customer.customer_name.toLowerCase().includes(state.customerSearch.toLowerCase()) ||
      customer.customer_code.toLowerCase().includes(state.customerSearch.toLowerCase()),
  )

  // Redefine handleNew to match the expected signature for UniversalToolbar
  const handleNewRecord = () => {
    setEditingOrder?.(null)
    // Reset form state to initial values for a new order
    setState((prev) => ({
      ...prev, // Keep existing states like customers, products etc.
      formData: initialFormData,
      orderItems: [{ ...initialOrderItem, id: "1" }],
      customerSearch: "",
      activeTab: "basic", // Reset to basic tab
      showCustomerSearch: false,
      showProductSearch: false,
      activeItemId: null,
      showLotSelector: false,
      selectedProductForLots: null,
      selectedItemIdForLots: null,
    }))
    generateOrderNumber() // Generate a new order number for the new order
  }

  const handleCancel = () => {
    // Reset form state
    setState((prev) => ({
      ...prev, // Keep existing states like customers, products etc.
      formData: initialFormData,
      orderItems: [{ ...initialOrderItem, id: "1" }],
      customerSearch: "",
      activeTab: "basic", // Reset to basic tab
    }))

    if (onOpenChange) {
      onOpenChange(false)
    } else {
      onCancel()
    }
  }

  const handleLotSelection = (itemId: string, productId: number, productName: string, quantity: number) => {
    const product = state.products.find((p) => p.id === productId)
    if (!product) return

    setState((prev) => ({
      ...prev,
      showLotSelector: true,
      selectedProductForLots: product,
      selectedItemIdForLots: itemId,
    }))
  }

  const handleLotsSelected = (selectedLots: any[]) => {
    if (!state.selectedItemIdForLots) return

    const itemId = state.selectedItemIdForLots

    // Update the item with lot information
    if (selectedLots.length > 0) {
      const firstLot = selectedLots[0]
      updateOrderItem(itemId, "lot_id", firstLot.lot_id)
      updateOrderItem(itemId, "expiry_date", firstLot.expiry_date || "")
      updateOrderItem(itemId, "batch_number", firstLot.lot_number || "")
      updateOrderItem(itemId, "unit_price", firstLot.unit_cost || 0)

      // If multiple lots, store the allocation info
      if (selectedLots.length > 1) {
        updateOrderItem(itemId, "notes", `متعدد الدفعات: ${selectedLots.map((l) => l.lot_number).join(", ")}`)
      }

      // Store lot allocation data for later use
      setState((prev) => ({
        ...prev,
        orderItems: prev.orderItems.map((item) =>
          item.id === itemId ? { ...item, lotAllocations: selectedLots } : item,
        ),
      }))
    }

    setState((prev) => ({
      ...prev,
      showLotSelector: false,
      selectedProductForLots: null,
      selectedItemIdForLots: null,
    }))
  }

  const handleReport = () => {
    setShowReport(true)
  }

  const handleExportExcel = async () => {
    setShowReport(true)
  }

  const handlePrint = () => {
    setShowReport(true)
  }

  const reportColumns = [
    { key: "order_number", label: "رقم الطلبية", width: "120px" },
    { key: "order_date", label: "التاريخ", width: "100px" },
    { key: "customer_name", label: "اسم الزبون", width: "200px" },
    { key: "order_status", label: "الحالة", width: "100px" },
    { key: "financial_status", label: "الحالة المالية", width: "120px" },
    { key: "total_amount", label: "المبلغ", width: "100px" },
    { key: "salesman", label: "المندوب", width: "120px" },
    { key: "delivery_datetime", label: "تاريخ التسليم", width: "120px" },
  ]

  return (
    <Dialog open={open} onOpenChange={onOpenChange || handleCancel}>
      <DialogContent className="max-w-[98vw] w-full h-[95vh] p-0 gap-0 flex flex-col">
        <div className="sticky top-0 z-50 bg-background border-b px-6 py-4">
          <UniversalToolbar
            currentRecord={currentIndex}
            totalRecords={navTotalRecords}
            onFirst={goToFirst}
            onPrevious={goToPrevious}
            onNext={goToNext}
            onLast={goToLast}
            onNew={handleNewRecord}
            onSave={handleSave}
            onDelete={handleDelete}
            onReport={handleReport}
            onExportExcel={handleExportExcel}
            onPrint={handlePrint}
            isLoading={navLoading}
            isSaving={state.isSaving}
            canSave={canSave}
            canDelete={canDelete}
            isFirstRecord={isFirstRecord}
            isLastRecord={isLastRecord}
          />
        </div>

        <div className="flex-1 overflow-y-auto">
          <div className="p-6 space-y-6">
            <Card className="bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20 sticky top-0 z-40 shadow-md">
              <CardContent className="py-4">
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <div className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-primary" />
                    <span className="text-sm font-medium">ملخص الطلبية</span>
                  </div>
                  <div className="flex flex-wrap items-center gap-6 text-sm">
                    <div className="flex flex-col items-end">
                      <span className="text-xs text-muted-foreground">المجموع الفرعي</span>
                      <span className="font-semibold">{totals.subtotal.toFixed(2)} ر.س</span>
                    </div>
                    <div className="flex flex-col items-end">
                      <span className="text-xs text-muted-foreground">الخصم</span>
                      <span className="font-semibold text-red-600">-{totals.discount.toFixed(2)} ر.س</span>
                    </div>
                    <div className="flex flex-col items-end">
                      <span className="text-xs text-muted-foreground">الضريبة</span>
                      <span className="font-semibold">{totals.tax.toFixed(2)} ر.س</span>
                    </div>
                    <Separator orientation="vertical" className="h-10 hidden md:block" />
                    <div className="flex flex-col items-end">
                      <span className="text-xs text-muted-foreground">الإجمالي</span>
                      <span className="text-lg font-bold text-primary">{totals.total.toFixed(2)} ر.س</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-4">
                <CardTitle className="text-lg flex items-center gap-2">
                  <FileText className="h-5 w-5 text-primary" />
                  معلومات الطلبية الأساسية
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {isFieldVisible("sequence") && (
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">
                        {getFieldDisplayName("sequence")}
                        {settings.find((s) => s.field_name === "sequence")?.is_required && (
                          <span className="text-red-500 mr-1">*</span>
                        )}
                      </Label>
                      <Input
                        value={state.formData.order_number ?? ""}
                        onChange={(e) =>
                          setState((prev) => ({
                            ...prev,
                            formData: { ...prev.formData, order_number: e.target.value },
                          }))
                        }
                        className="text-right font-medium h-11"
                        dir="rtl"
                        placeholder={state.formData.order_number === "" ? "أدخل الرقم يدوياً" : ""}
                      />
                    </div>
                  )}
                  {isFieldVisible("order_date") && (
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">
                        {getFieldDisplayName("order_date") || "تاريخ الطلبية"}
                        {settings.find((s) => s.field_name === "order_date")?.is_required && (
                          <span className="text-red-500 mr-1">*</span>
                        )}
                      </Label>
                      <Input
                        type="date"
                        value={state.formData.order_date ?? ""}
                        onChange={(e) =>
                          setState((prev) => ({
                            ...prev,
                            formData: { ...prev.formData, order_date: e.target.value },
                          }))
                        }
                        className="text-right h-11"
                        dir="rtl"
                      />
                    </div>
                  )}
                  {isFieldVisible("invoice_number") && (
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">
                        {getFieldDisplayName("invoice_number") || "رقم الفاتورة"}
                      </Label>
                      <Input
                        value={state.formData.invoice_number ?? ""}
                        onChange={(e) =>
                          setState((prev) => ({
                            ...prev,
                            formData: { ...prev.formData, invoice_number: e.target.value },
                          }))
                        }
                        className="text-right h-11"
                        dir="rtl"
                      />
                    </div>
                  )}
                  {isFieldVisible("order_status") && (
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">
                        {getFieldDisplayName("order_status") || "حالة الطلبية"}
                      </Label>
                      <Select
                        value={state.formData.order_status || "pending"}
                        onValueChange={(value) =>
                          setState((prev) => ({
                            ...prev,
                            formData: { ...prev.formData, order_status: value },
                          }))
                        }
                      >
                        <SelectTrigger className="h-11">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="قيد التنفيذ">قيد التنفيذ</SelectItem>
                          <SelectItem value="مؤكدة">مؤكدة</SelectItem>
                          <SelectItem value="تم الشحن">تم الشحن</SelectItem>
                          <SelectItem value="تم التسليم">تم التسليم</SelectItem>
                          <SelectItem value="ملغاة">ملغاة</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                  {isFieldVisible("salesman") && (
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">المندوب</Label>
                      <Input
                        value={state.formData.salesman ?? ""}
                        onChange={(e) =>
                          setState((prev) => ({
                            ...prev,
                            formData: { ...prev.formData, salesman: e.target.value },
                          }))
                        }
                        className="text-right h-11"
                        dir="rtl"
                      />
                    </div>
                  )}

                  {isFieldVisible("order_source") && (
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">
                        {getFieldDisplayName("order_source") || "مصدر الطلبية"}
                      </Label>
                      <Select
                        value={state.formData.order_source || "manual"}
                        onValueChange={(value) =>
                          setState((prev) => ({
                            ...prev,
                            formData: { ...prev.formData, order_source: value },
                          }))
                        }
                      >
                        <SelectTrigger className="h-11">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="manual">إدخال يدوي</SelectItem>
                          <SelectItem value="customer_portal">من الزبائن عبر الويب</SelectItem>
                          <SelectItem value="api_import">استيراد من API</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                </div>

                <Accordion type="single" collapsible className="w-full">
                  <AccordionItem value="additional-info" className="border rounded-lg px-4">
                    <AccordionTrigger className="text-sm font-medium hover:no-underline">
                      معلومات إضافية
                    </AccordionTrigger>
                    <AccordionContent className="pt-4 space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {isFieldVisible("reference_number") && (
                          <div className="space-y-2">
                            <Label className="text-sm font-medium">
                              {getFieldDisplayName("reference_number") || "الرقم المرجعي"}
                            </Label>
                            <Input
                              value={state.formData.reference_number ?? ""}
                              onChange={(e) =>
                                setState((prev) => ({
                                  ...prev,
                                  formData: { ...prev.formData, reference_number: e.target.value },
                                }))
                              }
                              className="text-right h-11"
                              dir="rtl"
                            />
                          </div>
                        )}
                        {isFieldVisible("delivery_date") && (
                          <div className="space-y-2">
                            <Label className="text-sm font-medium">
                              {getFieldDisplayName("delivery_date") || "تاريخ التسليم"}
                            </Label>
                            <Input
                              type="date"
                              value={state.formData.delivery_date ?? ""}
                              onChange={(e) =>
                                setState((prev) => ({
                                  ...prev,
                                  formData: { ...prev.formData, delivery_date: e.target.value },
                                }))
                              }
                              className="text-right h-11"
                              dir="rtl"
                            />
                          </div>
                        )}
                        {isFieldVisible("priority") && (
                          <div className="space-y-2">
                            <Label className="text-sm font-medium">
                              {getFieldDisplayName("priority") || "الأولوية"}
                            </Label>
                            <Select
                              value={state.formData.priority || "عادي"}
                              onValueChange={(value) =>
                                setState((prev) => ({
                                  ...prev,
                                  formData: { ...prev.formData, priority: value },
                                }))
                              }
                            >
                              <SelectTrigger className="h-11">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="منخفضة">منخفضة</SelectItem>
                                <SelectItem value="متوسطة">متوسطة</SelectItem>
                                <SelectItem value="عالية">عالية</SelectItem>
                                <SelectItem value="عاجلة">عاجلة</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        )}
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-4">
                <CardTitle className="text-lg flex items-center gap-2">
                  <User className="h-5 w-5 text-primary" />
                  معلومات العميل
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {isFieldVisible("customer_number") && (
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">
                        {getFieldDisplayName("customer_number") || "رقم العميل"}
                        {settings.find((s) => s.field_name === "customer_number")?.is_required && (
                          <span className="text-red-500 mr-1">*</span>
                        )}
                      </Label>
                      <div className="relative">
                        <Input
                          value={state.formData.customer_number ?? ""}
                          onChange={(e) =>
                            setState((prev) => ({
                              ...prev,
                              formData: { ...prev.formData, customer_number: e.target.value },
                            }))
                          }
                          className="text-right pr-12 h-11"
                          placeholder="C0000001"
                          dir="rtl"
                        />
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          className="absolute right-1 top-1/2 transform -translate-y-1/2 h-9 w-9 p-0"
                          onClick={() => setState((prev) => ({ ...prev, showCustomerSearch: true }))}
                        >
                          <Search className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  )}
                  {isFieldVisible("customer_name") && (
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">
                        {getFieldDisplayName("customer_name") || "اسم العميل"}
                        {settings.find((s) => s.field_name === "customer_name")?.is_required && (
                          <span className="text-red-500 mr-1">*</span>
                        )}
                      </Label>
                      <Input
                        value={state.formData.customer_name ?? ""}
                        onChange={(e) =>
                          setState((prev) => ({
                            ...prev,
                            formData: { ...prev.formData, customer_name: e.target.value },
                          }))
                        }
                        className="text-right h-11"
                        dir="rtl"
                      />
                    </div>
                  )}
                  {isFieldVisible("customer_phone") && (
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">
                        {getFieldDisplayName("customer_phone") || "هاتف العميل"}
                      </Label>
                      <Input
                        value={state.formData.customer_phone ?? ""}
                        onChange={(e) =>
                          setState((prev) => ({
                            ...prev,
                            formData: { ...prev.formData, customer_phone: e.target.value },
                          }))
                        }
                        className="text-right h-11"
                        dir="rtl"
                      />
                    </div>
                  )}
                  {isFieldVisible("payment_terms") && (
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">شروط الدفع</Label>
                      <Select
                        value={state.formData.payment_terms ?? "نقدي"}
                        onValueChange={(value) =>
                          setState((prev) => ({
                            ...prev,
                            formData: { ...prev.formData, payment_terms: value },
                          }))
                        }
                      >
                        <SelectTrigger className="h-11">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {paymentTerms.map((term) => (
                            <SelectItem key={term} value={term}>
                              {term}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                </div>

                {isFieldVisible("delivery_address") && (
                  <div className="space-y-2">
                    <Label className="text-sm font-medium">
                      {getFieldDisplayName("delivery_address") || "عنوان التسليم"}
                    </Label>
                    <Textarea
                      value={state.formData.delivery_address ?? ""}
                      onChange={(e) =>
                        setState((prev) => ({
                          ...prev,
                          formData: { ...prev.formData, delivery_address: e.target.value },
                        }))
                      }
                      className="text-right min-h-[100px] resize-none"
                      rows={3}
                      dir="rtl"
                    />
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-4">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Package className="h-5 w-5 text-primary" />
                    أصناف الطلبية
                  </CardTitle>
                  <Button onClick={addOrderItem} size="sm" className="h-10 w-full sm:w-auto">
                    <Plus className="h-4 w-4 ml-2" />
                    إضافة صنف
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto -mx-6 px-6">
                  <div className="inline-block min-w-full align-middle">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          {isFieldVisible("sequence") && (
                            <TableHead className="text-right w-16">{getFieldDisplayName("sequence")}</TableHead>
                          )}
                          {isFieldVisible("product_code") && (
                            <TableHead className="text-right min-w-[120px]">
                              {getFieldDisplayName("product_code")}
                            </TableHead>
                          )}
                          {isFieldVisible("product_name") && (
                            <TableHead className="text-right min-w-[200px]">
                              {getFieldDisplayName("product_name")}
                            </TableHead>
                          )}
                          {isFieldVisible("barcode") && (
                            <TableHead className="text-right min-w-[120px]">{getFieldDisplayName("barcode")}</TableHead>
                          )}
                          {isFieldVisible("quantity") && (
                            <TableHead className="text-right min-w-[120px]">
                              {getFieldDisplayName("quantity")}
                            </TableHead>
                          )}
                          {isFieldVisible("unit") && (
                            <TableHead className="text-right min-w-[100px]">{getFieldDisplayName("unit")}</TableHead>
                          )}
                          {isFieldVisible("unit_price") && (
                            <TableHead className="text-right min-w-[120px]">
                              {getFieldDisplayName("unit_price")}
                            </TableHead>
                          )}
                          {isFieldVisible("discount") && (
                            <TableHead className="text-right min-w-[100px]">
                              {getFieldDisplayName("discount")}
                            </TableHead>
                          )}
                          {isFieldVisible("tax") && (
                            <TableHead className="text-right min-w-[100px]">{getFieldDisplayName("tax")}</TableHead>
                          )}
                          {isFieldVisible("total") && (
                            <TableHead className="text-right min-w-[140px]">{getFieldDisplayName("total")}</TableHead>
                          )}
                          {isFieldVisible("warehouse") && (
                            <TableHead className="text-right min-w-[120px]">
                              {getFieldDisplayName("warehouse")}
                            </TableHead>
                          )}
                          {isFieldVisible("expiry_date") && (
                            <TableHead className="text-right min-w-[140px]">
                              {getFieldDisplayName("expiry_date")}
                            </TableHead>
                          )}
                          {isFieldVisible("batch_number") && (
                            <TableHead className="text-right min-w-[120px]">
                              {getFieldDisplayName("batch_number")}
                            </TableHead>
                          )}
                          {isFieldVisible("notes") && (
                            <TableHead className="text-right min-w-[150px]">{getFieldDisplayName("notes")}</TableHead>
                          )}
                          <TableHead className="text-right w-20 sticky left-0 bg-background">إجراءات</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {state.orderItems.map((item, index) => (
                          <TableRow key={item.id} data-product-row={item.id}>
                            {isFieldVisible("sequence") && (
                              <TableCell className="text-center font-medium">{index + 1}</TableCell>
                            )}
                            {isFieldVisible("product_code") && (
                              <TableCell>
                                <div className="relative">
                                  <Input
                                    value={item.product_code ?? ""}
                                    onChange={(e) => updateOrderItem(item.id, "product_code", e.target.value)}
                                    className="text-right pr-10 h-10"
                                    placeholder="كود"
                                    dir="rtl"
                                  />
                                  <Button
                                    type="button"
                                    variant="ghost"
                                    size="sm"
                                    className="absolute right-1 top-1/2 transform -translate-y-1/2 h-8 w-8 p-0"
                                    onClick={() =>
                                      setState((prev) => ({
                                        ...prev,
                                        showProductSearch: true,
                                        activeItemId: item.id,
                                      }))
                                    }
                                  >
                                    <Search className="h-4 w-4" />
                                  </Button>
                                </div>
                              </TableCell>
                            )}
                            {isFieldVisible("product_name") && (
                              <TableCell>
                                <Input
                                  value={item.product_name ?? ""}
                                  onChange={(e) => updateOrderItem(item.id, "product_name", e.target.value)}
                                  className="text-right h-10"
                                  placeholder="اسم المنتج"
                                  dir="rtl"
                                />
                              </TableCell>
                            )}
                            {isFieldVisible("barcode") && (
                              <TableCell>
                                <Input
                                  value={item.barcode ?? ""}
                                  onChange={(e) => updateOrderItem(item.id, "barcode", e.target.value)}
                                  className="text-right h-10"
                                  placeholder="الباركود"
                                  dir="rtl"
                                />
                              </TableCell>
                            )}
                            {isFieldVisible("quantity") && (
                              <TableCell>
                                <div className="flex items-center gap-1">
                                  <Input
                                    type="number"
                                    value={item.quantity}
                                    onChange={(e) =>
                                      updateOrderItem(item.id, "quantity", Number.parseFloat(e.target.value) || 0)
                                    }
                                    className="text-right h-10"
                                    dir="rtl"
                                  />
                                  {item.product_id && (
                                    <Button
                                      type="button"
                                      variant="ghost"
                                      size="sm"
                                      className="h-9 w-9 p-0 flex-shrink-0"
                                      onClick={() =>
                                        handleLotSelection(item.id, item.product_id!, item.product_name, item.quantity)
                                      }
                                      title="اختيار الدفعات (FIFO)"
                                    >
                                      <Package className="h-4 w-4" />
                                    </Button>
                                  )}
                                </div>
                              </TableCell>
                            )}
                            {isFieldVisible("unit") && (
                              <TableCell>
                                <Input
                                  value={item.unit ?? ""}
                                  onChange={(e) => updateOrderItem(item.id, "unit", e.target.value)}
                                  className="text-right h-10"
                                  dir="rtl"
                                />
                              </TableCell>
                            )}
                            {isFieldVisible("unit_price") && (
                              <TableCell>
                                <Input
                                  type="number"
                                  step="0.01"
                                  value={item.unit_price}
                                  onChange={(e) =>
                                    updateOrderItem(item.id, "unit_price", Number.parseFloat(e.target.value) || 0)
                                  }
                                  className="text-right h-10"
                                  dir="rtl"
                                />
                              </TableCell>
                            )}
                            {isFieldVisible("discount") && (
                              <TableCell>
                                <Input
                                  type="number"
                                  step="0.01"
                                  value={item.discount_percentage}
                                  onChange={(e) =>
                                    updateOrderItem(
                                      item.id,
                                      "discount_percentage",
                                      Number.parseFloat(e.target.value) || 0,
                                    )
                                  }
                                  className="text-right h-10"
                                  dir="rtl"
                                />
                              </TableCell>
                            )}
                            {isFieldVisible("tax") && (
                              <TableCell>
                                <Input
                                  type="number"
                                  step="0.01"
                                  value={item.tax_percentage}
                                  onChange={(e) =>
                                    updateOrderItem(item.id, "tax_percentage", Number.parseFloat(e.target.value) || 0)
                                  }
                                  className="text-right h-10"
                                  dir="rtl"
                                />
                              </TableCell>
                            )}
                            {isFieldVisible("total") && (
                              <TableCell>
                                <div className="text-right font-semibold text-base" dir="rtl">
                                  {calculateItemTotal(item).toFixed(2)} ر.س
                                </div>
                              </TableCell>
                            )}
                            {isFieldVisible("warehouse") && (
                              <TableCell>
                                <Select
                                  value={item.warehouse}
                                  onValueChange={(value) => updateOrderItem(item.id, "warehouse", value)}
                                >
                                  <SelectTrigger className="h-10">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    {warehouses.map((wh) => (
                                      <SelectItem key={wh} value={wh}>
                                        {wh}
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                              </TableCell>
                            )}
                            {isFieldVisible("expiry_date") && (
                              <TableCell>
                                <Input
                                  type="date"
                                  value={item.expiry_date ?? ""}
                                  onChange={(e) => updateOrderItem(item.id, "expiry_date", e.target.value)}
                                  className="text-right h-10"
                                  dir="rtl"
                                  readOnly={!!item.lot_id}
                                />
                              </TableCell>
                            )}
                            {isFieldVisible("batch_number") && (
                              <TableCell>
                                <Input
                                  value={item.batch_number ?? ""}
                                  onChange={(e) => updateOrderItem(item.id, "batch_number", e.target.value)}
                                  className="text-right h-10"
                                  dir="rtl"
                                  readOnly={!!item.lot_id}
                                />
                              </TableCell>
                            )}
                            {isFieldVisible("notes") && (
                              <TableCell>
                                <Input
                                  value={item.notes ?? ""}
                                  onChange={(e) => updateOrderItem(item.id, "notes", e.target.value)}
                                  className="text-right h-10"
                                  dir="rtl"
                                />
                              </TableCell>
                            )}
                            <TableCell className="sticky left-0 bg-background">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => removeOrderItem(item.id)}
                                className="text-red-600 hover:text-red-800 hover:bg-red-50 h-9 w-9 p-0"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader className="pb-4">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Percent className="h-5 w-5 text-primary" />
                    الخصومات والضرائب
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">نوع الخصم</Label>
                      <Select
                        value={state.formData.discount_type || "percentage"}
                        onValueChange={(value) =>
                          setState((prev) => ({
                            ...prev,
                            formData: { ...prev.formData, discount_type: value },
                          }))
                        }
                      >
                        <SelectTrigger className="h-11">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="percentage">نسبة مئوية</SelectItem>
                          <SelectItem value="amount">مبلغ ثابت</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">قيمة الخصم</Label>
                      <Input
                        type="number"
                        step="0.01"
                        value={state.formData.discount_value || 0}
                        onChange={(e) =>
                          setState((prev) => ({
                            ...prev,
                            formData: { ...prev.formData, discount_value: Number.parseFloat(e.target.value) || 0 },
                          }))
                        }
                        className="text-right h-11"
                        dir="rtl"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-sm font-medium">نسبة الضريبة (%)</Label>
                    <Input
                      type="number"
                      step="0.01"
                      value={state.formData.tax_percentage || 15}
                      onChange={(e) =>
                        setState((prev) => ({
                          ...prev,
                          formData: { ...prev.formData, tax_percentage: Number.parseFloat(e.target.value) || 0 },
                        }))
                      }
                      className="text-right h-11"
                      dir="rtl"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">تكلفة الشحن</Label>
                      <Input
                        type="number"
                        step="0.01"
                        value={state.formData.shipping_cost || 0}
                        onChange={(e) =>
                          setState((prev) => ({
                            ...prev,
                            formData: { ...prev.formData, shipping_cost: Number.parseFloat(e.target.value) || 0 },
                          }))
                        }
                        className="text-right h-11"
                        dir="rtl"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">رسوم أخرى</Label>
                      <Input
                        type="number"
                        step="0.01"
                        value={state.formData.other_charges || 0}
                        onChange={(e) =>
                          setState((prev) => ({
                            ...prev,
                            formData: { ...prev.formData, other_charges: Number.parseFloat(e.target.value) || 0 },
                          }))
                        }
                        className="text-right h-11"
                        dir="rtl"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20">
                <CardHeader className="pb-4">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Calculator className="h-5 w-5 text-primary" />
                    ملخص المبالغ
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center text-base py-2">
                      <span className="text-muted-foreground">المجموع الفرعي:</span>
                      <span className="font-semibold text-lg">{totals.subtotal.toFixed(2)} ر.س</span>
                    </div>
                    <div className="flex justify-between items-center text-base py-2">
                      <span className="text-muted-foreground">الخصم:</span>
                      <span className="font-semibold text-lg text-red-600">-{totals.discount.toFixed(2)} ر.س</span>
                    </div>
                    <div className="flex justify-between items-center text-base py-2">
                      <span className="text-muted-foreground">الضريبة:</span>
                      <span className="font-semibold text-lg">{totals.tax.toFixed(2)} ر.س</span>
                    </div>
                    <div className="flex justify-between items-center text-base py-2">
                      <span className="text-muted-foreground">الشحن:</span>
                      <span className="font-semibold text-lg">{state.formData.shipping_cost.toFixed(2)} ر.س</span>
                    </div>
                    <div className="flex justify-between items-center text-base py-2">
                      <span className="text-muted-foreground">رسوم أخرى:</span>
                      <span className="font-semibold text-lg">{state.formData.other_charges.toFixed(2)} ر.س</span>
                    </div>
                    <Separator className="my-4" />
                    <div className="flex justify-between items-center bg-primary/10 p-4 rounded-lg border border-primary/20">
                      <span className="text-lg font-bold">المجموع الكلي:</span>
                      <span className="text-2xl font-bold text-primary">{totals.total.toFixed(2)} ر.س</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="notes" className="border rounded-lg">
                <Card className="border-0">
                  <AccordionTrigger className="px-6 py-4 hover:no-underline">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <MessageSquare className="h-5 w-5 text-primary" />
                      الملاحظات
                    </CardTitle>
                  </AccordionTrigger>
                  <AccordionContent>
                    <CardContent className="space-y-6 pt-0">
                      <div className="space-y-2">
                        <Label className="text-sm font-medium">ملاحظات عامة</Label>
                        <Textarea
                          value={state.formData.notes ?? ""}
                          onChange={(e) =>
                            setState((prev) => ({
                              ...prev,
                              formData: { ...prev.formData, notes: e.target.value },
                            }))
                          }
                          className="text-right min-h-[100px] resize-none"
                          rows={4}
                          placeholder="ملاحظات للعميل"
                          dir="rtl"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label className="text-sm font-medium">ملاحظات داخلية</Label>
                        <Textarea
                          value={state.formData.internal_notes ?? ""}
                          onChange={(e) =>
                            setState((prev) => ({
                              ...prev,
                              formData: { ...prev.formData, internal_notes: e.target.value },
                            }))
                          }
                          className="text-right min-h-[100px] resize-none"
                          rows={4}
                          placeholder="ملاحظات للاستخدام الداخلي فقط"
                          dir="rtl"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label className="text-sm font-medium">ملاحظات التسليم</Label>
                        <Textarea
                          value={state.formData.delivery_notes ?? ""}
                          onChange={(e) =>
                            setState((prev) => ({
                              ...prev,
                              formData: { ...prev.formData, delivery_notes: e.target.value },
                            }))
                          }
                          className="text-right min-h-[100px] resize-none"
                          rows={4}
                          placeholder="ملاحظات خاصة بالتسليم"
                          dir="rtl"
                        />
                      </div>
                    </CardContent>
                  </AccordionContent>
                </Card>
              </AccordionItem>
            </Accordion>
          </div>
        </div>

        <div className="bg-muted/50 px-6 py-3 border-t">
          <div className="text-xs text-muted-foreground text-center">
            <span className="font-medium">الاختصارات:</span> F2 - بحث العملاء | F3 - بحث المنتجات | Ctrl+S - حفظ |
            Escape - إغلاق
          </div>
        </div>

        {/* Search dialogs and other modals remain the same */}
        {state.showCustomerSearch && (
          <InlineCustomerSearch
            customers={state.customers}
            onSelect={handleCustomerSelect}
            onClose={() => setState((prev) => ({ ...prev, showCustomerSearch: false }))}
          />
        )}

        {state.showProductSearch && (
          <InlineProductSearch
            products={state.products}
            onSelect={(product: any) => handleProductSelect(product, state.activeItemId!)}
            onClose={() => setState((prev) => ({ ...prev, showProductSearch: false, activeItemId: null }))}
          />
        )}

        {state.showLotSelector && state.selectedProductForLots && (
          <LotSelector
            open={state.showLotSelector}
            onOpenChange={(open) => setState((prev) => ({ ...prev, showLotSelector: open }))}
            productId={state.selectedProductForLots.id}
            productName={state.selectedProductForLots.product_name}
            requestedQuantity={state.orderItems.find((item) => item.id === state.selectedItemIdForLots)?.quantity || 0}
            onLotsSelected={handleLotsSelected}
          />
        )}

        <ReportGenerator
          title="تقرير طلبات المبيعات"
          data={allOrders}
          columns={reportColumns}
          isOpen={showReport}
          onClose={() => setShowReport(false)}
        />
      </DialogContent>
    </Dialog>
  )
}

export { UnifiedSalesOrder }
export default UnifiedSalesOrder
