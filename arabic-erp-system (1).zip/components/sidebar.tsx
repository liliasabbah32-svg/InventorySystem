"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  LayoutDashboard,
  Users,
  ShoppingCart,
  FileText,
  Settings,
  ChevronDown,
  ChevronRight,
  Package,
  Truck,
  BarChart3,
  DollarSign,
  UserCheck,
  Printer,
  Shield,
  Globe,
  Database,
  Palette,
  GitBranch,
  Archive,
  TrendingUp,
  ExternalLink,
  Unlock,
  UserCog,
  Sparkles,
  Lightbulb,
} from "lucide-react"
import { useWindowManager } from "@/contexts/window-manager-context"

interface SidebarProps {
  isOpen: boolean
  onToggle: () => void
  activeSection: string
  onSectionChange: (section: string) => void
  isMobile?: boolean
}

export function Sidebar({ isOpen, onToggle, activeSection, onSectionChange, isMobile = false }: SidebarProps) {
  const [expandedMenus, setExpandedMenus] = useState<string[]>(["definitions", "transactions", "reports", "settings"])
  const { openWindow } = useWindowManager()

  console.log("[v0] Sidebar render:", { activeSection, isOpen, isMobile })

  const toggleMenu = (menuId: string) => {
    setExpandedMenus((prev) => (prev.includes(menuId) ? prev.filter((id) => id !== menuId) : [...prev, menuId]))
  }

  const menuItems = [
    {
      id: "dashboard",
      title: "لوحة التحكم",
      icon: LayoutDashboard,
      section: "dashboard",
      windowSupport: false,
    },
    {
      id: "ai-assistant",
      title: "المساعد الذكي",
      icon: Sparkles,
      section: "ai-assistant",
      windowSupport: true,
    },
    {
      id: "smart-analytics",
      title: "التحليلات الذكية",
      icon: BarChart3,
      section: "smart-analytics",
      windowSupport: true,
    },
    {
      id: "smart-inventory",
      title: "توصيات المخزون الذكية",
      icon: Lightbulb,
      section: "smart-inventory",
      windowSupport: true,
    },
    {
      id: "inventory-analytics",
      title: "تحليلات المخزون",
      icon: TrendingUp,
      section: "inventory-analytics",
      windowSupport: true,
    },
    {
      id: "order-tracking",
      title: "متابعة الطلبيات",
      icon: GitBranch,
      section: "order-tracking",
      windowSupport: true,
    },
    {
      id: "lot-opener",
      title: "فتح الدفعات",
      icon: Unlock,
      section: "lot-opener",
      windowSupport: true,
    },
    {
      id: "definitions",
      title: "الملفات والتعريفات",
      icon: Users,
      submenu: [
        { title: "الزبائن", section: "customers", icon: Users, windowSupport: true, tabSupport: true },
        { title: "الموردين", section: "suppliers", icon: Truck, windowSupport: true, tabSupport: true },
        { title: "الأصناف والخدمات", section: "products", icon: Package, windowSupport: true, tabSupport: true },
        { title: "مجموعات الأصناف", section: "product-groups", icon: Package, windowSupport: true, tabSupport: true },
        { title: "التعريفات", section: "definitions", icon: Settings, windowSupport: false },
      ],
    },
    {
      id: "transactions",
      title: "الحركات",
      icon: ShoppingCart,
      submenu: [
        {
          title: "طلبيات المبيعات",
          section: "sales-orders",
          icon: ShoppingCart,
          windowSupport: true,
          tabSupport: true,
        },
        { title: "طلبيات المشتريات", section: "purchase-orders", icon: Truck, windowSupport: true, tabSupport: true },
        { title: "أسعار الصرف", section: "exchange-rates", icon: DollarSign, windowSupport: true },
        { title: "حركات الدفعات", section: "batch-movements", icon: Archive, windowSupport: true },
        { title: "إدارة حالات الدفعات", section: "lot-status-manager", icon: Package, windowSupport: true },
      ],
    },
    {
      id: "reports",
      title: "التقارير",
      icon: FileText,
      submenu: [
        { title: "تقارير الطلبيات", section: "order-reports", icon: BarChart3, windowSupport: true, tabSupport: true },
        { title: "تقارير الأصناف", section: "product-reports", icon: Package, windowSupport: true, tabSupport: true },
        { title: "تقارير الدفعات", section: "batch-reports", icon: Archive, windowSupport: true },
      ],
    },
    {
      id: "settings",
      title: "الإعدادات",
      icon: Settings,
      submenu: [
        { title: "فحص الجودة", section: "qa-dashboard", icon: Shield, windowSupport: false },
        { title: "تخصيص المظهر", section: "theme-customization", icon: Palette, windowSupport: false },
        { title: "إعدادات المستخدمين", section: "user-settings", icon: UserCheck, windowSupport: false },
        { title: "إدارة بوابة العملاء", section: "customer-portal-admin", icon: UserCog, windowSupport: false },
        { title: "إعدادات الطباعة", section: "print-settings", icon: Printer, windowSupport: false },
        { title: "إعدادات النظام", section: "system-settings", icon: Settings, windowSupport: false },
        { title: "إعدادات السندات", section: "document-settings", icon: FileText, windowSupport: false },
        { title: "الصلاحيات", section: "permissions", icon: Shield, windowSupport: false },
        { title: "إعدادات عامة", section: "general-settings", icon: Globe, windowSupport: false },
        { title: "إعدادات API", section: "api-settings", icon: Database, windowSupport: false },
        { title: "إعدادات Pervasive", section: "pervasive-settings", icon: Database, windowSupport: false },
      ],
    },
  ]

  const handleItemClick = (item: any, openInModal = false) => {
    console.log("[v0] Sidebar item clicked:", { section: item.section, openInModal, windowSupport: item.windowSupport })

    if (openInModal && item.windowSupport) {
      openWindow({
        title: item.title,
        component: item.section,
        type: "modal",
        size: { width: 1000, height: 700 },
        position: { x: 150, y: 100 },
      })
    } else if (item.tabSupport) {
      onSectionChange(item.section)
    } else {
      onSectionChange(item.section)
    }
  }

  if (!isOpen && !isMobile) {
    return (
      <div
        className="w-16 erp-sidebar flex flex-col items-center py-4 border-l border-sidebar-border fixed right-0 top-0 h-full"
        dir="rtl"
      >
        <Button variant="ghost" size="icon" onClick={onToggle} className="mb-4">
          <ChevronRight className="h-4 w-4" />
        </Button>
        {menuItems.map((item) => (
          <Button
            key={item.id}
            variant="ghost"
            size="icon"
            className="mb-2"
            onClick={() => item.section && handleItemClick(item)}
          >
            <item.icon className="h-5 w-5" />
          </Button>
        ))}
      </div>
    )
  }

  return (
    <div
      className={`${isMobile ? "w-72" : "w-80"} erp-sidebar border-l border-sidebar-border bg-background fixed right-0 top-0 h-full`}
      dir="rtl"
    >
      <div className="p-4 md:p-6 border-b border-sidebar-border bg-primary">
        <div className="flex items-center justify-between" dir="rtl">
          <div className="flex items-center gap-2 md:gap-3 flex-row-reverse">
            <div className="text-right">
              <h2 className="text-base md:text-lg font-semibold text-white text-right">نظام إدارة المخزون والطلبيات</h2>
              <p className="text-xs text-primary-foreground/80 text-right">إدارة متكاملة</p>
            </div>
            <div className="w-8 h-8 md:w-10 md:h-10 bg-white rounded-lg flex items-center justify-center">
              <span className="text-primary font-bold text-sm md:text-lg">ERP</span>
            </div>
          </div>
          <Button variant="ghost" size="icon" onClick={onToggle} className="text-white hover:bg-white/10">
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <nav
        className="p-2 md:p-4 space-y-1 overflow-y-auto max-h-[calc(100vh-100px)] md:max-h-[calc(100vh-120px)]"
        dir="rtl"
      >
        {menuItems.map((item) => (
          <div key={item.id}>
            <Button
              variant={activeSection === item.section ? "secondary" : "ghost"}
              className="w-full justify-between text-right hover:bg-sidebar-accent/10 text-sm md:text-base p-2 md:p-3"
              onClick={() => {
                if (item.submenu) {
                  toggleMenu(item.id)
                } else if (item.section) {
                  handleItemClick(item)
                }
              }}
              dir="rtl"
            >
              <div className="flex items-center gap-2 md:gap-3">
                <item.icon className="h-4 w-4 md:h-5 md:w-5" />
                <span className="font-medium text-right">{item.title}</span>
              </div>
              <div className="flex items-center gap-1">
                {item.windowSupport && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-6 w-6 p-0 hover:bg-sidebar-accent/20"
                    onClick={(e) => {
                      e.stopPropagation()
                      handleItemClick(item, true)
                    }}
                    title="فتح في نافذة منبثقة"
                  >
                    <ExternalLink className="h-3 w-3" />
                  </Button>
                )}
                {item.submenu && (
                  <ChevronDown
                    className={`h-3 w-3 md:h-4 md:w-4 transition-transform ${expandedMenus.includes(item.id) ? "rotate-180" : ""}`}
                  />
                )}
              </div>
            </Button>

            {item.submenu && expandedMenus.includes(item.id) && (
              <div className="ml-4 md:ml-6 mt-1 space-y-1 border-l-2 border-sidebar-border pl-2 md:pl-4" dir="rtl">
                {item.submenu.map((subItem) => (
                  <div key={subItem.section} className="flex items-center gap-1">
                    <Button
                      variant={activeSection === subItem.section ? "secondary" : "ghost"}
                      size="sm"
                      className="flex-1 justify-start text-right text-muted-foreground hover:text-foreground hover:bg-sidebar-accent/10 text-xs md:text-sm p-2"
                      onClick={() => handleItemClick(subItem)}
                      dir="rtl"
                    >
                      <div className="flex items-center gap-2">
                        {subItem.icon && <subItem.icon className="h-3 w-3 md:h-4 md:w-4" />}
                        <span className="text-right">{subItem.title}</span>
                      </div>
                    </Button>
                    {subItem.windowSupport && (
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-6 w-6 p-0 hover:bg-sidebar-accent/20 flex-shrink-0"
                        onClick={() => handleItemClick(subItem, true)}
                        title="فتح في نافذة منبثقة"
                      >
                        <ExternalLink className="h-3 w-3" />
                      </Button>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </nav>
    </div>
  )
}
