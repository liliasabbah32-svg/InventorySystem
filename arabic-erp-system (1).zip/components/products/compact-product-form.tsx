"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { Separator } from "@/components/ui/separator"
import { UniversalToolbar } from "@/components/ui/universal-toolbar"
import { Package, Save, X, Barcode, DollarSign, Warehouse, Truck, Info, Settings, Package2 } from "lucide-react"
import { WarehouseInventoryTable } from "./warehouse-inventory-table"
import { BatchTrackingTable } from "./batch-tracking-table"

interface ProductFormData {
  product_code: string
  product_name: string
  product_name_en: string
  barcode: string
  description: string
  category: string
  subcategory: string
  brand: string
  model: string
  main_unit: string
  secondary_unit: string
  conversion_factor: number
  last_purchase_price: number
  average_cost: number
  selling_price: number
  wholesale_price: number
  retail_price: number
  currency: string
  tax_rate: number
  discount_rate: number
  min_stock_level: number
  max_stock_level: number
  reorder_point: number
  location: string
  shelf_life: number
  expiry_tracking: boolean
  batch_tracking: boolean
  serial_tracking: boolean
  status: string
  supplier_id: string
  supplier_name: string
  supplier_code: string
  manufacturer: string
  country_of_origin: string
  weight: number
  dimensions: string
  color: string
  size: string
  material: string
  warranty_period: number
  image_url: string
  notes: string
  available_quantity?: number
  reserved_quantity?: number
  actual_balance?: number
  inventory_value?: number
  warehouse_name?: string
  stock_status?: string
  batch_number?: string
  expiry_date?: string
  manufacturing_date?: string
  serial_number?: string
}

const initialFormData: ProductFormData = {
  product_code: "",
  product_name: "",
  product_name_en: "",
  barcode: "",
  description: "",
  category: "",
  subcategory: "",
  brand: "",
  model: "",
  main_unit: "قطعة",
  secondary_unit: "",
  conversion_factor: 1,
  last_purchase_price: 0,
  average_cost: 0,
  selling_price: 0,
  wholesale_price: 0,
  retail_price: 0,
  currency: "ريال سعودي",
  tax_rate: 15,
  discount_rate: 0,
  min_stock_level: 0,
  max_stock_level: 0,
  reorder_point: 0,
  location: "",
  shelf_life: 0,
  expiry_tracking: false,
  batch_tracking: false,
  serial_tracking: false,
  status: "نشط",
  supplier_id: "",
  supplier_name: "",
  supplier_code: "",
  manufacturer: "",
  country_of_origin: "",
  weight: 0,
  dimensions: "",
  color: "",
  size: "",
  material: "",
  warranty_period: 0,
  image_url: "",
  notes: "",
  available_quantity: 0,
  reserved_quantity: 0,
  actual_balance: 0,
  inventory_value: 0,
  warehouse_name: "",
  stock_status: "",
  batch_number: "",
  expiry_date: "",
  manufacturing_date: "",
  serial_number: "",
}

interface CompactProductFormProps {
  editingProduct?: any
  onSave: (data: ProductFormData) => void
  onCancel: () => void
  isSubmitting?: boolean
}

export function CompactProductForm({
  editingProduct,
  onSave,
  onCancel,
  isSubmitting = false,
}: CompactProductFormProps) {
  const [formData, setFormData] = useState<ProductFormData>(initialFormData)
  const [isSearching, setIsSearching] = useState(false)
  const [productCodeError, setProductCodeError] = useState("")
  const [definitions, setDefinitions] = useState({
    categories: [] as Array<{ id: number; name: string }>,
    suppliers: [] as Array<{ id: number; name: string; code?: string }>,
    warehouses: [] as Array<{ id: number; name: string }>,
    units: [] as Array<{ id: number; unit_name: string; unit_code: string }>, // Added units from API
  })

  const currencies = ["ريال سعودي", "دولار أمريكي", "يورو", "شيكل إسرائيلي"]

  const countries = [
    "السعودية",
    "الإمارات",
    "الكويت",
    "قطر",
    "البحرين",
    "عمان",
    "الأردن",
    "لبنان",
    "سوريا",
    "العراق",
    "مصر",
    "المغرب",
    "تونس",
    "الجزائر",
    "أخرى",
  ]

  const stockStatuses = ["متوفر", "تحت الحد الأدنى", "نفد المخزون", "محجوز", "تالف"]

  useEffect(() => {
    fetchDefinitions()

    if (editingProduct) {
      setFormData({
        product_code: editingProduct.product_code || "",
        product_name: editingProduct.product_name || "",
        product_name_en: editingProduct.product_name_en || "",
        barcode: editingProduct.barcode || "",
        description: editingProduct.description || "",
        category: editingProduct.category || "",
        subcategory: editingProduct.subcategory || "",
        brand: editingProduct.brand || "",
        model: editingProduct.model || "",
        main_unit: editingProduct.main_unit || "قطعة",
        secondary_unit: editingProduct.secondary_unit || "",
        conversion_factor: editingProduct.conversion_factor || 1,
        last_purchase_price: editingProduct.last_purchase_price || 0,
        average_cost: editingProduct.average_cost || 0,
        selling_price: editingProduct.selling_price || 0,
        wholesale_price: editingProduct.wholesale_price || 0,
        retail_price: editingProduct.retail_price || 0,
        currency: editingProduct.currency || "ريال سعودي",
        tax_rate: editingProduct.tax_rate || 15,
        discount_rate: editingProduct.discount_rate || 0,
        min_stock_level: editingProduct.min_stock_level || 0,
        max_stock_level: editingProduct.max_stock_level || 0,
        reorder_point: editingProduct.reorder_point || 0,
        location: editingProduct.location || "",
        shelf_life: editingProduct.shelf_life || 0,
        expiry_tracking: editingProduct.expiry_tracking || false,
        batch_tracking: editingProduct.batch_tracking || false,
        serial_tracking: editingProduct.serial_tracking || false,
        status: editingProduct.status || "نشط",
        supplier_id: editingProduct.supplier_id?.toString() || "",
        supplier_name: editingProduct.supplier_name || "",
        supplier_code: editingProduct.supplier_code || "",
        manufacturer: editingProduct.manufacturer || "",
        country_of_origin: editingProduct.country_of_origin || "",
        weight: editingProduct.weight || 0,
        dimensions: editingProduct.dimensions || "",
        color: editingProduct.color || "",
        size: editingProduct.size || "",
        material: editingProduct.material || "",
        warranty_period: editingProduct.warranty_period || 0,
        image_url: editingProduct.image_url || "",
        notes: editingProduct.notes || "",
        available_quantity: editingProduct.available_quantity || 0,
        reserved_quantity: editingProduct.reserved_quantity || 0,
        actual_balance: editingProduct.actual_balance || 0,
        inventory_value: editingProduct.inventory_value || 0,
        warehouse_name: editingProduct.warehouse_name || "",
        stock_status: editingProduct.stock_status || "",
        batch_number: editingProduct.batch_number || "",
        expiry_date: editingProduct.expiry_date || "",
        manufacturing_date: editingProduct.manufacturing_date || "",
        serial_number: editingProduct.serial_number || "",
      })
    } else {
      setFormData(initialFormData)
    }
  }, [editingProduct])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSave(formData)
  }

  const updateFormData = (field: keyof ProductFormData, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const validateProductCode = (code: string): boolean => {
    // يجب أن يكون الكود بحد أقصى 8 خانات ويحتوي على أرقام وحروف إنجليزية فقط
    const regex = /^[A-Za-z0-9]{1,8}$/
    return regex.test(code)
  }

  const searchProductByCode = async (code: string) => {
    if (!code || code.length === 0) return

    try {
      setIsSearching(true)
      setProductCodeError("")

      const response = await fetch(`/api/inventory/products/search?code=${encodeURIComponent(code)}`)
      if (response.ok) {
        const product = await response.json()
        if (product && product.id) {
          // إذا وُجد المنتج، املأ النموذج ببياناته
          setFormData({
            product_code: product.product_code || "",
            product_name: product.product_name || "",
            product_name_en: product.product_name_en || "",
            barcode: product.barcode || "",
            description: product.description || "",
            category: product.category || "",
            subcategory: product.subcategory || "",
            brand: product.brand || "",
            model: product.model || "",
            main_unit: product.main_unit || "قطعة",
            secondary_unit: product.secondary_unit || "",
            conversion_factor: product.conversion_factor || 1,
            last_purchase_price: product.last_purchase_price || 0,
            average_cost: product.average_cost || 0,
            selling_price: product.selling_price || 0,
            wholesale_price: product.wholesale_price || 0,
            retail_price: product.retail_price || 0,
            currency: product.currency || "ريال سعودي",
            tax_rate: product.tax_rate || 15,
            discount_rate: product.discount_rate || 0,
            min_stock_level: product.min_stock_level || 0,
            max_stock_level: product.max_stock_level || 0,
            reorder_point: product.reorder_point || 0,
            location: product.location || "",
            shelf_life: product.shelf_life || 0,
            expiry_tracking: product.expiry_tracking || false,
            batch_tracking: product.batch_tracking || false,
            serial_tracking: product.serial_tracking || false,
            status: product.status || "نشط",
            supplier_id: product.supplier_id?.toString() || "",
            supplier_name: product.supplier_name || "",
            supplier_code: product.supplier_code || "",
            manufacturer: product.manufacturer || "",
            country_of_origin: product.country_of_origin || "",
            weight: product.weight || 0,
            dimensions: product.dimensions || "",
            color: product.color || "",
            size: product.size || "",
            material: product.material || "",
            warranty_period: product.warranty_period || 0,
            image_url: product.image_url || "",
            notes: product.notes || "",
            available_quantity: product.available_quantity || 0,
            reserved_quantity: product.reserved_quantity || 0,
            actual_balance: product.actual_balance || 0,
            inventory_value: product.inventory_value || 0,
            warehouse_name: product.warehouse_name || "",
            stock_status: product.stock_status || "",
            batch_number: product.batch_number || "",
            expiry_date: product.expiry_date || "",
            manufacturing_date: product.manufacturing_date || "",
            serial_number: product.serial_number || "",
          })
        }
      } else if (response.status === 404) {
        // المنتج غير موجود - هذا طبيعي للمنتجات الجديدة
        console.log("[v0] Product not found - this is normal for new products")
      }
    } catch (error) {
      console.error("[v0] Error searching for product:", error)
    } finally {
      setIsSearching(false)
    }
  }

  const handleProductCodeChange = (value: string) => {
    // تنظيف القيمة للسماح بالأرقام والحروف الإنجليزية فقط
    const cleanValue = value.replace(/[^A-Za-z0-9]/g, "").slice(0, 8)

    if (cleanValue !== value) {
      setProductCodeError("يُسمح بالأرقام والحروف الإنجليزية فقط (حد أقصى 8 خانات)")
    } else {
      setProductCodeError("")
    }

    updateFormData("product_code", cleanValue)
  }

  const handleProductCodeBlur = () => {
    if (formData.product_code && validateProductCode(formData.product_code)) {
      searchProductByCode(formData.product_code)
    }
  }

  const fetchDefinitions = async () => {
    try {
      // جلب التصنيفات
      const categoriesResponse = await fetch("/api/item-groups")
      if (categoriesResponse.ok) {
        const categoriesData = await categoriesResponse.json()
        setDefinitions((prev) => ({ ...prev, categories: categoriesData }))
      }

      // جلب الموردين
      const suppliersResponse = await fetch("/api/suppliers")
      if (suppliersResponse.ok) {
        const suppliersData = await suppliersResponse.json()
        setDefinitions((prev) => ({ ...prev, suppliers: suppliersData }))
      }

      // جلب المستودعات
      const warehousesResponse = await fetch("/api/warehouses")
      if (warehousesResponse.ok) {
        const warehousesData = await warehousesResponse.json()
        setDefinitions((prev) => ({ ...prev, warehouses: warehousesData }))
      }

      const unitsResponse = await fetch("/api/units")
      if (unitsResponse.ok) {
        const unitsData = await unitsResponse.json()
        setDefinitions((prev) => ({ ...prev, units: unitsData }))
      }
    } catch (error) {
      console.error("[v0] Error fetching definitions:", error)
    }
  }

  const handleSupplierChange = (value: string) => {
    if (value === "none") {
      updateFormData("supplier_id", "")
      updateFormData("supplier_name", "")
      updateFormData("supplier_code", "")
    } else {
      const supplier = definitions.suppliers.find((s) => s.id.toString() === value)
      if (supplier) {
        updateFormData("supplier_id", supplier.id.toString())
        updateFormData("supplier_name", supplier.name)
        updateFormData("supplier_code", supplier.code || "")
      }
    }
  }

  const handleCategoryChange = (value: string) => {
    if (value === "none") {
      updateFormData("category", "")
    } else {
      updateFormData("category", value)
    }
  }

  return (
    <div className="h-screen flex flex-col bg-background" dir="rtl">
      {/* Universal Toolbar - Fixed at top */}
      <div className="flex-shrink-0">
        <UniversalToolbar
          currentRecord={1}
          totalRecords={1}
          onFirst={() => {}}
          onPrevious={() => {}}
          onNext={() => {}}
          onLast={() => {}}
          onNew={() => setFormData(initialFormData)}
          onSave={() => onSave(formData)}
          onDelete={() => {}}
          onReport={() => console.log("Generate product report")}
          onExportExcel={() => console.log("Export to Excel")}
          onPrint={() => console.log("Print product")}
          isLoading={isSearching}
          isSaving={isSubmitting}
          canSave={true}
          canDelete={false}
          isFirstRecord={true}
          isLastRecord={true}
        />
      </div>

      <div className="flex-1 overflow-y-auto">
        <div className="space-y-6 p-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-foreground flex items-center gap-3">
                <Package className="h-7 w-7 text-primary" />
                {editingProduct ? "تعديل الصنف" : "صنف جديد"}
              </h1>
              <p className="text-muted-foreground mt-1">جميع بيانات الصنف في شاشة واحدة مضغوطة</p>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* المعلومات الأساسية والتعريف */}
            <Card>
              <CardHeader className="pb-4">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Info className="h-5 w-5 text-primary" />
                  المعلومات الأساسية والتعريف
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* الصف الأول: الأكواد والتعريف */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div>
                    <Label htmlFor="product_code" className="text-sm font-medium">
                      كود الصنف * (حد أقصى 8 خانات)
                    </Label>
                    <div className="relative">
                      <Input
                        id="product_code"
                        value={formData.product_code}
                        onChange={(e) => handleProductCodeChange(e.target.value)}
                        onBlur={handleProductCodeBlur}
                        className={`text-right ${productCodeError ? "border-red-500" : ""}`}
                        placeholder="أرقام وحروف إنجليزية فقط"
                        maxLength={8}
                        required
                      />
                      {isSearching && (
                        <div className="absolute left-3 top-1/2 transform -translate-y-1/2">
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary"></div>
                        </div>
                      )}
                    </div>
                    {productCodeError && <p className="text-red-500 text-xs mt-1">{productCodeError}</p>}
                    <p className="text-muted-foreground text-xs mt-1">اتركه فارغاً للتوليد التلقائي أو أدخل كود مخصص</p>
                  </div>
                  <div>
                    <Label htmlFor="barcode" className="text-sm font-medium">
                      الباركود
                    </Label>
                    <div className="relative">
                      <Barcode className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        id="barcode"
                        value={formData.barcode}
                        onChange={(e) => updateFormData("barcode", e.target.value)}
                        className="text-right pr-10"
                        placeholder="رقم الباركود"
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="status" className="text-sm font-medium">
                      حالة الصنف
                    </Label>
                    <Select value={formData.status} onValueChange={(value) => updateFormData("status", value)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="نشط">نشط</SelectItem>
                        <SelectItem value="غير نشط">غير نشط</SelectItem>
                        <SelectItem value="متوقف">متوقف</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="image_url" className="text-sm font-medium">
                      رابط الصورة
                    </Label>
                    <Input
                      id="image_url"
                      value={formData.image_url}
                      onChange={(e) => updateFormData("image_url", e.target.value)}
                      className="text-left"
                      placeholder="https://example.com/image.jpg"
                    />
                  </div>
                </div>

                {/* الصف الثاني: الأسماء */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="product_name" className="text-sm font-medium">
                      اسم الصنف *
                    </Label>
                    <Input
                      id="product_name"
                      value={formData.product_name}
                      onChange={(e) => updateFormData("product_name", e.target.value)}
                      className="text-right"
                      placeholder="اسم الصنف باللغة العربية"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="product_name_en" className="text-sm font-medium">
                      اسم الصنف بالإنجليزية
                    </Label>
                    <Input
                      id="product_name_en"
                      value={formData.product_name_en}
                      onChange={(e) => updateFormData("product_name_en", e.target.value)}
                      className="text-left"
                      placeholder="Product Name in English"
                    />
                  </div>
                </div>

                {/* الوصف */}
                <div>
                  <Label htmlFor="description" className="text-sm font-medium">
                    وصف الصنف
                  </Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => updateFormData("description", e.target.value)}
                    className="text-right"
                    rows={2}
                    placeholder="وصف مفصل للصنف"
                  />
                </div>
              </CardContent>
            </Card>

            {/* التصنيف والعلامة التجارية */}
            <Card>
              <CardHeader className="pb-4">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Settings className="h-5 w-5 text-primary" />
                  التصنيف والعلامة التجارية
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                  <div>
                    <Label htmlFor="category" className="text-sm font-medium">
                      الفئة الرئيسية *
                    </Label>
                    <Select value={formData.category} onValueChange={handleCategoryChange}>
                      <SelectTrigger>
                        <SelectValue placeholder="اختر الفئة" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">بدون فئة</SelectItem>
                        {definitions.categories.map((category) => (
                          <SelectItem key={category.id} value={category.name}>
                            {category.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="subcategory" className="text-sm font-medium">
                      الفئة الفرعية
                    </Label>
                    <Input
                      id="subcategory"
                      value={formData.subcategory}
                      onChange={(e) => updateFormData("subcategory", e.target.value)}
                      className="text-right"
                      placeholder="الفئة الفرعية"
                    />
                  </div>
                  <div>
                    <Label htmlFor="brand" className="text-sm font-medium">
                      العلامة التجارية
                    </Label>
                    <Input
                      id="brand"
                      value={formData.brand}
                      onChange={(e) => updateFormData("brand", e.target.value)}
                      className="text-right"
                      placeholder="اسم العلامة التجارية"
                    />
                  </div>
                  <div>
                    <Label htmlFor="model" className="text-sm font-medium">
                      الموديل
                    </Label>
                    <Input
                      id="model"
                      value={formData.model}
                      onChange={(e) => updateFormData("model", e.target.value)}
                      className="text-right"
                      placeholder="رقم أو اسم الموديل"
                    />
                  </div>
                  <div>
                    <Label htmlFor="manufacturer" className="text-sm font-medium">
                      الشركة المصنعة
                    </Label>
                    <Input
                      id="manufacturer"
                      value={formData.manufacturer}
                      onChange={(e) => updateFormData("manufacturer", e.target.value)}
                      className="text-right"
                      placeholder="اسم الشركة المصنعة"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* الوحدات والقياسات */}
            <Card>
              <CardHeader className="pb-4">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Package className="h-5 w-5 text-primary" />
                  الوحدات والقياسات الفيزيائية
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
                  <div>
                    <Label htmlFor="main_unit" className="text-sm font-medium">
                      الوحدة الأساسية *
                    </Label>
                    <Select value={formData.main_unit} onValueChange={(value) => updateFormData("main_unit", value)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {definitions.units.map((unit) => (
                          <SelectItem key={unit.id} value={unit.unit_name}>
                            {unit.unit_name}
                          </SelectItem>
                        ))}
                        {/* Fallback to static units if API fails */}
                        {definitions.units.length === 0 && (
                          <>
                            <SelectItem value="قطعة">قطعة</SelectItem>
                            <SelectItem value="كيلو">كيلو</SelectItem>
                            <SelectItem value="جرام">جرام</SelectItem>
                            <SelectItem value="لتر">لتر</SelectItem>
                            <SelectItem value="متر">متر</SelectItem>
                            <SelectItem value="صندوق">صندوق</SelectItem>
                            <SelectItem value="كرتون">كرتون</SelectItem>
                            <SelectItem value="علبة">علبة</SelectItem>
                            <SelectItem value="زجاجة">زجاجة</SelectItem>
                            <SelectItem value="كيس">كيس</SelectItem>
                          </>
                        )}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="secondary_unit" className="text-sm font-medium">
                      الوحدة الثانوية
                    </Label>
                    <Select
                      value={formData.secondary_unit}
                      onValueChange={(value) => updateFormData("secondary_unit", value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="اختر الوحدة" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="بدون">بدون</SelectItem>
                        {definitions.units.map((unit) => (
                          <SelectItem key={unit.id} value={unit.unit_name}>
                            {unit.unit_name}
                          </SelectItem>
                        ))}
                        {/* Fallback to static units if API fails */}
                        {definitions.units.length === 0 && (
                          <>
                            <SelectItem value="قطعة">قطعة</SelectItem>
                            <SelectItem value="كيلو">كيلو</SelectItem>
                            <SelectItem value="جرام">جرام</SelectItem>
                            <SelectItem value="لتر">لتر</SelectItem>
                            <SelectItem value="متر">متر</SelectItem>
                            <SelectItem value="صندوق">صندوق</SelectItem>
                            <SelectItem value="كرتون">كرتون</SelectItem>
                            <SelectItem value="علبة">علبة</SelectItem>
                            <SelectItem value="زجاجة">زجاجة</SelectItem>
                            <SelectItem value="كيس">كيس</SelectItem>
                          </>
                        )}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="conversion_factor" className="text-sm font-medium">
                      معامل التحويل
                    </Label>
                    <Input
                      id="conversion_factor"
                      type="number"
                      step="0.01"
                      value={formData.conversion_factor}
                      onChange={(e) => updateFormData("conversion_factor", Number.parseFloat(e.target.value) || 1)}
                      className="text-right"
                    />
                  </div>
                  <div>
                    <Label htmlFor="weight" className="text-sm font-medium">
                      الوزن (كجم)
                    </Label>
                    <Input
                      id="weight"
                      type="number"
                      step="0.01"
                      value={formData.weight}
                      onChange={(e) => updateFormData("weight", Number.parseFloat(e.target.value) || 0)}
                      className="text-right"
                    />
                  </div>
                  <div>
                    <Label htmlFor="dimensions" className="text-sm font-medium">
                      الأبعاد
                    </Label>
                    <Input
                      id="dimensions"
                      value={formData.dimensions}
                      onChange={(e) => updateFormData("dimensions", e.target.value)}
                      className="text-right"
                      placeholder="الطول × العرض × الارتفاع"
                    />
                  </div>
                  <div>
                    <Label htmlFor="country_of_origin" className="text-sm font-medium">
                      بلد المنشأ
                    </Label>
                    <Select
                      value={formData.country_of_origin}
                      onValueChange={(value) => updateFormData("country_of_origin", value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="اختر البلد" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="غير محدد">غير محدد</SelectItem>
                        {countries.map((country) => (
                          <SelectItem key={country} value={country}>
                            {country}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <Separator className="my-4" />

                {/* الخصائص الفيزيائية */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div>
                    <Label htmlFor="color" className="text-sm font-medium">
                      اللون
                    </Label>
                    <Input
                      id="color"
                      value={formData.color}
                      onChange={(e) => updateFormData("color", e.target.value)}
                      className="text-right"
                      placeholder="لون الصنف"
                    />
                  </div>
                  <div>
                    <Label htmlFor="size" className="text-sm font-medium">
                      الحجم
                    </Label>
                    <Input
                      id="size"
                      value={formData.size}
                      onChange={(e) => updateFormData("size", e.target.value)}
                      className="text-right"
                      placeholder="حجم الصنف"
                    />
                  </div>
                  <div>
                    <Label htmlFor="material" className="text-sm font-medium">
                      المادة
                    </Label>
                    <Input
                      id="material"
                      value={formData.material}
                      onChange={(e) => updateFormData("material", e.target.value)}
                      className="text-right"
                      placeholder="المادة المصنوع منها"
                    />
                  </div>
                  <div>
                    <Label htmlFor="warranty_period" className="text-sm font-medium">
                      فترة الضمان (شهر)
                    </Label>
                    <Input
                      id="warranty_period"
                      type="number"
                      value={formData.warranty_period}
                      onChange={(e) => updateFormData("warranty_period", Number.parseInt(e.target.value) || 0)}
                      className="text-right"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* الأسعار والعملة */}
            <Card>
              <CardHeader className="pb-4">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <DollarSign className="h-5 w-5 text-primary" />
                  الأسعار والعملة والضرائب
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
                  <div>
                    <Label htmlFor="last_purchase_price" className="text-sm font-medium">
                      آخر سعر شراء
                    </Label>
                    <Input
                      id="last_purchase_price"
                      type="number"
                      step="0.01"
                      value={formData.last_purchase_price}
                      onChange={(e) => updateFormData("last_purchase_price", Number.parseFloat(e.target.value) || 0)}
                      className="text-right"
                    />
                  </div>
                  <div>
                    <Label htmlFor="average_cost" className="text-sm font-medium">
                      متوسط التكلفة
                    </Label>
                    <Input
                      id="average_cost"
                      type="number"
                      step="0.01"
                      value={formData.average_cost}
                      onChange={(e) => updateFormData("average_cost", Number.parseFloat(e.target.value) || 0)}
                      className="text-right"
                    />
                  </div>
                  <div>
                    <Label htmlFor="selling_price" className="text-sm font-medium">
                      سعر البيع
                    </Label>
                    <Input
                      id="selling_price"
                      type="number"
                      step="0.01"
                      value={formData.selling_price}
                      onChange={(e) => updateFormData("selling_price", Number.parseFloat(e.target.value) || 0)}
                      className="text-right"
                    />
                  </div>
                  <div>
                    <Label htmlFor="wholesale_price" className="text-sm font-medium">
                      سعر الجملة
                    </Label>
                    <Input
                      id="wholesale_price"
                      type="number"
                      step="0.01"
                      value={formData.wholesale_price}
                      onChange={(e) => updateFormData("wholesale_price", Number.parseFloat(e.target.value) || 0)}
                      className="text-right"
                    />
                  </div>
                  <div>
                    <Label htmlFor="retail_price" className="text-sm font-medium">
                      سعر التجزئة
                    </Label>
                    <Input
                      id="retail_price"
                      type="number"
                      step="0.01"
                      value={formData.retail_price}
                      onChange={(e) => updateFormData("retail_price", Number.parseFloat(e.target.value) || 0)}
                      className="text-right"
                    />
                  </div>
                  <div>
                    <Label htmlFor="currency" className="text-sm font-medium">
                      العملة
                    </Label>
                    <Select value={formData.currency} onValueChange={(value) => updateFormData("currency", value)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {currencies.map((currency) => (
                          <SelectItem key={currency} value={currency}>
                            {currency}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <Separator className="my-4" />

                {/* الضرائب والخصومات */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="tax_rate" className="text-sm font-medium">
                      معدل الضريبة (%)
                    </Label>
                    <Input
                      id="tax_rate"
                      type="number"
                      step="0.01"
                      value={formData.tax_rate}
                      onChange={(e) => updateFormData("tax_rate", Number.parseFloat(e.target.value) || 0)}
                      className="text-right"
                    />
                  </div>
                  <div>
                    <Label htmlFor="discount_rate" className="text-sm font-medium">
                      معدل الخصم (%)
                    </Label>
                    <Input
                      id="discount_rate"
                      type="number"
                      step="0.01"
                      value={formData.discount_rate}
                      onChange={(e) => updateFormData("discount_rate", Number.parseFloat(e.target.value) || 0)}
                      className="text-right"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* إدارة المخزون */}
            <Card>
              <CardHeader className="pb-4">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Warehouse className="h-5 w-5 text-primary" />
                  إدارة المخزون والتتبع
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                  <div>
                    <Label htmlFor="min_stock_level" className="text-sm font-medium">
                      الحد الأدنى للمخزون
                    </Label>
                    <Input
                      id="min_stock_level"
                      type="number"
                      value={formData.min_stock_level}
                      onChange={(e) => updateFormData("min_stock_level", Number.parseInt(e.target.value) || 0)}
                      className="text-right"
                    />
                  </div>
                  <div>
                    <Label htmlFor="max_stock_level" className="text-sm font-medium">
                      الحد الأقصى للمخزون
                    </Label>
                    <Input
                      id="max_stock_level"
                      type="number"
                      value={formData.max_stock_level}
                      onChange={(e) => updateFormData("max_stock_level", Number.parseInt(e.target.value) || 0)}
                      className="text-right"
                    />
                  </div>
                  <div>
                    <Label htmlFor="reorder_point" className="text-sm font-medium">
                      نقطة إعادة الطلب
                    </Label>
                    <Input
                      id="reorder_point"
                      type="number"
                      value={formData.reorder_point}
                      onChange={(e) => updateFormData("reorder_point", Number.parseInt(e.target.value) || 0)}
                      className="text-right"
                    />
                  </div>
                  <div>
                    <Label htmlFor="location" className="text-sm font-medium">
                      موقع التخزين
                    </Label>
                    <Input
                      id="location"
                      value={formData.location}
                      onChange={(e) => updateFormData("location", e.target.value)}
                      className="text-right"
                      placeholder="رقم الرف، المنطقة"
                    />
                  </div>
                  <div>
                    <Label htmlFor="shelf_life" className="text-sm font-medium">
                      مدة الصلاحية (يوم)
                    </Label>
                    <Input
                      id="shelf_life"
                      type="number"
                      value={formData.shelf_life}
                      onChange={(e) => updateFormData("shelf_life", Number.parseInt(e.target.value) || 0)}
                      className="text-right"
                    />
                  </div>
                </div>

                <Separator className="my-6" />

                {/* خيارات التتبع */}
                <div>
                  <Label className="text-sm font-medium mb-3 block">خيارات التتبع</Label>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="flex items-center space-x-2 space-x-reverse">
                      <Checkbox
                        id="expiry_tracking"
                        checked={formData.expiry_tracking}
                        onCheckedChange={(checked) => updateFormData("expiry_tracking", checked)}
                      />
                      <Label htmlFor="expiry_tracking" className="text-sm">
                        تتبع تاريخ الانتهاء
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2 space-x-reverse">
                      <Checkbox
                        id="batch_tracking"
                        checked={formData.batch_tracking}
                        onCheckedChange={(checked) => updateFormData("batch_tracking", checked)}
                      />
                      <Label htmlFor="batch_tracking" className="text-sm font-medium">
                        تتبع الدفعات
                      </Label>
                      <div className="text-xs text-muted-foreground mt-1">
                        (فعل هذا الخيار لإظهار جدول تفاصيل الدفعات أدناه)
                      </div>
                    </div>
                    <div className="flex items-center space-x-2 space-x-reverse">
                      <Checkbox
                        id="serial_tracking"
                        checked={formData.serial_tracking}
                        onCheckedChange={(checked) => updateFormData("serial_tracking", checked)}
                      />
                      <Label htmlFor="serial_tracking" className="text-sm">
                        تتبع الأرقام التسلسلية
                      </Label>
                    </div>
                  </div>

                  {!formData.batch_tracking && (
                    <div className="mt-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                      <div className="flex items-start gap-3">
                        <Package2 className="h-5 w-5 text-blue-600 mt-0.5" />
                        <div>
                          <h4 className="text-sm font-medium text-blue-900 mb-1">تتبع الدفعات غير مفعل</h4>
                          <p className="text-sm text-blue-700">
                            لإضافة وإدارة تفاصيل الدفعات (Batches) للمنتج، يرجى تفعيل خيار "تتبع الدفعات" أعلاه. سيظهر
                            جدول تفاعلي يمكنك من خلاله إضافة معلومات الدفعات مثل رقم الدفعة، تاريخ الإنتاج، تاريخ
                            الانتهاء، والكميات في كل مستودع.
                          </p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            <WarehouseInventoryTable productId={editingProduct?.id} readOnly={false} />

            {formData.batch_tracking ? (
              <BatchTrackingTable productId={editingProduct?.id} readOnly={false} />
            ) : (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Package2 className="h-5 w-5 text-muted-foreground" />
                    تفاصيل الدفعات والتتبع
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-8">
                    <Package2 className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                    <p className="text-muted-foreground mb-2">تتبع الدفعات غير مفعل لهذا المنتج</p>
                    <p className="text-sm text-muted-foreground mb-4">
                      لإظهار جدول تفاصيل الدفعات، يرجى تفعيل خيار "تتبع الدفعات" في قسم إدارة المخزون أعلاه
                    </p>
                    <Button
                      variant="outline"
                      onClick={() => updateFormData("batch_tracking", true)}
                      className="flex items-center gap-2"
                    >
                      <Package2 className="h-4 w-4" />
                      تفعيل تتبع الدفعات
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* بيانات المورد */}
            <Card>
              <CardHeader className="pb-4">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Truck className="h-5 w-5 text-primary" />
                  بيانات المورد والتوريد
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="supplier_selection" className="text-sm font-medium">
                      اختيار المورد
                    </Label>
                    <Select value={formData.supplier_id} onValueChange={handleSupplierChange}>
                      <SelectTrigger>
                        <SelectValue placeholder="اختر المورد" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">بدون مورد</SelectItem>
                        {definitions.suppliers.map((supplier) => (
                          <SelectItem key={supplier.id} value={supplier.id.toString()}>
                            {supplier.name} {supplier.code && `(${supplier.code})`}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="supplier_name" className="text-sm font-medium">
                      اسم المورد
                    </Label>
                    <Input
                      id="supplier_name"
                      value={formData.supplier_name}
                      onChange={(e) => updateFormData("supplier_name", e.target.value)}
                      className="text-right"
                      placeholder="اسم المورد الرئيسي"
                      readOnly
                    />
                  </div>
                  <div>
                    <Label htmlFor="supplier_code" className="text-sm font-medium">
                      كود المورد
                    </Label>
                    <Input
                      id="supplier_code"
                      value={formData.supplier_code}
                      onChange={(e) => updateFormData("supplier_code", e.target.value)}
                      className="text-right"
                      placeholder="كود المورد"
                      readOnly
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* ملاحظات إضافية */}
            <Card>
              <CardHeader className="pb-4">
                <CardTitle className="text-lg">ملاحظات وتفاصيل إضافية</CardTitle>
              </CardHeader>
              <CardContent>
                <div>
                  <Label htmlFor="notes" className="text-sm font-medium">
                    ملاحظات
                  </Label>
                  <Textarea
                    id="notes"
                    value={formData.notes}
                    onChange={(e) => updateFormData("notes", e.target.value)}
                    className="text-right"
                    rows={3}
                    placeholder="أي ملاحظات أو تفاصيل إضافية حول الصنف"
                  />
                </div>
              </CardContent>
            </Card>

            {/* أزرار الحفظ والإلغاء */}
            <div className="flex gap-4 justify-end border-t pt-6 pb-6">
              <Button
                type="button"
                variant="outline"
                onClick={onCancel}
                disabled={isSubmitting}
                className="min-w-[120px] bg-transparent"
              >
                <X className="h-4 w-4 mr-2" />
                إلغاء
              </Button>
              <Button type="submit" disabled={isSubmitting} className="bg-primary hover:bg-primary/90 min-w-[120px]">
                <Save className="h-4 w-4 mr-2" />
                {isSubmitting ? "جاري الحفظ..." : "حفظ الصنف"}
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}
