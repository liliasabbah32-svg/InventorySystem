"use client"

import { useState, useEffect, useMemo, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Plus, Search, Download, Package, Layers, BarChart3, TrendingUp } from "lucide-react"
import { UniversalToolbar } from "@/components/ui/universal-toolbar"

export default function ProductGroups() {
  const [state, setState] = useState({
    itemGroups: [],
    loading: true,
    error: null,
    isFormOpen: false,
    isSubmitting: false,
    editingGroup: null,
    currentIndex: 0,
    searchTerm: "",
    formData: {
      group_number: "",
      group_name: "",
      description: "",
      status: "نشط",
    },
  })

  const filteredGroups = useMemo(() => {
    return state.itemGroups.filter(
      (group) => group.group_name?.includes(state.searchTerm) || group.group_number?.includes(state.searchTerm),
    )
  }, [state.itemGroups, state.searchTerm])

  const statistics = useMemo(() => {
    const totalGroups = state.itemGroups.length
    const totalProducts = state.itemGroups.reduce((sum, group) => sum + (group.product_count || 0), 0)
    const largestGroup = state.itemGroups.reduce(
      (max, group) => ((group.product_count || 0) > (max.product_count || 0) ? group : max),
      { group_name: "لا يوجد", product_count: 0 },
    )
    const averageProducts = totalGroups > 0 ? Math.round(totalProducts / totalGroups) : 0

    return { totalGroups, totalProducts, largestGroup, averageProducts }
  }, [state.itemGroups])

  const currentGroup = useMemo(() => {
    return filteredGroups[state.currentIndex] || null
  }, [filteredGroups, state.currentIndex])

  useEffect(() => {
    fetchItemGroups()
  }, [])

  useEffect(() => {
    if (currentGroup && state.isFormOpen) {
      updateFormData(currentGroup)
    }
  }, [currentGroup, state.isFormOpen])

  const fetchItemGroups = async () => {
    try {
      setState((prev) => ({ ...prev, loading: true }))
      const response = await fetch("/api/item-groups")
      if (!response.ok) {
        throw new Error("Failed to fetch item groups")
      }
      const data = await response.json()
      setState((prev) => ({ ...prev, itemGroups: data, error: null }))
    } catch (err) {
      setState((prev) => ({ ...prev, error: err.message }))
    } finally {
      setState((prev) => ({ ...prev, loading: false }))
    }
  }

  const updateFormData = useCallback((group) => {
    setState((prev) => ({
      ...prev,
      formData: {
        group_number: group.group_number || "",
        group_name: group.group_name || "",
        description: group.description || "",
        status: group.status || "نشط",
      },
    }))
  }, [])

  const handleFirst = useCallback(() => {
    console.log("[v0] Navigation: First")
    setState((prev) => ({ ...prev, currentIndex: 0 }))
  }, [])

  const handlePrevious = useCallback(() => {
    console.log("[v0] Navigation: Previous")
    setState((prev) => ({
      ...prev,
      currentIndex: Math.max(0, prev.currentIndex - 1),
    }))
  }, [])

  const handleNext = useCallback(() => {
    console.log("[v0] Navigation: Next")
    setState((prev) => ({
      ...prev,
      currentIndex: Math.min(filteredGroups.length - 1, prev.currentIndex + 1),
    }))
  }, [filteredGroups.length])

  const handleLast = useCallback(() => {
    console.log("[v0] Navigation: Last")
    setState((prev) => ({
      ...prev,
      currentIndex: filteredGroups.length - 1,
    }))
  }, [filteredGroups.length])

  const generateNewGroupNumber = async () => {
    try {
      const response = await fetch("/api/item-groups/generate-number")
      if (response.ok) {
        const data = await response.json()
        setState((prev) => ({
          ...prev,
          formData: { ...prev.formData, group_number: data.number },
        }))
      }
    } catch (error) {
      console.error("Error generating group number:", error)
    }
  }

  const handleInputChange = useCallback((field, value) => {
    setState((prev) => ({
      ...prev,
      formData: { ...prev.formData, [field]: value },
    }))
  }, [])

  const handleEditGroup = (group) => {
    const index = filteredGroups.findIndex((g) => g.group_number === group.group_number)
    setState((prev) => ({
      ...prev,
      currentIndex: index >= 0 ? index : 0,
      editingGroup: group,
      isFormOpen: true,
    }))
  }

  const handleDeleteGroup = async (groupId) => {
    if (!confirm("هل أنت متأكد من حذف هذه المجموعة؟")) {
      return
    }

    try {
      const response = await fetch(`/api/item-groups/${groupId}`, {
        method: "DELETE",
      })

      if (response.ok) {
        await fetchItemGroups()
      } else {
        setState((prev) => ({ ...prev, error: "فشل في حذف المجموعة" }))
      }
    } catch (error) {
      console.error("Error deleting group:", error)
      setState((prev) => ({ ...prev, error: "خطأ في حذف المجموعة" }))
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()

    if (!state.formData.group_name.trim()) {
      alert("اسم المجموعة مطلوب")
      return
    }

    if (!state.editingGroup && !state.formData.group_number.trim()) {
      alert("رقم المجموعة مطلوب")
      return
    }

    setState((prev) => ({ ...prev, isSubmitting: true }))
    try {
      const method = state.editingGroup ? "PUT" : "POST"
      const url = state.editingGroup ? `/api/item-groups/${state.editingGroup.id}` : "/api/item-groups"

      const response = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(state.formData),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Failed to save item group")
      }

      await fetchItemGroups()
      setState((prev) => ({
        ...prev,
        isFormOpen: false,
        editingGroup: null,
        formData: {
          group_number: "",
          group_name: "",
          description: "",
          status: "نشط",
        },
      }))
      alert(state.editingGroup ? "تم تحديث المجموعة بنجاح" : "تم حفظ المجموعة بنجاح")
    } catch (err) {
      console.error("Error saving item group:", err)
      alert("حدث خطأ أثناء حفظ البيانات: " + err.message)
    } finally {
      setState((prev) => ({ ...prev, isSubmitting: false }))
    }
  }

  const getStatusBadge = (status) => {
    const statusConfig = {
      نشط: { color: "bg-green-100 text-green-800", text: "نشط" },
      "غير نشط": { color: "bg-red-100 text-red-800", text: "غير نشط" },
      متوقف: { color: "bg-yellow-100 text-yellow-800", text: "متوقف" },
    }

    const config = statusConfig[status] || statusConfig["نشط"]
    return <Badge className={config.color}>{config.text}</Badge>
  }

  if (state.loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">جاري تحميل المجموعات...</p>
        </div>
      </div>
    )
  }

  if (state.error) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <p className="text-destructive mb-4">خطأ في تحميل البيانات: {state.error}</p>
          <Button onClick={fetchItemGroups} variant="outline">
            إعادة المحاولة
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6 p-6" dir="rtl">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-blue-700">إجمالي المجموعات</p>
                <p className="text-3xl font-bold text-blue-900">{statistics.totalGroups}</p>
              </div>
              <Layers className="h-10 w-10 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-green-700">إجمالي الأصناف</p>
                <p className="text-3xl font-bold text-green-900">{statistics.totalProducts}</p>
              </div>
              <Package className="h-10 w-10 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-50 to-orange-100 border-orange-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-orange-700">أكبر مجموعة</p>
                <p className="text-lg font-bold text-orange-900 truncate">{statistics.largestGroup.group_name}</p>
                <p className="text-sm text-orange-600">{statistics.largestGroup.product_count} صنف</p>
              </div>
              <BarChart3 className="h-10 w-10 text-orange-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-purple-700">متوسط الأصناف</p>
                <p className="text-3xl font-bold text-purple-900">{statistics.averageProducts}</p>
              </div>
              <TrendingUp className="h-10 w-10 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col lg:flex-row gap-4 items-center justify-between">
            <div className="flex flex-col sm:flex-row gap-4 flex-1">
              <div className="relative flex-1">
                <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="البحث في المجموعات..."
                  value={state.searchTerm}
                  onChange={(e) => setState((prev) => ({ ...prev, searchTerm: e.target.value }))}
                  className="pr-10"
                />
              </div>
            </div>

            <div className="flex gap-2">
              <Button onClick={() => setState((prev) => ({ ...prev, isFormOpen: true, editingGroup: null }))}>
                <Plus className="ml-2 h-4 w-4" />
                إضافة مجموعة جديدة
              </Button>
              <Button variant="outline">
                <Download className="ml-2 h-4 w-4" />
                تصدير
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Groups Table */}
      <Card>
        <CardHeader>
          <CardTitle className="font-heading">مجموعات الأصناف ({filteredGroups.length})</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-right p-4 font-semibold">رقم المجموعة</th>
                  <th className="text-right p-4 font-semibold">اسم المجموعة</th>
                  <th className="text-right p-4 font-semibold">الوصف</th>
                  <th className="text-right p-4 font-semibold">عدد الأصناف</th>
                  <th className="text-right p-4 font-semibold">الحالة</th>
                  <th className="text-right p-4 font-semibold">الإجراءات</th>
                </tr>
              </thead>
              <tbody>
                {filteredGroups.map((group) => (
                  <tr key={group.group_number} className="border-b hover:bg-gray-50">
                    <td className="p-4 font-mono">{group.group_number}</td>
                    <td className="p-4 font-semibold">{group.group_name}</td>
                    <td className="p-4">{group.description || "-"}</td>
                    <td className="p-4 font-medium">{group.product_count || 0}</td>
                    <td className="p-4">{getStatusBadge(group.status)}</td>
                    <td className="p-4">
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" onClick={() => handleEditGroup(group)}>
                          عرض
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => handleEditGroup(group)}>
                          تعديل
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => handleDeleteGroup(group.id)}>
                          حذف
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Group Dialog */}
      <Dialog open={state.isFormOpen} onOpenChange={(open) => setState((prev) => ({ ...prev, isFormOpen: open }))}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold">
              {state.editingGroup ? "تعديل بيانات المجموعة" : currentGroup ? "عرض المجموعة" : "إضافة مجموعة جديدة"}
            </DialogTitle>
          </DialogHeader>

          {filteredGroups.length > 0 && (
            <UniversalToolbar
              currentIndex={state.currentIndex}
              totalRecords={filteredGroups.length}
              onFirst={handleFirst}
              onPrevious={handlePrevious}
              onNext={handleNext}
              onLast={handleLast}
              isFirstRecord={state.currentIndex === 0}
              isLastRecord={state.currentIndex === filteredGroups.length - 1}
              isSaving={state.isSubmitting}
            />
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="font-semibold">رقم المجموعة</Label>
                <div className="flex gap-2">
                  <Input
                    value={state.formData.group_number}
                    onChange={(e) => handleInputChange("group_number", e.target.value)}
                    placeholder="أدخل رقم المجموعة أو اضغط جديد"
                    disabled={state.editingGroup}
                  />
                  {!state.editingGroup && (
                    <Button
                      type="button"
                      variant="outline"
                      onClick={generateNewGroupNumber}
                      className="whitespace-nowrap bg-transparent"
                    >
                      جديد
                    </Button>
                  )}
                </div>
              </div>
              <div className="space-y-2">
                <Label className="font-semibold">اسم المجموعة *</Label>
                <Input
                  required
                  value={state.formData.group_name}
                  onChange={(e) => handleInputChange("group_name", e.target.value)}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label className="font-semibold">الوصف</Label>
              <Input
                value={state.formData.description}
                onChange={(e) => handleInputChange("description", e.target.value)}
                placeholder="وصف المجموعة (اختياري)"
              />
            </div>

            <div className="flex justify-end gap-3 pt-6 border-t">
              <Button
                type="button"
                variant="outline"
                onClick={() => setState((prev) => ({ ...prev, isFormOpen: false }))}
                disabled={state.isSubmitting}
              >
                إلغاء
              </Button>
              <Button type="submit" disabled={state.isSubmitting}>
                {state.isSubmitting ? "جاري الحفظ..." : "حفظ البيانات"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}
