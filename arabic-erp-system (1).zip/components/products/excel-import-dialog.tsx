"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Upload, Download, FileSpreadsheet, CheckCircle, AlertCircle, X, Package } from "lucide-react"
import * as XLSX from "xlsx"

interface ExcelProduct {
  product_code: string
  product_name: string
  product_name_en?: string
  barcode?: string
  description?: string
  status?: string
  image_url?: string
  category: string
  subcategory?: string
  brand?: string
  model?: string
  manufacturer?: string
  main_unit: string
  secondary_unit?: string
  conversion_factor?: number
  weight?: number
  dimensions?: string
  country_of_origin?: string
  color?: string
  size?: string
  material?: string
  warranty_period?: number
  last_purchase_price: number
  average_cost?: number
  selling_price?: number
  wholesale_price?: number
  retail_price?: number
  currency: string
  tax_rate?: number
  discount_rate?: number
  min_stock_level?: number
  max_stock_level?: number
  reorder_point?: number
  location?: string
  shelf_life?: number
  expiry_tracking: boolean
  batch_tracking: boolean
  serial_tracking?: boolean
  supplier_name?: string
  supplier_code?: string
  warehouse_name?: string
  initial_quantity?: number
  lot_number?: string
  expiry_date?: string
  manufacturing_date?: string
  notes?: string
  isValid?: boolean
  errors?: string[]
  rowIndex?: number
}

interface ExcelImportDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onImportComplete: () => void
}

export function ExcelImportDialog({ open, onOpenChange, onImportComplete }: ExcelImportDialogProps) {
  const [file, setFile] = useState<File | null>(null)
  const [products, setProducts] = useState<ExcelProduct[]>([])
  const [isProcessing, setIsProcessing] = useState(false)
  const [isImporting, setIsImporting] = useState(false)
  const [importProgress, setImportProgress] = useState(0)
  const [importResults, setImportResults] = useState<{
    success: number
    failed: number
    errors: string[]
  } | null>(null)
  const [showPreview, setShowPreview] = useState(false)

  const downloadTemplate = () => {
    const templateData = [
      {
        product_code: "A0000001",
        product_name: "منتج تجريبي",
        product_name_en: "Sample Product",
        barcode: "1234567890123",
        description: "وصف المنتج التفصيلي",
        status: "نشط",
        image_url: "https://example.com/image.jpg",
        category: "إلكترونيات",
        subcategory: "هواتف ذكية",
        brand: "سامسونج",
        model: "Galaxy S24",
        manufacturer: "Samsung Electronics",
        main_unit: "قطعة",
        secondary_unit: "صندوق",
        conversion_factor: 12,
        weight: 0.2,
        dimensions: "15 × 7 × 0.8",
        country_of_origin: "كوريا الجنوبية",
        color: "أسود",
        size: "متوسط",
        material: "معدن وزجاج",
        warranty_period: 24,
        last_purchase_price: 800.0,
        average_cost: 820.0,
        selling_price: 1200.0,
        wholesale_price: 1000.0,
        retail_price: 1200.0,
        currency: "ريال سعودي",
        tax_rate: 15,
        discount_rate: 5,
        min_stock_level: 10,
        max_stock_level: 100,
        reorder_point: 20,
        location: "A-01-05",
        shelf_life: 365,
        expiry_tracking: false,
        batch_tracking: true,
        serial_tracking: false,
        supplier_name: "شركة التقنية المتقدمة",
        supplier_code: "SUP001",
        warehouse_name: "المستودع الرئيسي",
        initial_quantity: 50,
        lot_number: "LOT001",
        expiry_date: "2025-12-31",
        manufacturing_date: "2024-01-01",
        notes: "منتج عالي الجودة مع ضمان شامل",
      },
      {
        product_code: "B0000002",
        product_name: "منتج غذائي",
        product_name_en: "Food Product",
        barcode: "9876543210987",
        description: "منتج غذائي طبيعي",
        status: "نشط",
        image_url: "",
        category: "أغذية",
        subcategory: "معلبات",
        brand: "الطبيعة",
        model: "",
        manufacturer: "مصنع الأغذية الطبيعية",
        main_unit: "علبة",
        secondary_unit: "كرتون",
        conversion_factor: 24,
        weight: 0.4,
        dimensions: "10 × 10 × 5",
        country_of_origin: "السعودية",
        color: "",
        size: "400 جرام",
        material: "معدن",
        warranty_period: 0,
        last_purchase_price: 5.0,
        average_cost: 5.2,
        selling_price: 8.0,
        wholesale_price: 7.0,
        retail_price: 8.5,
        currency: "ريال سعودي",
        tax_rate: 0,
        discount_rate: 0,
        min_stock_level: 50,
        max_stock_level: 500,
        reorder_point: 100,
        location: "B-02-10",
        shelf_life: 730,
        expiry_tracking: true,
        batch_tracking: true,
        serial_tracking: false,
        supplier_name: "مورد الأغذية الطبيعية",
        supplier_code: "SUP002",
        warehouse_name: "مستودع الأغذية",
        initial_quantity: 200,
        lot_number: "FOOD001",
        expiry_date: "2026-06-30",
        manufacturing_date: "2024-01-15",
        notes: "يحفظ في مكان بارد وجاف",
      },
    ]

    const ws = XLSX.utils.json_to_sheet(templateData)
    const colWidths = [
      { wch: 12 }, // product_code
      { wch: 25 }, // product_name
      { wch: 25 }, // product_name_en
      { wch: 15 }, // barcode
      { wch: 30 }, // description
      { wch: 10 }, // status
      { wch: 30 }, // image_url
      { wch: 15 }, // category
      { wch: 15 }, // subcategory
      { wch: 15 }, // brand
      { wch: 15 }, // model
      { wch: 20 }, // manufacturer
      { wch: 12 }, // main_unit
      { wch: 12 }, // secondary_unit
      { wch: 12 }, // conversion_factor
      { wch: 10 }, // weight
      { wch: 15 }, // dimensions
      { wch: 15 }, // country_of_origin
      { wch: 10 }, // color
      { wch: 10 }, // size
      { wch: 15 }, // material
      { wch: 12 }, // warranty_period
      { wch: 12 }, // last_purchase_price
      { wch: 12 }, // average_cost
      { wch: 12 }, // selling_price
      { wch: 12 }, // wholesale_price
      { wch: 12 }, // retail_price
      { wch: 12 }, // currency
      { wch: 10 }, // tax_rate
      { wch: 10 }, // discount_rate
      { wch: 12 }, // min_stock_level
      { wch: 12 }, // max_stock_level
      { wch: 12 }, // reorder_point
      { wch: 12 }, // location
      { wch: 10 }, // shelf_life
      { wch: 12 }, // expiry_tracking
      { wch: 12 }, // batch_tracking
      { wch: 12 }, // serial_tracking
      { wch: 20 }, // supplier_name
      { wch: 12 }, // supplier_code
      { wch: 20 }, // warehouse_name
      { wch: 12 }, // initial_quantity
      { wch: 12 }, // lot_number
      { wch: 12 }, // expiry_date
      { wch: 15 }, // manufacturing_date
      { wch: 30 }, // notes
    ]
    ws["!cols"] = colWidths

    const wb = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(wb, ws, "Products Template")

    try {
      const wbout = XLSX.write(wb, { bookType: "xlsx", type: "array" })
      const blob = new Blob([wbout], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" })
      const url = URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = "products_import_template.xlsx"
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
    } catch (error) {
      console.error("Error downloading template:", error)
      alert("حدث خطأ في تحميل القالب. يرجى المحاولة مرة أخرى.")
    }
  }

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0]
    if (selectedFile) {
      setFile(selectedFile)
      processExcelFile(selectedFile)
    }
  }

  const processExcelFile = async (file: File) => {
    setIsProcessing(true)
    try {
      const data = await file.arrayBuffer()
      const workbook = XLSX.read(data, { type: "array" })
      const sheetName = workbook.SheetNames[0]
      const worksheet = workbook.Sheets[sheetName]
      const jsonData = XLSX.utils.sheet_to_json(worksheet) as any[]

      const processedProducts: ExcelProduct[] = jsonData.map((row, index) => {
        const product: ExcelProduct = {
          product_code: row.product_code || "",
          product_name: row.product_name || "",
          product_name_en: row.product_name_en || "",
          barcode: row.barcode || "",
          description: row.description || "",
          status: row.status || "نشط",
          image_url: row.image_url || "",
          category: row.category || "",
          subcategory: row.subcategory || "",
          brand: row.brand || "",
          model: row.model || "",
          manufacturer: row.manufacturer || "",
          main_unit: row.main_unit || "قطعة",
          secondary_unit: row.secondary_unit || "",
          conversion_factor: Number(row.conversion_factor) || 1,
          weight: Number(row.weight) || 0,
          dimensions: row.dimensions || "",
          country_of_origin: row.country_of_origin || "",
          color: row.color || "",
          size: row.size || "",
          material: row.material || "",
          warranty_period: Number(row.warranty_period) || 0,
          last_purchase_price: Number(row.last_purchase_price) || 0,
          average_cost: Number(row.average_cost) || 0,
          selling_price: Number(row.selling_price) || 0,
          wholesale_price: Number(row.wholesale_price) || 0,
          retail_price: Number(row.retail_price) || 0,
          currency: row.currency || "ريال سعودي",
          tax_rate: Number(row.tax_rate) || 15,
          discount_rate: Number(row.discount_rate) || 0,
          min_stock_level: Number(row.min_stock_level) || 0,
          max_stock_level: Number(row.max_stock_level) || 0,
          reorder_point: Number(row.reorder_point) || 0,
          location: row.location || "",
          shelf_life: Number(row.shelf_life) || 0,
          expiry_tracking: Boolean(row.expiry_tracking),
          batch_tracking: Boolean(row.batch_tracking),
          serial_tracking: Boolean(row.serial_tracking),
          supplier_name: row.supplier_name || "",
          supplier_code: row.supplier_code || "",
          warehouse_name: row.warehouse_name || "المستودع الرئيسي",
          initial_quantity: Number(row.initial_quantity) || 0,
          lot_number: row.lot_number || "",
          expiry_date: row.expiry_date || "",
          manufacturing_date: row.manufacturing_date || "",
          notes: row.notes || "",
          rowIndex: index + 2,
          errors: [],
        }

        const errors: string[] = []
        if (!product.product_name.trim()) errors.push("اسم المنتج مطلوب")
        if (!product.category.trim()) errors.push("الفئة مطلوبة")
        if (product.last_purchase_price <= 0) errors.push("سعر الشراء يجب أن يكون أكبر من صفر")
        if (product.expiry_tracking && !product.expiry_date) errors.push("تاريخ الانتهاء مطلوب عند تفعيل تتبع الصلاحية")
        if (product.batch_tracking && product.initial_quantity > 0 && !product.lot_number)
          errors.push("رقم الدفعة مطلوب عند تفعيل تتبع الدفعات")
        if (product.conversion_factor <= 0) errors.push("معامل التحويل يجب أن يكون أكبر من صفر")
        if (product.tax_rate < 0 || product.tax_rate > 100) errors.push("معدل الضريبة يجب أن يكون بين 0 و 100")
        if (product.discount_rate < 0 || product.discount_rate > 100) errors.push("معدل الخصم يجب أن يكون بين 0 و 100")

        product.errors = errors
        product.isValid = errors.length === 0

        return product
      })

      setProducts(processedProducts)
      setShowPreview(true)
    } catch (error) {
      console.error("Error processing Excel file:", error)
      alert("حدث خطأ في معالجة ملف Excel. تأكد من أن الملف يحتوي على البيانات الصحيحة.")
    } finally {
      setIsProcessing(false)
    }
  }

  const importProducts = async () => {
    const validProducts = products.filter((p) => p.isValid)
    if (validProducts.length === 0) {
      alert("لا توجد منتجات صالحة للاستيراد")
      return
    }

    setIsImporting(true)
    setImportProgress(0)

    const results = {
      success: 0,
      failed: 0,
      errors: [] as string[],
    }

    for (let i = 0; i < validProducts.length; i++) {
      const product = validProducts[i]

      try {
        const productResponse = await fetch("/api/inventory/products", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            product_code: product.product_code,
            product_name: product.product_name,
            product_name_en: product.product_name_en,
            barcode: product.barcode,
            description: product.description,
            status: product.status,
            image_url: product.image_url,
            category: product.category,
            subcategory: product.subcategory,
            brand: product.brand,
            model: product.model,
            manufacturer: product.manufacturer,
            main_unit: product.main_unit,
            secondary_unit: product.secondary_unit,
            conversion_factor: product.conversion_factor,
            weight: product.weight,
            dimensions: product.dimensions,
            country_of_origin: product.country_of_origin,
            color: product.color,
            size: product.size,
            material: product.material,
            warranty_period: product.warranty_period,
            last_purchase_price: product.last_purchase_price,
            average_cost: product.average_cost,
            selling_price: product.selling_price,
            wholesale_price: product.wholesale_price,
            retail_price: product.retail_price,
            currency: product.currency,
            tax_rate: product.tax_rate,
            discount_rate: product.discount_rate,
            min_stock_level: product.min_stock_level,
            max_stock_level: product.max_stock_level,
            reorder_point: product.reorder_point,
            location: product.location,
            shelf_life: product.shelf_life,
            expiry_tracking: product.expiry_tracking,
            batch_tracking: product.batch_tracking,
            serial_tracking: product.serial_tracking,
            supplier_name: product.supplier_name,
            supplier_code: product.supplier_code,
            available_quantity: product.initial_quantity,
            warehouse_name: product.warehouse_name,
            notes: product.notes,
          }),
        })

        if (!productResponse.ok) {
          const error = await productResponse.json()
          results.errors.push(`الصف ${product.rowIndex}: ${error.error}`)
          results.failed++
          continue
        }

        const createdProduct = await productResponse.json()

        if (product.batch_tracking && product.initial_quantity > 0 && product.lot_number) {
          try {
            await fetch("/api/inventory/lots", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                product_id: createdProduct.id,
                lot_number: product.lot_number,
                purchase_quantity: product.initial_quantity,
                current_quantity: product.initial_quantity,
                expiry_date: product.expiry_date || null,
                manufacturing_date: product.manufacturing_date || null,
                warehouse_name: product.warehouse_name,
                status: "جديد",
              }),
            })
          } catch (lotError) {
            console.error("Error creating lot:", lotError)
            results.errors.push(`الصف ${product.rowIndex}: فشل في إنشاء الدفعة`)
          }
        }

        results.success++
      } catch (error) {
        console.error("Error importing product:", error)
        results.errors.push(`الصف ${product.rowIndex}: خطأ غير متوقع`)
        results.failed++
      }

      setImportProgress(((i + 1) / validProducts.length) * 100)
    }

    setImportResults(results)
    setIsImporting(false)

    if (results.success > 0) {
      onImportComplete()
    }
  }

  const resetDialog = () => {
    setFile(null)
    setProducts([])
    setShowPreview(false)
    setImportResults(null)
    setImportProgress(0)
  }

  const validProductsCount = products.filter((p) => p.isValid).length
  const invalidProductsCount = products.length - validProductsCount

  return (
    <Dialog
      open={open}
      onOpenChange={(open) => {
        onOpenChange(open)
        if (!open) resetDialog()
      }}
    >
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-hidden" dir="rtl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileSpreadsheet className="h-5 w-5" />
            استيراد المنتجات من Excel
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {!showPreview && !importResults && (
            <>
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">رفع ملف Excel</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center gap-4">
                    <Button
                      variant="outline"
                      onClick={downloadTemplate}
                      className="flex items-center gap-2 bg-transparent"
                    >
                      <Download className="h-4 w-4" />
                      تحميل القالب
                    </Button>
                    <span className="text-sm text-muted-foreground">
                      قم بتحميل القالب أولاً لمعرفة تنسيق البيانات المطلوب
                    </span>
                  </div>

                  <div>
                    <Label htmlFor="excel-file">اختر ملف Excel</Label>
                    <Input
                      id="excel-file"
                      type="file"
                      accept=".xlsx,.xls"
                      onChange={handleFileChange}
                      disabled={isProcessing}
                    />
                  </div>

                  {isProcessing && (
                    <div className="flex items-center gap-2">
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary"></div>
                      <span className="text-sm">جاري معالجة الملف...</span>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Alert>
                <Package className="h-4 w-4" />
                <AlertDescription>
                  <strong>تعليمات الاستيراد:</strong>
                  <ul className="list-disc list-inside mt-2 space-y-1 text-sm">
                    <li>قم بتحميل القالب الذي يحتوي على جميع حقول المنتج (أكثر من 40 حقل)</li>
                    <li>املأ البيانات الأساسية: كود المنتج، الاسم، الفئة، وسعر الشراء (مطلوبة)</li>
                    <li>يمكن ملء الحقول الاختيارية مثل: الأسعار المختلفة، المقاسات، الألوان، والمواصفات</li>
                    <li>عند تفعيل تتبع الدفعات، يجب إدخال رقم الدفعة للكميات الابتدائية</li>
                    <li>عند تفعيل تتبع الصلاحية، يجب إدخال تاريخ الانتهاء</li>
                    <li>يمكن إدخال كميات ابتدائية لكل مستودع مع إنشاء دفعات تلقائياً</li>
                    <li>جميع الحقول المالية والكميات يجب أن تكون أرقام صحيحة</li>
                    <li>معدلات الضريبة والخصم يجب أن تكون بين 0 و 100</li>
                  </ul>
                </AlertDescription>
              </Alert>
            </>
          )}

          {showPreview && !importResults && (
            <>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <h3 className="text-lg font-semibold">معاينة البيانات</h3>
                  <div className="flex gap-2">
                    <Badge variant="secondary" className="bg-green-100 text-green-800">
                      صالح: {validProductsCount}
                    </Badge>
                    {invalidProductsCount > 0 && <Badge variant="destructive">غير صالح: {invalidProductsCount}</Badge>}
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" onClick={resetDialog}>
                    <X className="h-4 w-4 mr-2" />
                    إلغاء
                  </Button>
                  <Button
                    onClick={importProducts}
                    disabled={validProductsCount === 0 || isImporting}
                    className="bg-primary hover:bg-primary/90"
                  >
                    <Upload className="h-4 w-4 mr-2" />
                    استيراد ({validProductsCount}) منتج
                  </Button>
                </div>
              </div>

              {isImporting && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span>جاري الاستيراد...</span>
                    <span>{Math.round(importProgress)}%</span>
                  </div>
                  <Progress value={importProgress} />
                </div>
              )}

              <div className="border rounded-lg max-h-96 overflow-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="text-right">الصف</TableHead>
                      <TableHead className="text-right">الحالة</TableHead>
                      <TableHead className="text-right">كود المنتج</TableHead>
                      <TableHead className="text-right">اسم المنتج</TableHead>
                      <TableHead className="text-right">الفئة</TableHead>
                      <TableHead className="text-right">العلامة التجارية</TableHead>
                      <TableHead className="text-right">سعر الشراء</TableHead>
                      <TableHead className="text-right">سعر البيع</TableHead>
                      <TableHead className="text-right">الكمية الابتدائية</TableHead>
                      <TableHead className="text-right">المستودع</TableHead>
                      <TableHead className="text-right">الأخطاء</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {products.map((product, index) => (
                      <TableRow key={index}>
                        <TableCell>{product.rowIndex}</TableCell>
                        <TableCell>
                          {product.isValid ? (
                            <CheckCircle className="h-4 w-4 text-green-600" />
                          ) : (
                            <AlertCircle className="h-4 w-4 text-red-600" />
                          )}
                        </TableCell>
                        <TableCell>{product.product_code}</TableCell>
                        <TableCell>{product.product_name}</TableCell>
                        <TableCell>{product.category}</TableCell>
                        <TableCell>{product.brand}</TableCell>
                        <TableCell>{product.last_purchase_price}</TableCell>
                        <TableCell>{product.selling_price}</TableCell>
                        <TableCell>{product.initial_quantity}</TableCell>
                        <TableCell>{product.warehouse_name}</TableCell>
                        <TableCell>
                          {product.errors && product.errors.length > 0 && (
                            <div className="text-xs text-red-600">{product.errors.join(", ")}</div>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </>
          )}

          {importResults && (
            <>
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">نتائج الاستيراد</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-4 bg-green-50 rounded-lg">
                      <div className="text-2xl font-bold text-green-600">{importResults.success}</div>
                      <div className="text-sm text-green-700">تم استيرادها بنجاح</div>
                    </div>
                    <div className="text-center p-4 bg-red-50 rounded-lg">
                      <div className="text-2xl font-bold text-red-600">{importResults.failed}</div>
                      <div className="text-sm text-red-700">فشل في الاستيراد</div>
                    </div>
                  </div>

                  {importResults.errors.length > 0 && (
                    <div>
                      <h4 className="font-semibold mb-2">الأخطاء:</h4>
                      <div className="max-h-32 overflow-auto space-y-1">
                        {importResults.errors.map((error, index) => (
                          <div key={index} className="text-sm text-red-600 bg-red-50 p-2 rounded">
                            {error}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="flex justify-end gap-2">
                    <Button variant="outline" onClick={resetDialog}>
                      استيراد ملف آخر
                    </Button>
                    <Button onClick={() => onOpenChange(false)}>إغلاق</Button>
                  </div>
                </CardContent>
              </Card>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
