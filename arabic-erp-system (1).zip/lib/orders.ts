import { generateSalesOrderNumber } from "./number-generator"
import { neon } from "@neondatabase/serverless"

const sql = neon(process.env.DATABASE_URL!)

export interface SalesOrder {
  id: number
  order_number: string
  order_date: Date
  customer_id: number
  customer_name: string
  salesman: string
  total_amount: number
  currency_code: string
  currency_name: string
  exchange_rate: number
  order_status: string
  financial_status: string
  delivery_datetime?: Date
  manual_document?: string
  notes?: string
  attachments?: string
  created_at: Date
  updated_at: Date
  invoice_number?: string
  barcode?: string
  workflow_sequence_id?: number
}

export interface PurchaseOrder {
  id: number
  order_number: string
  order_date: Date
  supplier_id: number
  supplier_name: string
  salesman: string
  total_amount: number
  currency_code: string
  currency_name: string
  exchange_rate: number
  workflow_status: string
  expected_delivery_date?: Date
  manual_document?: string
  notes?: string
  attachments?: string
  created_at: Date
  updated_at: Date
}

export interface OrderItem {
  id: number
  order_id: number
  order_type: "sales" | "purchase"
  product_id: number
  product_name: string
  product_code: string
  quantity: number
  unit_price: number
  discount_percentage?: number
  total_price: number
  delivered_quantity?: number
  received_quantity?: number
  notes?: string
  created_at: Date
  barcode?: string
  unit?: string
  warehouse?: string
  bonus_quantity?: number
  expiry_date?: Date
  batch_number?: string
  item_status?: string
}

export interface OrderFilters {
  search?: string
  status?: string
  salesman?: string
  dateFrom?: string
  dateTo?: string
  customerId?: number
  supplierId?: number
}

export async function getSalesOrders(filters: OrderFilters = {}, organizationId = 1) {
  try {
    const whereConditions = ["1=1"]
    const params: any[] = []
    let paramIndex = 1

    if (filters.search) {
      whereConditions.push(`(so.order_number ILIKE $${paramIndex} OR c.customer_name ILIKE $${paramIndex})`)
      params.push(`%${filters.search}%`)
      paramIndex++
    }

    if (filters.status && filters.status !== "all") {
      whereConditions.push(`so.order_status = $${paramIndex}`)
      params.push(filters.status)
      paramIndex++
    }

    if (filters.salesman && filters.salesman !== "all") {
      whereConditions.push(`so.salesman = $${paramIndex}`)
      params.push(filters.salesman)
      paramIndex++
    }

    if (filters.dateFrom) {
      whereConditions.push(`so.order_date >= $${paramIndex}`)
      params.push(filters.dateFrom)
      paramIndex++
    }

    if (filters.dateTo) {
      whereConditions.push(`so.order_date <= $${paramIndex}`)
      params.push(filters.dateTo)
      paramIndex++
    }

    if (filters.customerId) {
      whereConditions.push(`so.customer_id = $${paramIndex}`)
      params.push(filters.customerId)
      paramIndex++
    }

    const whereClause = whereConditions.join(" AND ")

    const result = await sql`
      SELECT 
        so.*,
        COALESCE(c.customer_name, so.customer_name) as customer_name,
        COALESCE(COUNT(soi.id), 0) as item_count,
        COALESCE(SUM(soi.quantity), 0) as total_quantity
      FROM sales_orders so
      LEFT JOIN customers c ON so.customer_id = c.id
      LEFT JOIN sales_order_items soi ON so.id = soi.sales_order_id
      WHERE ${sql.unsafe(whereClause)}
      GROUP BY so.id, c.customer_name
      ORDER BY so.created_at DESC
    `

    return result
  } catch (error) {
    console.error("Error fetching sales orders:", error)
    if (error instanceof Error && error.message.includes("does not exist")) {
      return []
    }
    throw error
  }
}

export async function getPurchaseOrders(filters: OrderFilters = {}, organizationId = 1) {
  try {
    const whereConditions = ["1=1"]
    const params: any[] = []
    let paramIndex = 1

    if (filters.search) {
      whereConditions.push(`(po.order_number ILIKE $${paramIndex} OR s.supplier_name ILIKE $${paramIndex})`)
      params.push(`%${filters.search}%`)
      paramIndex++
    }

    if (filters.status && filters.status !== "all") {
      whereConditions.push(`po.workflow_status = $${paramIndex}`)
      params.push(filters.status)
      paramIndex++
    }

    if (filters.dateFrom) {
      whereConditions.push(`po.order_date >= $${paramIndex}`)
      params.push(filters.dateFrom)
      paramIndex++
    }

    if (filters.dateTo) {
      whereConditions.push(`po.order_date <= $${paramIndex}`)
      params.push(filters.dateTo)
      paramIndex++
    }

    if (filters.supplierId) {
      whereConditions.push(`po.supplier_id = $${paramIndex}`)
      params.push(filters.supplierId)
      paramIndex++
    }

    const whereClause = whereConditions.join(" AND ")

    const result = await sql`
      SELECT 
        po.*,
        s.supplier_name,
        COUNT(poi.id) as item_count,
        SUM(poi.quantity) as total_quantity
      FROM purchase_orders po
      LEFT JOIN suppliers s ON po.supplier_id = s.id
      LEFT JOIN purchase_order_items poi ON po.id = poi.purchase_order_id
      WHERE ${sql.unsafe(whereClause)}
      GROUP BY po.id, s.supplier_name
      ORDER BY po.created_at DESC
    `

    return result
  } catch (error) {
    console.error("Error fetching purchase orders:", error)
    if (error instanceof Error && error.message.includes("does not exist")) {
      return []
    }
    throw error
  }
}

export async function getSalesOrderItems(orderId: number) {
  try {
    const result = await sql`
      SELECT 
        soi.*,
        p.product_code,
        p.main_unit,
        ps.current_stock
      FROM sales_order_items soi
      LEFT JOIN products p ON soi.product_id = p.id
      LEFT JOIN product_stock ps ON p.id = ps.product_id
      WHERE soi.sales_order_id = ${orderId}
      ORDER BY soi.id
    `

    return result
  } catch (error) {
    console.error("Error fetching sales order items:", error)
    throw error
  }
}

export async function getPurchaseOrderItems(orderId: number) {
  try {
    const result = await sql`
      SELECT 
        poi.*,
        p.product_code,
        p.main_unit
      FROM purchase_order_items poi
      LEFT JOIN products p ON poi.product_id = p.id
      WHERE poi.purchase_order_id = ${orderId}
      ORDER BY poi.id
    `

    return result
  } catch (error) {
    console.error("Error fetching purchase order items:", error)
    throw error
  }
}

export async function createSalesOrder(orderData: Partial<SalesOrder>, items: Partial<OrderItem>[]) {
  try {
    if (!orderData.order_number) {
      orderData.order_number = await generateSalesOrderNumber()
    }

    console.log("[v0] Creating sales order with data:", orderData)
    console.log("[v0] Creating sales order with items:", items)

    const orderResult = await sql`
      INSERT INTO sales_orders (
        order_number, order_date, customer_id, customer_name, salesman,
        total_amount, currency_code, currency_name, exchange_rate,
        order_status, financial_status, delivery_datetime, manual_document, 
        notes, invoice_number, barcode, attachments, workflow_sequence_id
      ) VALUES (
        ${orderData.order_number}, 
        ${orderData.order_date}, 
        ${orderData.customer_id},
        ${orderData.customer_name}, 
        ${orderData.salesman || ""}, 
        ${orderData.total_amount || 0},
        ${orderData.currency_code || "SAR"}, 
        ${orderData.currency_name || "ريال سعودي"}, 
        ${orderData.exchange_rate || 1.0},
        ${orderData.order_status || "pending"}, 
        ${orderData.financial_status || "unpaid"},
        ${orderData.delivery_datetime || null}, 
        ${orderData.manual_document || null},
        ${orderData.notes || null},
        ${orderData.invoice_number || null},
        ${orderData.barcode || null},
        ${orderData.attachments || null},
        ${orderData.workflow_sequence_id || null}
      )
      RETURNING *
    `

    const order = orderResult[0]
    console.log("[v0] Sales order created:", order)

    for (const item of items) {
      if (item.product_name && item.quantity && item.unit_price) {
        console.log("[v0] Creating order item:", item)

        await sql`
          INSERT INTO sales_order_items (
            sales_order_id, product_id, product_name, product_code,
            quantity, unit_price, discount_percentage, total_price, 
            notes, barcode, unit, warehouse, bonus_quantity, 
            delivered_quantity, expiry_date, batch_number, item_status
          ) VALUES (
            ${order.id}, 
            ${item.product_id || null}, 
            ${item.product_name}, 
            ${item.product_code || ""},
            ${item.quantity}, 
            ${item.unit_price}, 
            ${item.discount_percentage || 0},
            ${item.total_price || item.quantity * item.unit_price}, 
            ${item.notes || null},
            ${item.barcode || null},
            ${item.unit || "قطعة"},
            ${item.warehouse || "المستودع الرئيسي"},
            ${item.bonus_quantity || 0},
            ${item.delivered_quantity || 0},
            ${item.expiry_date || null},
            ${item.batch_number || null},
            ${item.item_status || "pending"}
          )
        `

        if (item.product_id) {
          try {
            await sql`
              UPDATE product_stock 
              SET reserved_stock = reserved_stock + ${item.quantity}
              WHERE product_id = ${item.product_id}
            `
          } catch (stockError) {
            console.warn("[v0] Could not update stock for product:", item.product_id, stockError)
            // Don't fail the entire order if stock update fails
          }
        }
      }
    }

    console.log("[v0] Sales order creation completed successfully")
    return order
  } catch (error) {
    console.error("Error creating sales order:", error)
    throw error
  }
}

export async function createPurchaseOrder(orderData: Partial<PurchaseOrder>, items: Partial<OrderItem>[]) {
  try {
    // Generate order number if not provided
    if (!orderData.order_number) {
      const lastOrder = await sql`
        SELECT order_number FROM purchase_orders 
        WHERE order_number LIKE 'PO-%' 
        ORDER BY created_at DESC 
        LIMIT 1
      `

      let nextNumber = 1
      if (lastOrder.length > 0) {
        const lastNumber = Number.parseInt(lastOrder[0].order_number.split("-")[1])
        nextNumber = lastNumber + 1
      }

      orderData.order_number = `PO-${nextNumber.toString().padStart(6, "0")}`
    }

    // Create the purchase order
    const orderResult = await sql`
      INSERT INTO purchase_orders (
        order_number, order_date, supplier_id, supplier_name, salesman,
        total_amount, currency_code, currency_name, exchange_rate,
        workflow_status, expected_delivery_date, manual_document, notes
      ) VALUES (
        ${orderData.order_number}, ${orderData.order_date}, ${orderData.supplier_id},
        ${orderData.supplier_name}, ${orderData.salesman}, ${orderData.total_amount},
        ${orderData.currency_code}, ${orderData.currency_name}, ${orderData.exchange_rate},
        ${orderData.workflow_status || "pending"}, ${orderData.expected_delivery_date || null},
        ${orderData.manual_document || null}, ${orderData.notes || null}
      )
      RETURNING *
    `

    const order = orderResult[0]

    // Create order items
    for (const item of items) {
      if (item.product_id && item.quantity && item.unit_price) {
        await sql`
          INSERT INTO purchase_order_items (
            purchase_order_id, product_id, product_name, product_code,
            quantity, unit_price, total_price, notes
          ) VALUES (
            ${order.id}, ${item.product_id}, ${item.product_name}, ${item.product_code},
            ${item.quantity}, ${item.unit_price}, ${item.total_price}, ${item.notes || null}
          )
        `
      }
    }

    return order
  } catch (error) {
    console.error("Error creating purchase order:", error)
    throw error
  }
}

export async function updateOrderStatus(
  orderId: number,
  orderType: "sales" | "purchase",
  status: string,
  userId: string,
) {
  try {
    const table = orderType === "sales" ? "sales_orders" : "purchase_orders"
    const statusField = orderType === "sales" ? "order_status" : "workflow_status"

    const result = await sql`
      UPDATE ${sql.unsafe(table)}
      SET ${sql.unsafe(statusField)} = ${status}, updated_at = NOW()
      WHERE id = ${orderId}
      RETURNING *
    `

    // Log the status change
    await sql`
      INSERT INTO workflow_history (
        order_id, order_type, order_number, previous_status, new_status,
        changed_by, change_reason, organization_id
      ) VALUES (
        ${orderId}, ${orderType}, 
        (SELECT order_number FROM ${sql.unsafe(table)} WHERE id = ${orderId}),
        (SELECT ${sql.unsafe(statusField)} FROM ${sql.unsafe(table)} WHERE id = ${orderId}),
        ${status}, ${userId}, 'Status updated via system', 1
      )
    `

    return result[0]
  } catch (error) {
    console.error("Error updating order status:", error)
    throw error
  }
}

export async function getOrderStatistics(organizationId = 1) {
  try {
    const salesStats = await sql`
      SELECT 
        COUNT(*) as total_orders,
        COUNT(*) FILTER (WHERE order_status = 'pending') as pending_orders,
        COUNT(*) FILTER (WHERE order_status = 'completed') as completed_orders,
        COUNT(*) FILTER (WHERE order_status = 'cancelled') as cancelled_orders,
        COALESCE(SUM(total_amount), 0) as total_value,
        COALESCE(SUM(total_amount) FILTER (WHERE order_status = 'completed'), 0) as completed_value
      FROM sales_orders
      WHERE created_at >= CURRENT_DATE - INTERVAL '30 days'
    `

    const purchaseStats = await sql`
      SELECT 
        COUNT(*) as total_orders,
        COUNT(*) FILTER (WHERE workflow_status = 'pending') as pending_orders,
        COUNT(*) FILTER (WHERE workflow_status = 'completed') as completed_orders,
        COUNT(*) FILTER (WHERE workflow_status = 'cancelled') as cancelled_orders,
        COALESCE(SUM(total_amount), 0) as total_value,
        COALESCE(SUM(total_amount) FILTER (WHERE workflow_status = 'completed'), 0) as completed_value
      FROM purchase_orders
      WHERE created_at >= CURRENT_DATE - INTERVAL '30 days'
    `

    return {
      sales: salesStats[0],
      purchase: purchaseStats[0],
    }
  } catch (error) {
    console.error("Error fetching order statistics:", error)
    throw error
  }
}

export async function getCustomers() {
  try {
    console.log("[v0] Fetching customers from database...")

    const result = await sql`
      SELECT id, customer_code, customer_name, email, mobile1, status
      FROM customers
      WHERE status = 'active'
      ORDER BY customer_name
    `

    console.log("[v0] Customers fetched:", result.length, "records")
    console.log("[v0] Sample customer data:", result[0])

    return result
  } catch (error) {
    console.error("[v0] Error fetching customers:", error)
    throw error
  }
}

export async function getSuppliers() {
  try {
    console.log("[v0] Fetching suppliers from database...")

    const result = await sql`
      SELECT id, supplier_code, supplier_name, email, mobile1, status
      FROM suppliers
      WHERE status = 'active'
      ORDER BY supplier_name
    `

    console.log("[v0] Suppliers fetched:", result.length, "records")
    console.log("[v0] Sample supplier data:", result[0])

    return result
  } catch (error) {
    console.error("[v0] Error fetching suppliers:", error)
    throw error
  }
}

export async function updateSalesOrder(orderId: number, orderData: Partial<SalesOrder>, items: Partial<OrderItem>[]) {
  try {
    console.log("[v0] Updating sales order:", orderId, orderData)

    // Update the sales order
    const orderResult = await sql`
      UPDATE sales_orders SET
        order_number = ${orderData.order_number},
        order_date = ${orderData.order_date},
        customer_id = ${orderData.customer_id},
        customer_name = ${orderData.customer_name},
        salesman = ${orderData.salesman || ""},
        total_amount = ${orderData.total_amount || 0},
        currency_code = ${orderData.currency_code || "SAR"},
        currency_name = ${orderData.currency_name || "ريال سعودي"},
        exchange_rate = ${orderData.exchange_rate || 1.0},
        order_status = ${orderData.order_status || "pending"},
        financial_status = ${orderData.financial_status || "unpaid"},
        delivery_datetime = ${orderData.delivery_datetime || null},
        manual_document = ${orderData.manual_document || null},
        notes = ${orderData.notes || null},
        invoice_number = ${orderData.invoice_number || null},
        barcode = ${orderData.barcode || null},
        attachments = ${orderData.attachments || null},
        workflow_sequence_id = ${orderData.workflow_sequence_id || null},
        updated_at = NOW()
      WHERE id = ${orderId}
      RETURNING *
    `

    const order = orderResult[0]
    console.log("[v0] Sales order updated:", order)

    // Delete existing items
    await sql`DELETE FROM sales_order_items WHERE sales_order_id = ${orderId}`

    // Insert new items
    for (const item of items) {
      if (item.product_name && item.quantity && item.unit_price) {
        console.log("[v0] Creating order item:", item)

        await sql`
          INSERT INTO sales_order_items (
            sales_order_id, product_id, product_name, product_code,
            quantity, unit_price, discount_percentage, total_price, 
            notes, barcode, unit, warehouse, bonus_quantity, 
            delivered_quantity, expiry_date, batch_number, item_status
          ) VALUES (
            ${orderId}, 
            ${item.product_id || null}, 
            ${item.product_name}, 
            ${item.product_code || ""},
            ${item.quantity}, 
            ${item.unit_price}, 
            ${item.discount_percentage || 0},
            ${item.total_price || item.quantity * item.unit_price}, 
            ${item.notes || null},
            ${item.barcode || null},
            ${item.unit || "قطعة"},
            ${item.warehouse || "المستودع الرئيسي"},
            ${item.bonus_quantity || 0},
            ${item.delivered_quantity || 0},
            ${item.expiry_date || null},
            ${item.batch_number || null},
            ${item.item_status || "pending"}
          )
        `
      }
    }

    console.log("[v0] Sales order update completed successfully")
    return order
  } catch (error) {
    console.error("Error updating sales order:", error)
    throw error
  }
}

export async function deleteSalesOrder(orderId: number) {
  try {
    console.log("[v0] Deleting sales order:", orderId)

    // Delete order items first
    await sql`DELETE FROM sales_order_items WHERE sales_order_id = ${orderId}`

    // Delete the order
    await sql`DELETE FROM sales_orders WHERE id = ${orderId}`

    console.log("[v0] Sales order deleted successfully")
    return { success: true }
  } catch (error) {
    console.error("Error deleting sales order:", error)
    throw error
  }
}
